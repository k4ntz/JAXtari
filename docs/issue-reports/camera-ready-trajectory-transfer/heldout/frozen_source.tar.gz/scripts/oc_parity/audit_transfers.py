#!/usr/bin/env python3
"""Audit initial transfer and free-running replay, isolating each game's JAX cache.

The JSON includes presence and all per-object errors; a small matched-position
error is never used as a substitute for missing-object coverage. ``n`` counts
compared snapshots, including injection (there are n-1 action transitions).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

GAMES = (
    "asteroids",
    "bankheist",
    "beamrider",
    "breakout",
    "enduro",
    "freeway",
    "frostbite",
    "kangaroo",
    "montezumarevenge",
    "mspacman",
    "phoenix",
    "pong",
    "seaquest",
    "skiing",
    "tennis",
)


def _json_safe(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_safe(v) for v in value]
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", default="data/oc_parity_corpus")
    parser.add_argument("--out", required=True)
    parser.add_argument("--games", nargs="+", choices=GAMES, default=list(GAMES))
    parser.add_argument("--game", choices=GAMES, help=argparse.SUPPRESS)
    parser.add_argument("--n", type=int, default=150)
    parser.add_argument("--num-t0", type=int, default=5)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument(
        "--sampling-horizon",
        type=int,
        default=150,
        help="Keep sync points fixed during n=1 injection audits",
    )
    parser.add_argument(
        "--latent-lookahead",
        action="store_true",
        help="Fit latent state using at most 16 future transitions",
    )
    args = parser.parse_args()
    if args.n < 1:
        parser.error("--n must be positive")
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    if not args.game:
        errors = []
        for game in args.games:
            cmd = [
                sys.executable,
                __file__,
                "--game",
                game,
                "--corpus",
                args.corpus,
                "--out",
                str(out),
                "--n",
                str(args.n),
                "--num-t0",
                str(args.num_t0),
                "--seed",
                str(args.seed),
            ]
            cmd.extend(["--sampling-horizon", str(args.sampling_horizon)])
            if args.latent_lookahead:
                cmd.append("--latent-lookahead")
            with (out / f"{game}.log").open("w") as log:
                result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
            if result.returncode:
                errors.append(game)
                print(f"{game}: FAILED (see {out / (game + '.log')})", flush=True)
            else:
                d = json.loads((out / game / "summary.json").read_text())
                print(f"{game}: " + json.dumps(d["mean"]), flush=True)
        (out / "errors.json").write_text(json.dumps(errors, indent=2) + "\n")
        if errors:
            raise SystemExit(1)
        return

    os.environ.setdefault("JAX_PLATFORMS", "cpu")
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    import jax
    import numpy as np
    from PIL import Image
    import jaxtari
    from oc_parity.lockstep_eval import (
        _sample_t0s,
        _valid_t0_candidates,
        run_one_lockstep,
    )
    from oc_parity.trajectory_io import load_trajectory

    game = args.game
    game_out = out / game
    game_out.mkdir(exist_ok=True)
    paths = sorted((Path(args.corpus) / "raw").glob(f"{game}_play*.npz"))
    if not paths:
        raise SystemExit(f"Missing human-play recording for {game}")
    env = jaxtari.make(game)
    step, render = jax.jit(env.step), jax.jit(env.render)
    rng = np.random.default_rng(args.seed)
    runs = []
    provenance = []
    prefix_checks = []
    for path in paths:
        traj = load_trajectory(str(path))
        provenance.append(
            {
                "path": str(path),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "meta": traj["meta"],
            }
        )
        candidates = _valid_t0_candidates(
            traj, game, max(args.n, args.sampling_horizon)
        )
        starts = _sample_t0s(
            candidates, mode="random", fixed_t0=None, num_t0=args.num_t0, rng=rng
        )
        if starts and not args.latent_lookahead:
            from oc_parity.translators import trajectory_frame_to_state

            t0 = starts[0]
            full = trajectory_frame_to_state(env, game, traj, t0)
            prefix = {
                k: (v[: t0 + 1] if k != "meta" and v is not None else v)
                for k, v in traj.items()
            }
            causal = trajectory_frame_to_state(env, game, prefix, t0)
            same = all(
                np.array_equal(np.asarray(a), np.asarray(b))
                for a, b in zip(
                    jax.tree_util.tree_leaves(full), jax.tree_util.tree_leaves(causal)
                )
            )
            if not same:
                raise AssertionError(
                    "History/RAM transfer changed when future frames were removed"
                )
            prefix_checks.append(
                {"trajectory": str(path), "t0": t0, "same_state_without_future": same}
            )
        for t0 in starts:
            panel_name = (
                f"{path.stem}_t0_{t0}.png" if len(paths) > 1 else f"t0_{t0}.png"
            )
            r = run_one_lockstep(
                env,
                step,
                render,
                traj,
                jax_key=game,
                t0=t0,
                n=args.n,
                tau=2,
                soft_tau=12,
                persist=5,
                keep_strips=True,
                strip_ks=[0, args.n - 1],
                latent_lookahead=args.latent_lookahead,
            )
            strips = []
            for k in sorted(set([0, args.n - 1])):
                a, b = r["strip_frames"][k]
                h, w = min(a.shape[0], b.shape[0]), min(a.shape[1], b.shape[1])
                a, b = a[:h, :w], b[:h, :w]
                diff = np.abs(a.astype(np.int16) - b.astype(np.int16)).astype(np.uint8)
                strips.append(np.concatenate([a, b, diff], axis=1))
            Image.fromarray(np.concatenate(strips, axis=0)).save(game_out / panel_name)
            runs.append(
                {
                    "traj": str(path),
                    "panel": panel_name,
                    **{
                        k: r[k]
                        for k in (
                            "t0",
                            "metrics_at_0",
                            "metrics_at_end",
                            "per_entity_at_0",
                            "per_entity_at_end",
                            "first_diverge_soft",
                            "latent_fit",
                        )
                    },
                }
            )
    if not runs:
        raise SystemExit("No valid windows")
    means = {}
    for field, suffix in [("metrics_at_0", "0"), ("metrics_at_end", "end")]:
        for key in ("entity_mean_l1", "entity_presence", "pixel_mae", "score_mean_abs"):
            means[f"{key}@{suffix}"] = float(np.mean([r[field][key] for r in runs]))
    summary = {
        "game": game,
        "n": args.n,
        "num_transitions": args.n - 1,
        "sampling_horizon": args.sampling_horizon,
        "seed": args.seed,
        "future_assisted": args.latent_lookahead,
        "prefix_checks": prefix_checks,
        "action_alignment": "post_action_snapshot_next_action",
        "provenance": provenance,
        "runs": runs,
        "mean": means,
    }
    source_hash = hashlib.sha256()
    for source in sorted(Path(__file__).parent.rglob("*.py")):
        source_hash.update(str(source.relative_to(Path(__file__).parent)).encode())
        source_hash.update(source.read_bytes())
    summary["implementation_sha256"] = source_hash.hexdigest()
    (game_out / "summary.json").write_text(
        json.dumps(_json_safe(summary), indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
