"""Future-assisted initial-state estimation, followed by unmodified JAX stepping.

This is a diagnostic reconstruction protocol, not a causal state transfer.
Candidates modify latent fields only and must render the exact same injection
frame as the history/RAM transfer. We fit at most 16 future transitions; the
remaining replay is held out from this objective. No future objects are inserted
early, no action is changed, and there are no per-step state corrections.
"""

from __future__ import annotations

import numpy as np

from oc_parity.reconstruction import replace


def _get(state, path):
    for key in path.split("."):
        state = getattr(state, key)
    return state


def _set(state, path, value):
    head, sep, tail = path.partition(".")
    if sep:
        child = _set(getattr(state, head), tail, value)
        return (state.replace if hasattr(state, "replace") else state._replace)(
            **{head: child}
        )
    return replace(state, **{head: value})


def _candidate_groups(state, game, env):
    """Finite, game-specific searches over latent variables with known units."""
    scalar = {
        "pong": [
            ("player_speed", [-5.75, -3, 0, 3, 5.75]),
            ("enemy_speed", [-3, -1, 0, 1, 3]),
            ("ball_vel_x", [-3, -2, -1, 1, 2, 3]),
            ("ball_vel_y", [-3, -2, -1, 0, 1, 2, 3]),
        ],
        "breakout": [
            ("ball_speed_idx", range(5)),
            ("ball_direction_idx", range(4)),
            ("player_speed", range(-6, 7, 2)),
        ],
        "asteroids": [
            ("side_step_counter", [1, 15, 30, 60, 90, 115]),
            ("player_speed_x", [-256, -128, 0, 128, 256]),
            ("player_speed_y", [-256, -128, 0, 128, 256]),
        ],
        "frostbite": [
            ("bailey_jumping_idx", range(32)),
            ("bailey_frac_accumulator", range(0, 16, 4)),
            ("bailey_walk_frac_accumulator", range(0, 16, 4)),
        ],
        "kangaroo": [
            ("player.jump_counter", range(0, 32, 4)),
            ("player.climb_counter", range(0, 16, 2)),
        ],
        "montezumarevenge": [
            ("player_vx", range(-2, 3)),
            ("player_vy", range(-6, 7)),
            ("is_jumping", [False, True]),
        ],
        "skiing": [
            ("skier_x_speed", [-1.2, -0.6, 0, 0.6, 1.2]),
            ("skier_y_speed", [0, 0.3, 0.6, 0.9, 1.2]),
        ],
        "tennis": [
            ("ball_state.ball_velocity_z_fp", range(-40, 41, 10)),
            ("ball_state.move_x", [-4, -2, -1, 0, 1, 2, 4]),
            ("ball_state.move_y", [-4, -2, -1, 0, 1, 2, 4]),
            ("ball_state.bounces", [0, 1]),
            ("ball_state.last_hit", [0, 1]),
        ],
        "enduro": [
            ("player_speed", [0, 0.5, 1, 2, 3, 4]),
            ("opponent_speed", [0, 0.5, 1, 2]),
        ],
        "bankheist": [
            ("reserve_speed", [0, 0.25, 0.5, 0.75]),
            ("police_reserve_speed", [0, 0.25, 0.5, 0.75]),
        ],
    }
    for path, values in scalar.get(game, []):
        yield [_set(state, path, value) for value in values]
    arrays = {
        "freeway": [("lane_time", None)],
        "mspacman": [
            ("ghosts.actions", [2, 3, 4, 5]),
            ("ghosts.timers", [1, 16, 60, 180]),
        ],
        "beamrider": [
            ("level.white_ufo_pattern_id", range(10)),
            ("level.white_ufo_pattern_timer", [0, 8, 16, 32]),
            ("level.white_ufo_attack_time", [0, 16, 60, 180]),
        ],
        "phoenix": [("phoenix_cooldown", [0, 8, 16, 60, 180, 10000])],
        "seaquest": [
            (
                "spawn_state.spawn_timers",
                [
                    int(getattr(env.consts, "DIVER_SPAWN_TIMER_TRIGGER", 0)) + i
                    for i in (1, 2, 4, 8, 12, 16, 32, 60, 180)
                ],
            )
        ],
    }
    for path, values in arrays.get(game, []):
        original = np.asarray(_get(state, path))
        for index in np.ndindex(original.shape):
            choices = values
            if game == "freeway":
                choices = range(
                    max(1, abs(int(np.asarray(env.consts.CAR_UPDATES)[index])))
                )
            candidates = []
            for value in choices:
                arr = original.copy()
                arr[index] = value
                candidates.append(_set(state, path, arr))
            yield candidates
    if game == "asteroids":
        rocks = np.asarray(state.asteroid_states)
        for i in range(len(rocks)):
            if rocks[i, 3] == 0:
                continue
            candidates = []
            for quadrant in range(4):
                arr = rocks.copy()
                arr[i, 2] = quadrant
                candidates.append(replace(state, asteroid_states=arr))
            yield candidates


def fit_latents(env, state, traj, *, jax_key, t0, horizon=16):
    """Return the fitted state and a serializable record of the actual lookahead."""
    import jax
    from oc_parity.lockstep_eval import _extract_pair, _map_oc_action_to_jax
    from oc_parity.metrics import entity_metrics

    h = min(int(horizon), 16, len(traj["actions"]) - t0 - 1)
    # Do not fit across an episode boundary, including archives concatenating
    # independent games without saving an initial reset snapshot.
    for k in range(h):
        if bool(traj["terminated"][t0 + k]) or bool(traj["truncated"][t0 + k]):
            h = k
            break
    if h < 1:
        return state, {"fit_transitions": 0, "accepted_groups": 0}
    step, render = jax.jit(env.step), jax.jit(env.render)
    injection = np.asarray(render(state))
    meanings = traj.get("meta", {}).get("action_meanings")
    actions = [
        _map_oc_action_to_jax(env, int(traj["actions"][t0 + k]), meanings)
        for k in range(1, h + 1)
    ]
    checkpoints = sorted({1, min(2, h), min(4, h), min(8, h), h})

    def score(candidate):
        total = 0.0
        current = candidate
        for k, action in enumerate(actions, 1):
            _, current, _, _, _ = step(current, action)
            if k in checkpoints:
                a, b = _extract_pair(jax_key, env, current, traj["objects"][t0 + k])
                m = entity_metrics(a, b)
                l1 = m["entity_mean_l1"]
                total += (float(l1) if np.isfinite(l1) else 320.0) + 160 * (
                    1 - m["entity_presence"]
                )
        return total / len(checkpoints)

    initial = best = score(state)
    accepted = 0
    # Generate each coordinate group from the most recently accepted state,
    # rather than resetting other fitted coordinates to their initial values.
    groups = _candidate_groups(state, jax_key, env)
    # The generator stores its input state, so rebase each candidate's changed
    # leaves onto the current best before evaluating it.
    original = state
    for candidates in groups:
        group_best = state
        for candidate in candidates:
            leaves0, structure = jax.tree_util.tree_flatten(original)
            leaves1 = jax.tree_util.tree_leaves(candidate)
            current = jax.tree_util.tree_leaves(state)
            import jax.numpy as jnp

            leaves = [
                jnp.where(a != v, v, c) for a, v, c in zip(leaves0, leaves1, current)
            ]
            candidate = jax.tree_util.tree_unflatten(structure, leaves)
            if not np.array_equal(np.asarray(render(candidate)), injection):
                continue
            cost = score(candidate)
            if cost < best - 1e-6:
                group_best, best = candidate, cost
        if group_best is not state:
            state = group_best
            accepted += 1
    return state, {
        "fit_transitions": h,
        "fit_score_before": initial,
        "fit_score_after": best,
        "accepted_groups": accepted,
        "initial_render_unchanged": True,
    }
