"""Transfer Skiing boxes to JAX sprite centers and paired gates.

OCAtari exposes individual poles, while JAX stores a gate's left pole center.
Unobserved slots are offscreen. Fixed skier Y/artwork differences remain.
"""

from __future__ import annotations
import jax
import numpy as np
from .base import cast_like, collect_category, find_object, objects_as_dicts


def _center(obj):
    return [
        float(obj["x"]) + float(obj["w"]) / 2,
        float(obj["y"]) + float(obj["h"]) / 2,
    ]


def _gates(objs):
    rows = []
    for pole in sorted(collect_category(objs, "Flag"), key=lambda o: (o["y"], o["x"])):
        row = next((r for r in rows if abs(r[0]["y"] - pole["y"]) < 5), None)
        if row is None:
            rows.append([pole])
        else:
            row.append(pole)
    return [sorted(row, key=lambda o: o["x"]) for row in rows]


def oc_frame_to_skiing_state(
    env, objects, *, seed=0, frame_index=0, ram=None, history_objects=None, **_ignored
):
    objs = objects_as_dicts(objects)
    _, state = env.reset(jax.random.PRNGKey(seed))
    values = {"step_count": frame_index}
    player = find_object(objs, "Player")
    if player:
        values["skier_x"] = _center(player)[0]
        ori = int(ram[15]) if ram is not None else player.get("orientation", 8)
        try:
            values["skier_pos"] = int(np.clip(round((int(ori) - 2) * 9 / 12), 0, 9))
        except (ValueError, TypeError):
            pass
    tree_colors = np.array(
        [(110, 156, 66), (82, 126, 45), (158, 208, 101), (72, 160, 72)]
    )
    for field, category in [("trees", "Tree"), ("moguls", "Mogul")]:
        arr = np.asarray(getattr(state, field)).copy()
        arr[:, 1] = 10000
        for i, obj in enumerate(collect_category(objs, category)[: len(arr)]):
            arr[i, :2] = _center(obj)
            if field == "trees" and arr.shape[1] > 2:
                arr[i, 2] = int(
                    np.argmin(np.sum((tree_colors - np.array(obj["rgb"])) ** 2, axis=1))
                )
        values[field] = arr
    flags = np.asarray(state.flags).copy()
    flags[:, 1] = 10000
    for i, row in enumerate(_gates(objs)[: len(flags)]):
        flags[i, :2] = _center(row[0])
    values["flags"] = flags
    # Scrolling velocity comes from scenery, not the fixed-Y skier.
    if history_objects and len(history_objects) > 1:
        prev = objects_as_dicts(history_objects[-2])
        deltas = []
        for category in ("Tree", "Mogul", "Flag"):
            for obj in collect_category(objs, category):
                same = [
                    p
                    for p in collect_category(prev, category)
                    if abs(p["x"] - obj["x"]) < 3
                ]
                if same:
                    p = min(same, key=lambda p: abs(p["y"] - obj["y"]))
                    dy = p["y"] - obj["y"]
                    if 0 <= dy <= 8:
                        deltas.append(dy)
        if deltas:
            values["skier_y_speed"] = float(np.median(deltas))
    if ram is not None:
        from oc_parity.reconstruction import bcd

        # Despite its name, JAX's successful_gates stores gates remaining.
        values["successful_gates"] = bcd(ram[107])
        seconds = 60 * bcd(ram[104]) + bcd(ram[105]) + bcd(ram[106]) / 100
        values["step_count"] = round(seconds * env.consts.fps)
    return state.replace(
        **{k: cast_like(v, getattr(state, k)) for k, v in values.items()}
    )


def extract_oc_compare_entities(objects, **_kwargs):
    objs = objects_as_dicts(objects)
    entities = {}
    player = find_object(objs, "Player")
    if player:
        entities["skier"] = tuple(_center(player))
    for category, prefix in [("Flag", "flag"), ("Tree", "tree"), ("Mogul", "mogul")]:
        for i, obj in enumerate(collect_category(objs, category)):
            entities[f"{prefix}_{i}"] = tuple(_center(obj))
    return {"entities": entities, "scores": {}}


def extract_jax_compare_entities(state, env):
    entities = {"skier": (float(state.skier_x), float(env.consts.skier_y))}
    for field, prefix in [("trees", "tree"), ("moguls", "mogul")]:
        for i, obj in enumerate(np.asarray(getattr(state, field))):
            if 22 < float(obj[1]) < 190:
                entities[f"{prefix}_{i}"] = tuple(float(v) for v in obj[:2])
    for i, gate in enumerate(np.asarray(state.flags)):
        if 22 < float(gate[1]) < 190:
            entities[f"flag_{2*i}"] = tuple(float(v) for v in gate[:2])
            entities[f"flag_{2*i+1}"] = (
                float(gate[0]) + float(env.consts.flag_distance),
                float(gate[1]),
            )
    return {"entities": entities, "scores": {}}
