"""Per-game OCAtari object snapshot → Jaxtari state translators."""

from .pong import oc_frame_to_pong_state, trajectory_frame_to_pong_state
from .bankheist import oc_frame_to_bankheist_state
from .registry import (
    SKIPPED_OC_GAMES,
    get_translator,
    list_implemented_translators,
    normalize_game_name,
    print_disclaimers,
    print_skipped_games_note,
)


def trajectory_frame_to_state(env, game, trajectory, frame_index, *, use_ram=True):
    """Transfer a saved frame using objects, past motion, RAM and image phase.

    This public entry point does not inspect future frames. Future-assisted
    latent fitting is a separate, explicitly enabled diagnostic operation.
    """
    from oc_parity.lockstep_eval import _inject_state
    game, _ = normalize_game_name(game)
    return _inject_state(env, game, trajectory, frame_index, use_ram=use_ram)

__all__ = [
    "oc_frame_to_pong_state",
    "trajectory_frame_to_state",
    "trajectory_frame_to_pong_state",
    "oc_frame_to_bankheist_state",
    "SKIPPED_OC_GAMES",
    "get_translator",
    "list_implemented_translators",
    "normalize_game_name",
    "print_disclaimers",
    "print_skipped_games_note",
]
