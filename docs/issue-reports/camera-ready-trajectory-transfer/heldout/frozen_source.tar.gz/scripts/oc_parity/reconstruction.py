"""History/RAM reconstruction at injection, with no access to future snapshots.

RAM addresses follow OCAtari's ``ocatari/ram/<game>.py`` decoders. Only fields
with an identified interpretation are copied; an ALE PRNG byte is not a JAX key.
This module never replaces frames or patches state during the replay.
"""

from __future__ import annotations

import numpy as np
from functools import lru_cache

from oc_parity.translators.base import cast_like, collect_category, find_object


def replace(state, **values):
    """Preserve PyTree leaf dtypes and support both flax and NamedTuple states."""
    values = {k: cast_like(v, getattr(state, k)) for k, v in values.items()}
    return (state.replace if hasattr(state, "replace") else state._replace)(**values)


def bcd(value):
    value = int(value)
    return 10 * (value >> 4) + (value & 15)


@lru_cache(maxsize=32)
def _render(env):
    import jax

    return jax.jit(env.render)


def fit_appearance(env, state, game, traj, t):
    """Infer rendering phase/road geometry from the injection frame alone.

    No image is installed into the renderer; candidates are ordinary game
    states. The raw full-frame MAE must improve before accepting a candidate.
    """
    if traj.get("frames") is None or game not in ("asteroids", "enduro", "beamrider"):
        return state
    target = np.asarray(traj["frames"][t], dtype=np.float32)
    render = _render(env)

    def error(candidate):
        frame = np.asarray(render(candidate), dtype=np.float32)
        if frame.shape != target.shape:
            raise ValueError(
                f"Frame shape mismatch: ALE {target.shape}, JAX {frame.shape}"
            )
        return float(np.abs(frame - target).mean())

    best = error(state)

    def choose(candidates):
        nonlocal state, best
        for candidate in candidates:
            cost = error(candidate)
            if cost < best - 1e-6:
                state, best = candidate, cost

    if game == "asteroids":
        choose([replace(state, step_counter=int(state.step_counter) ^ 1)])
    elif game == "enduro":
        choose([replace(state, weather_index=i) for i in range(16)])
        choose([replace(state, track_top_x=x) for x in range(65, 101, 2)])
        extent = int(env.consts.curve_offset_base)
        choose(
            [
                replace(state, track_top_x_curve_offset=x)
                for x in range(-extent, extent + 1, 4)
            ]
        )
        center = int(state.track_top_x_curve_offset)
        choose(
            [
                replace(state, track_top_x_curve_offset=x)
                for x in range(max(-extent, center - 3), min(extent, center + 3) + 1)
            ]
        )
    elif game == "beamrider":
        from jaxtari.games.jax_beamrider import BLUE_LINE_LOOP_TABLE

        choose(
            [
                state.replace(level=replace(state.level, line_positions=row))
                for row in BLUE_LINE_LOOP_TABLE
            ]
        )
    return state


def _enduro_hidden(env, state, objs):
    """Invert perspective Y phase and lane codes, avoiding next-step reset cars."""
    cars = collect_category(objs, "Car")[:7]
    if not cars:
        return state
    base_y = np.asarray(env.consts.opponent_slot_ys, dtype=float)
    heights = np.abs(np.diff(base_y, prepend=float(env.consts.game_window_height)))
    ys = np.array([c["y"] for c in cars])
    from scipy.optimize import linear_sum_assignment

    best = None
    for phase in np.linspace(0, 1, 129, endpoint=False):
        predicted = base_y + np.floor(phase * heights)
        cost = np.abs(ys[:, None] - predicted[None, :])
        rows, cols = linear_sum_assignment(cost)
        score = cost[rows, cols].sum()
        if best is None or score < best[0]:
            best = (score, phase, rows, cols)
    _, phase, rows, cols = best
    left, right = env.renderer._generate_viewable_track_lookup(
        state.track_top_x, state.track_top_x_curve_offset
    )
    left, right = np.asarray(left), np.asarray(right)
    base = np.asarray(state.base_opponents).copy()
    start = int(np.floor(float(state.opponent_index)))
    indices = (start + np.arange(7)) % base.shape[1]
    base[2, indices] = 1e6  # current unobserved slots are empty, not reset cars
    for i, slot in zip(rows, cols):
        car = cars[i]
        row = int(np.clip(car["y"] - env.consts.sky_height, 0, len(left) - 1))
        ratio = (
            car["x"] + float(np.asarray(env.consts.car_widths)[slot]) // 2 - left[row]
        ) / max(1, right[row] - left[row])
        lane = int(np.argmin(np.abs(np.asarray(env.consts.lane_ratios) - ratio)))
        base[0, indices[slot]] = lane
        base[2, indices[slot]] = -1
    return replace(
        state,
        base_opponents=base,
        opponent_index=start + phase,
        opponent_index_watermark=start,
    )


def motion(traj, t, obj, *, lag=1, wrap_x=None):
    """Match a nearby same-category object in past snapshots, not future ones.

    Nearest-position matching is used only to estimate velocity. It does not
    change object identities or remove objects from reported metrics.
    """
    tprev = max(episode_start(traj, t), t - lag)
    if tprev == t:
        return np.array([float(obj.get("dx", 0)), float(obj.get("dy", 0))])
    prior = collect_category(traj["objects"][tprev], obj["category"])
    if not prior:
        return np.zeros(2)
    pos = np.array([obj["x"], obj["y"]], dtype=float)
    deltas = pos - np.array([[p["x"], p["y"]] for p in prior], dtype=float)
    if wrap_x:
        deltas[:, 0] = (deltas[:, 0] + wrap_x / 2) % wrap_x - wrap_x / 2
    delta = deltas[np.argmin(np.sum(deltas**2, axis=1))]
    return delta / (t - tprev) if np.max(np.abs(delta)) < 24 else np.zeros(2)


def episode_start(traj, t):
    done = (
        np.asarray(traj.get("terminated", np.zeros(t)), dtype=bool)[:t]
        | np.asarray(traj.get("truncated", np.zeros(t)), dtype=bool)[:t]
    )
    ends = np.flatnonzero(done)
    return int(ends[-1]) + 1 if len(ends) else 0


def reconstruct(env, state, game, traj, t, *, use_ram=True):
    objs = traj["objects"][t]
    ram = (
        np.asarray(traj["ram"][t], dtype=int)
        if use_ram and traj.get("ram") is not None
        else None
    )
    player = find_object(objs, "Player")
    # Counters are in emulator frames; recording warmup is already omitted.
    start = episode_start(traj, t)
    elapsed = (
        t
        - start
        + (int(traj.get("meta", {}).get("skip_frames", 0)) if start == 0 else 0)
        + 1
    )

    if game == "freeway":
        cars = sorted(collect_category(objs, "Car"), key=lambda o: o["y"])
        periods = np.maximum(np.abs(np.asarray(env.consts.CAR_UPDATES)), 1)
        phases = np.asarray(state.lane_time).copy()
        # Infer the cadence phase from the latest observed movement. If a lane
        # just moved, its counter *after* that step is zero.
        for i, car in enumerate(cars[: len(phases)]):
            for lag in range(min(t - start, int(periods[i]) + 1)):
                now = sorted(
                    collect_category(traj["objects"][t - lag], "Car"),
                    key=lambda o: o["y"],
                )
                prev = sorted(
                    collect_category(traj["objects"][t - lag - 1], "Car"),
                    key=lambda o: o["y"],
                )
                if i < min(len(now), len(prev)) and now[i]["x"] != prev[i]["x"]:
                    phases[i] = lag % periods[i]
                    break
        state = replace(state, lane_time=phases, time=elapsed)

    elif game == "pong":
        if player and ram is not None:
            # OCAtari clips paddle bounding boxes at the walls; RAM retains
            # the unclipped coordinate used by the transition model.
            state = replace(
                state, player_y=int(ram[51]) - 13, enemy_y=int(ram[50]) - 15
            )
        ball = find_object(objs, "Ball")
        if ball:
            dx, dy = motion(traj, t, ball)
            if dx or dy:
                state = replace(state, ball_vel_x=round(dx), ball_vel_y=round(dy))
        state = replace(state, step_counter=max(60, elapsed) if ball else elapsed)

    elif game == "breakout":
        values = {"step_counter": elapsed}
        if player:
            values["small_paddle"] = int(player["w"]) < int(env.consts.PLAYER_SIZE[0])
            values["player_speed"] = round(motion(traj, t, player)[0])
        ball = find_object(objs, "Ball")
        if ball:
            vel = motion(traj, t, ball)
            if np.any(vel):
                dirs = np.asarray(env.consts.BALL_DIRECTIONS)
                direction = int(np.argmin(np.sum((dirs - np.sign(vel)) ** 2, axis=1)))
                speeds = np.asarray(env.consts.BALL_VELOCITIES_ABS)
                speed = int(
                    np.argmin(np.sum((speeds.mean(axis=1) - np.abs(vel)) ** 2, axis=1))
                )
                values.update(
                    ball_direction_idx=direction,
                    ball_speed_idx=speed,
                    ball_vel_x=round(vel[0]),
                    ball_vel_y=round(vel[1]),
                )
        if ram is not None:
            values.update(lives=ram[57], score=bcd(ram[76]) * 100 + bcd(ram[77]))
        state = replace(state, **values)

    elif game == "asteroids":
        values = {"step_counter": elapsed}
        if player:
            dx, dy = motion(traj, t, player, lag=min(t, 4) or 1, wrap_x=160)
            values.update(
                player_speed_x=round(dx * 128), player_speed_y=round(dy * 128)
            )
        missiles = np.asarray(state.missile_states).copy()
        for i, obj in enumerate(
            collect_category(objs, "PlayerMissile")[: len(missiles)]
        ):
            dx, dy = motion(traj, t, obj, wrap_x=160)
            missiles[i, 2:4] = [round(dx), round(dy)]
        values["missile_states"] = missiles
        rocks = sorted(
            collect_category(objs, "Asteroid"), key=lambda o: (o["y"], o["x"])
        )
        ast = np.asarray(state.asteroid_states).copy()
        quadrants = np.array([[1, 1], [-1, 1], [-1, -1], [1, -1]])
        for i, obj in enumerate(rocks[: len(ast)]):
            velocity = motion(traj, t, obj, lag=min(t, 4) or 1, wrap_x=160)
            if np.any(velocity):
                # Column 2 controls movement quadrant; unlike ship rotation,
                # it is not used by the asteroid renderer.
                mask = np.abs(velocity) > 0.01
                ast[i, 2] = np.argmin(
                    np.sum((quadrants[:, mask] - np.sign(velocity)[mask]) ** 2, axis=1)
                )
        values["asteroid_states"] = ast
        state = replace(state, **values)

    elif game == "beamrider":
        level = state.level
        if player:
            # Invert _get_player_screen_x, rather than snapping an in-between
            # player position to one of the five lane centers.
            x = float(player["x"])
            x = {26.0: 27.0, 51.0: 52.0, 128.0: 127.0}.get(x, x)
            level = replace(level, player_pos=x, player_vel=motion(traj, t, player)[0])
        # The model's velocity field is a lane index, not a pixel delta.
        # Keep it until the perspective projection has been inverted.
        if ram is not None:
            # RAM[0] is already one-based. RAM[5] counts reserve lives;
            # JAX includes the current ship. RAM[84] is the remaining saucer
            # counter. The little-endian BCD score at 9:12 was checked against
            # every reward delta in the archived recording (two +44 events).
            state = replace(
                state,
                sector=max(1, int(ram[0])),
                lives=int(ram[5]) + 1,
                score=bcd(ram[9]) + 100 * bcd(ram[10]) + 10000 * bcd(ram[11]),
                ufo_killed=int(ram[84]) < int(env.consts.WHITE_UFOS_PER_SECTOR),
            )
            level = replace(level, white_ufo_left=ram[84])
        state = state.replace(level=level)

    elif game == "frostbite":
        values = {"frame_count": elapsed}
        obstacles = sum(
            (collect_category(objs, c) for c in ("Bird", "Crab", "Clam", "GreenFish")),
            [],
        )
        if not obstacles:
            values["obstacle_active"] = np.zeros_like(np.asarray(state.obstacle_active))
        if ram is not None:
            # These are already encoded as BCD in both implementations.
            values.update(
                score=ram[72:75],
                temperature=ram[101],
                remaining_lives=ram[76],
                building_igloo_idx=-1 if ram[77] == 255 else min(15, ram[77]),
            )
        if not player:
            values["bailey_visible"] = 0
        state = replace(state, **values)

    elif game == "montezumarevenge":
        if ram is not None:
            # OCAtari identifies ladder state directly from RAM[94]. Position
            # alone is ambiguous near the top/bottom of ladders.
            state = replace(state, is_climbing=ram[94] == 1)

    elif game == "bankheist" and ram is not None:
        state = replace(
            state,
            money=bcd(ram[88]) * 10000 + bcd(ram[89]) * 100 + bcd(ram[90]),
            player_lives=ram[85],
        )

    elif game == "kangaroo":
        level = replace(state.level, step_counter=elapsed)
        p = state.player
        if ram is not None:
            p = replace(
                p,
                is_climbing=ram[18] in (39, 47),
                is_crashing=ram[54] in (1, 128),
                is_crouching=ram[18] in (20, 28),
            )
        state = state.replace(player=p, level=level)

    elif game == "seaquest" and ram is not None:
        state = replace(
            state,
            oxygen=ram[102],
            divers_collected=ram[62],
            score=bcd(ram[56]) * 10000 + bcd(ram[57]) * 100 + bcd(ram[58]),
            lives=ram[59],
            step_counter=elapsed % 1024,
        )
        sharks = np.zeros_like(np.asarray(state.shark_positions))
        subs = np.zeros_like(np.asarray(state.sub_positions))
        timers = np.zeros(4, dtype=np.int32)
        off_timers = np.full(24, -1, dtype=np.int32)
        previous_kind = np.zeros(4, dtype=np.int32)
        directions = np.zeros(4, dtype=np.int32)
        for native_lane in range(4):
            lane = 3 - native_lane  # OCAtari enumerates lanes from bottom to top
            is_sub = 3 < int(ram[89 + native_lane]) % 8 < 7
            direction = -1 if int(ram[89 + native_lane]) & 8 else 1
            previous_kind[lane] = int(is_sub)
            directions[lane] = int(direction < 0)
            formation = int(ram[36 + native_lane])
            for slot in range(3):
                if not formation & (1 << (2 - slot)):
                    continue
                x = (int(ram[30 + native_lane]) + 16 * slot) % 256
                # Unsigned RAM wraps negative incoming right-moving enemies.
                if x > 165 and direction > 0:
                    x -= 256
                last_visible = None
                # Resolve unsigned wrap using a visible anchor in this same
                # formation. In particular, x=255 can mean an exited leftward
                # enemy at -1, rather than an incoming enemy on the right.
                for past in range(t - 1, start - 1, -1):
                    old = np.asarray(traj["ram"][past], dtype=int)
                    if not int(old[36 + native_lane]) & (1 << (2 - slot)):
                        break
                    raw_x = (int(old[30 + native_lane]) + 16 * slot) % 256
                    if 0 <= raw_x <= 160:
                        last_visible = past
                        x = raw_x
                        previous = raw_x
                        for frame in range(past + 1, t + 1):
                            value = (
                                int(traj["ram"][frame][30 + native_lane]) + 16 * slot
                            ) % 256
                            x += (value - previous + 128) % 256 - 128
                            previous = value
                        break
                y = 141 - native_lane * 24 + (0 if is_sub else int(ram[93]) - 4)
                index = lane * 3 + slot
                (subs if is_sub else sharks)[index] = [x, y, direction]
                # If the object has just exited, retain its hidden despawn
                # countdown. Incoming objects must not receive this timer.
                exited = (direction < 0 and x < 0) or (direction > 0 and x > 160)
                if exited:
                    age = (
                        max(0, t - last_visible - 1) if last_visible is not None else 0
                    )
                    off_timers[index + (12 if is_sub else 0)] = max(
                        0, int(env.consts.ENEMY_OFFSCREEN_DESPAWN_FRAMES) - age
                    )
            if formation == 0:
                # Last lane clear is directly visible in past RAM formation
                # bits. Recover elapsed reload time, without peeking ahead.
                since = 0
                for past in range(t, start - 1, -1):
                    if int(traj["ram"][past][36 + native_lane]):
                        break
                    since += 1
                reload = int(
                    np.asarray(env.spawn_timer_reload(state.spawn_state.diver_array))[
                        lane
                    ]
                )
                timers[lane] = max(
                    int(env.consts.DIVER_SPAWN_TIMER_TRIGGER) + 1, reload - since
                )
        # Keep diver arming plausible rather than using the old invalid sentinel
        # 2 to disable spawning. Lane-specific collection status is ambiguous
        # when recording starts mid-episode and remains an explicit limitation.
        state = state.replace(
            shark_positions=cast_like(sharks, state.shark_positions),
            sub_positions=cast_like(subs, state.sub_positions),
            spawn_state=replace(
                state.spawn_state,
                episode_frame=elapsed,
                spawn_timers=timers,
                prev_sub=previous_kind,
                lane_directions=directions,
                enemy_offscreen_timers=off_timers,
                diver_array=np.ones(4, dtype=np.int32),
            ),
        )

    elif game == "mspacman":
        state = replace(state, step_count=elapsed)
        if ram is not None:
            state = replace(
                state,
                score=bcd(ram[122]) * 10000 + bcd(ram[121]) * 100 + bcd(ram[120]),
                lives=int(ram[123]) % 4 + 1,
            )
            # Ghost ordering is OCAtari orange, cyan, pink, red, whereas JAX
            # stores red, pink, cyan, orange.
            indices = [3, 2, 1, 0]
            positions = np.asarray(state.ghosts.positions).copy()
            actions = np.asarray(state.ghosts.actions).copy()
            modes = np.asarray(state.ghosts.modes).copy()
            timers = np.asarray(state.ghosts.timers).copy()
            for j, i in enumerate(indices):
                positions[j] = [int(ram[6 + i]) - 13, int(ram[12 + i]) + 4]
                # A released ghost must not retain reset's ENJAILED mode.
                in_jail = 60 <= positions[j, 0] <= 90 and 60 <= positions[j, 1] <= 90
                modes[j] = 6 if in_jail else 1
                timers[j] = (
                    env.consts.ENJAILED_DURATION
                    if in_jail
                    else env.consts.CHASE_DURATION
                )
                if t > 0:
                    prev = np.asarray(traj["ram"][t - 1], dtype=int)
                    dx = (int(ram[6 + i]) - int(prev[6 + i]) + 80) % 160 - 80
                    dy = int(ram[12 + i]) - int(prev[12 + i])
                    if dx or dy:
                        actions[j] = (
                            (3 if dx > 0 else 4)
                            if abs(dx) >= abs(dy)
                            else (5 if dy > 0 else 2)
                        )
            state = state.replace(
                ghosts=replace(
                    state.ghosts,
                    positions=positions,
                    actions=actions,
                    modes=modes,
                    timers=timers,
                )
            )
            fruit = state.fruit
            if int(ram[11]) > 0 and int(ram[17]) > 0:
                fruit = replace(
                    fruit,
                    position=[int(ram[11]) - 13, int(ram[17]) + 4],
                    spawned=True,
                    timer=env.consts.FRUIT_WANDER_DURATION,
                )
            else:
                fruit = replace(fruit, spawned=False)
            state = state.replace(fruit=fruit)

    elif game == "tennis" and ram is not None:
        # Raw point counts (0,1,2,3) differ from HUD values (0,15,30,40).
        gs = state.game_state
        fields = {
            k: v
            for k, v in {"player_score": ram[69], "enemy_score": ram[70]}.items()
            if hasattr(gs, k)
        }
        fields.update(player_game_score=ram[7], enemy_game_score=ram[6])
        on_top = player is not None and float(player["y"]) < float(
            env.consts.GAME_MIDDLE
        )
        ps = replace(state.player_state, player_field=1 if on_top else -1)
        state = state.replace(player_state=ps, game_state=replace(gs, **fields))

    state = fit_appearance(env, state, game, traj, t)
    if game == "enduro":
        state = _enduro_hidden(env, state, objs)
    return state
