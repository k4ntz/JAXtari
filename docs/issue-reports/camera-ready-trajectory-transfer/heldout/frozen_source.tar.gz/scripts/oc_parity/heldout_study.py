#!/usr/bin/env python3
"""Freeze, record, seal and evaluate a separate human-play transfer study.

Only initialization reads the working implementation. Subsequent operations use
and verify the frozen code, dependencies and assets. The primary evaluation never
enables future-assisted fitting. No interactive recording is started by init.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

GAMES = {
    "asteroids": "Asteroids",
    "bankheist": "BankHeist",
    "beamrider": "BeamRider",
    "breakout": "Breakout",
    "enduro": "Enduro",
    "freeway": "Freeway",
    "frostbite": "Frostbite",
    "kangaroo": "Kangaroo",
    "montezumarevenge": "MontezumaRevenge",
    "mspacman": "MsPacman",
    "phoenix": "Phoenix",
    "pong": "Pong",
    "seaquest": "Seaquest",
    "skiing": "Skiing",
    "tennis": "Tennis",
}
SCOPE = {
    "bankheist": "Stay in the initial city/map; later-city transfer is outside this protocol.",
    "montezumarevenge": "Stay in the initial room; collecting the key is allowed.",
    "kangaroo": "Intended scope is level one; retain and note unexpected level changes.",
    "phoenix": "Intended scope is the first bird wave; retain and note unexpected wave changes.",
}
PACKAGES = (
    "jax",
    "jaxlib",
    "numpy",
    "scipy",
    "flax",
    "ocatari",
    "ale-py",
    "gymnasium",
    "pillow",
)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def inventory(root):
    return {
        str(p.relative_to(root)): digest(p)
        for p in sorted(root.rglob("*"))
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
    }


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def expected(plan):
    return [
        (g, seed, f"{g}_play_holdout_seed{seed:02d}.npz")
        for seed in plan["recording_seeds"]
        for g in plan["games"]
    ]


def initialize(study, args):
    if study.exists():
        raise SystemExit(
            f"Study already exists; use status or resume recording: {study}"
        )
    repo = Path(__file__).resolve().parents[2]
    if args.steps < 150 or args.steps < 1 or args.fps < 1 or args.skip_frames < 0:
        raise SystemExit(
            "Need at least 150 recorded frames, positive FPS, nonnegative warmup"
        )
    if len(set(args.seeds)) != len(args.seeds) or any(s < 0 for s in args.seeds):
        raise SystemExit("Recording seeds must be distinct nonnegative integers")
    snapshot = study / "snapshot"
    snapshot.mkdir(parents=True)
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc")
    shutil.copytree(
        repo / "scripts" / "oc_parity",
        snapshot / "scripts" / "oc_parity",
        ignore=ignore,
    )
    shutil.copytree(
        repo / "src" / "jaxtari", snapshot / "src" / "jaxtari", ignore=ignore
    )
    import ocatari
    from jaxtari.paths import get_storage_dir

    shutil.copytree(
        Path(ocatari.__file__).parent, snapshot / "src" / "ocatari", ignore=ignore
    )
    assets = Path(get_storage_dir())
    frozen_assets = snapshot / "assets" / "jaxtari"
    frozen_assets.mkdir(parents=True)
    for name in ("sprites", "states"):
        if (assets / name).exists():
            shutil.copytree(assets / name, frozen_assets / name, ignore=ignore)
    for marker in assets.glob(".*"):
        if marker.is_file():
            shutil.copy2(marker, frozen_assets / marker.name)
    (study / "raw").mkdir()
    old = json.loads(
        (
            repo / "docs/issue-reports/camera-ready-trajectory-transfer/provenance.json"
        ).read_text()
    )
    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "prospective_human_play_evaluation",
        "python_executable": sys.executable,
        "games": args.games,
        "excluded": {"gravitar": "No decoder in the OCAtari pipeline"},
        "recording_seeds": args.seeds,
        "recorded_frames": args.steps,
        "warmup_frames": args.skip_frames,
        "playback_fps": args.fps,
        "compared_frames": 150,
        "transitions": 149,
        "syncs_per_recording": 5,
        "sync_seed": 20261027,
        "record_mode": "play",
        "frameskip": 1,
        "sticky_action_probability": 0.0,
        "future_assisted": False,
        "scope": SCOPE,
        "development_hashes": [x["sha256"] for x in old["raw_sources"]],
        "packages": {p: importlib.metadata.version(p) for p in PACKAGES},
        "snapshot_files": inventory(snapshot),
    }
    write_json(study / "plan.json", plan)
    (study / "plan.sha256").write_text(digest(study / "plan.json") + "\n")
    print(f"Frozen study: {study}\nPending human recordings: {len(expected(plan))}")


def load_and_verify(study):
    if digest(study / "plan.json") != (study / "plan.sha256").read_text().strip():
        raise SystemExit("Study plan changed after freezing")
    plan = json.loads((study / "plan.json").read_text())
    actual = inventory(study / "snapshot")
    if actual != plan["snapshot_files"]:
        raise SystemExit(
            "Frozen source/assets changed; create a separately named study version"
        )
    for package, version in plan["packages"].items():
        if importlib.metadata.version(package) != version:
            raise SystemExit(
                f"Dependency version changed: {package}; expected {version}"
            )
    return plan


def environment(study):
    env = os.environ.copy()
    env.update(
        PYTHONPATH=os.pathsep.join(
            [str(study / "snapshot/src"), str(study / "snapshot/scripts")]
        ),
        PYTHONDONTWRITEBYTECODE="1",
        JAX_PLATFORMS="cpu",
        XDG_DATA_HOME=str(study / "snapshot/assets"),
    )
    return env


def inspect_recording(path, game, seed, plan):
    import numpy as np

    with np.load(path, allow_pickle=False) as raw:
        meta = json.loads(str(raw["meta_json"]))
        wanted = {
            "game": GAMES[game],
            "seed": seed,
            "record_mode": "play",
            "frameskip": 1,
            "repeat_action_probability": 0.0,
            "snapshot_phase": "post_action",
            "skip_frames": plan["warmup_frames"],
            "n_frames": plan["recorded_frames"],
            "has_frames": True,
        }
        for key, value in wanted.items():
            if meta.get(key) != value:
                raise ValueError(
                    f"{path.name}: {key}={meta.get(key)!r}, expected {value!r}"
                )
        if len(raw["actions"]) != plan["recorded_frames"] or raw["ram"].shape != (
            plan["recorded_frames"],
            128,
        ):
            raise ValueError(f"{path.name}: incomplete/malformed actions or RAM")
        if not meta.get("action_meanings") or raw["frames"].shape != (
            plan["recorded_frames"],
            210,
            160,
            3,
        ):
            raise ValueError(f"{path.name}: missing action meanings or RGB frames")
    sha = digest(path)
    if sha in plan["development_hashes"]:
        raise ValueError(f"Development recording reused: {path.name}")
    return {"file": path.name, "game": game, "seed": seed, "sha256": sha, "meta": meta}


def recordings(study, plan, *, complete=False):
    entries = []
    names = {name for _, _, name in expected(plan)}
    extra = {p.name for p in (study / "raw").glob("*.npz")} - names
    if extra:
        raise SystemExit(f"Unexpected recordings in held-out corpus: {sorted(extra)}")
    for game, seed, name in expected(plan):
        p = study / "raw" / name
        if p.exists():
            entries.append(inspect_recording(p, game, seed, plan))
        elif complete:
            raise SystemExit(f"Recording still missing: {name}")
    if len({e["sha256"] for e in entries}) != len(entries):
        raise SystemExit("Duplicate recordings in held-out corpus")
    return entries


def record(study, plan, args):
    if (study / "recordings.json").exists():
        raise SystemExit("Corpus is sealed; no further recordings can be added")
    recordings(study, plan)
    slots = [
        s
        for s in expected(plan)
        if not (study / "raw" / s[2]).exists()
        and (not args.games or s[0] in args.games)
        and (not args.seeds or s[1] in args.seeds)
    ]
    for game, seed, name in slots:
        print(
            f"{game}, seed {seed}: {plan['recorded_frames']} frames. {plan['scope'].get(game,'Play normally; retain mistakes and deaths.')}",
            flush=True,
        )
        if args.list:
            continue
        if not sys.stdin.isatty():
            raise SystemExit(
                "Human play needs an interactive terminal; use --list to preview the queue"
            )
        answer = input("Enter to record; q to stop this session: ").strip().lower()
        if answer == "q":
            return
        temporary = study / (name + ".partial.npz")
        cmd = [
            plan["python_executable"],
            "-B",
            str(study / "snapshot/scripts/oc_parity/record_ocatari.py"),
            "--game",
            GAMES[game],
            "--mode",
            "play",
            "--seed",
            str(seed),
            "--steps",
            str(plan["recorded_frames"]),
            "--skip-frames",
            str(plan["warmup_frames"]),
            "--fps",
            str(plan["playback_fps"]),
            "--out",
            str(temporary),
        ]
        result = subprocess.run(cmd, env=environment(study))
        try:
            if result.returncode:
                raise ValueError(f"Recorder exited {result.returncode}")
            inspect_recording(temporary, game, seed, plan)
        except ValueError as exc:
            incomplete = study / "incomplete"
            incomplete.mkdir(exist_ok=True)
            if temporary.exists():
                shutil.move(
                    temporary,
                    incomplete
                    / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f_") + name),
                )
            print(
                f"Incomplete attempt retained: {exc}. Resume this slot later.",
                flush=True,
            )
            return
        temporary.rename(study / "raw" / name)
        note = input(
            "Optional session note (e.g. level change; Enter for none): "
        ).strip()
        with (study / "recording_notes.jsonl").open("a") as f:
            f.write(json.dumps({"file": name, "note": note}) + "\n")
    print("Recording queue complete for this selection.")


def evaluate(study, plan):
    if not (study / "recordings.json").exists():
        raise SystemExit(
            "Record all planned clips and seal the corpus before evaluation"
        )
    now = recordings(study, plan, complete=True)
    if now != json.loads((study / "recordings.json").read_text()):
        raise SystemExit("Recordings changed after sealing")
    if (study / "evaluation").exists():
        raise SystemExit(
            "Evaluation output already exists; retain it as the first held-out evaluation"
        )
    cmd = [
        plan["python_executable"],
        "-B",
        str(study / "snapshot/scripts/oc_parity/audit_transfers.py"),
        "--corpus",
        str(study),
        "--out",
        str(study / "evaluation"),
        "--games",
        *plan["games"],
        "--n",
        str(plan["compared_frames"]),
        "--num-t0",
        str(plan["syncs_per_recording"]),
        "--seed",
        str(plan["sync_seed"]),
    ]
    (study / "evaluation").mkdir()
    with (study / "evaluation/command.json").open("w") as f:
        json.dump(cmd, f, indent=2)
    with (study / "evaluation/run.log").open("w") as log:
        result = subprocess.run(
            cmd, env=environment(study), stdout=log, stderr=subprocess.STDOUT
        )
    write_json(
        study / "evaluation/completion.json",
        {"returncode": result.returncode, "future_assisted": False},
    )
    print(
        f"Evaluation exit {result.returncode}; logs and all failures retained in {study/'evaluation'}"
    )
    if result.returncode:
        raise SystemExit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for command in ("init", "record", "status", "seal", "evaluate"):
        p = sub.add_parser(command)
        p.add_argument("--study", type=Path, required=True)
        if command == "init":
            p.add_argument("--games", nargs="+", choices=GAMES, default=list(GAMES))
            p.add_argument("--seeds", nargs="+", type=int, default=[1, 2, 3])
            p.add_argument("--steps", type=int, default=1600)
            p.add_argument("--skip-frames", type=int, default=100)
            p.add_argument("--fps", type=int, default=60)
        if command == "record":
            p.add_argument("--games", nargs="+", choices=GAMES)
            p.add_argument("--seeds", nargs="+", type=int)
            p.add_argument("--list", action="store_true")
    args = parser.parse_args()
    study = args.study.resolve()
    if args.command == "init":
        initialize(study, args)
        return
    plan = load_and_verify(study)
    if args.command == "record":
        record(study, plan, args)
    elif args.command == "status":
        entries = recordings(study, plan)
        print(
            f"{len(entries)}/{len(expected(plan))} complete recordings; sealed={(study/'recordings.json').exists()}"
        )
        for game in plan["games"]:
            print(
                f"  {game}: {sum(e['game']==game for e in entries)}/{len(plan['recording_seeds'])}"
            )
    elif args.command == "seal":
        entries = recordings(study, plan, complete=True)
        if (study / "recordings.json").exists() and json.loads(
            (study / "recordings.json").read_text()
        ) != entries:
            raise SystemExit("Sealed recordings changed")
        write_json(study / "recordings.json", entries)
        print(f"Sealed {len(entries)} fresh human-play recordings")
    else:
        evaluate(study, plan)


if __name__ == "__main__":
    main()
