import os
from functools import partial
from typing import Tuple, NamedTuple, Dict, Any
import jax
import jax.numpy as jnp
import chex
from flax import struct

import jaxtari.spaces as spaces
from jaxtari.environment import JaxEnvironment, JaxtariAction as Action, ObjectObservation
from jaxtari.renderers import JAXGameRenderer
import jaxtari.rendering.jax_rendering_utils as render_utils
from jaxtari.modification import AutoDerivedConstants

def _create_static_procedural_sprites() -> dict:
    """Creates procedural sprites that don't depend on dynamic values."""
    # Create procedural black background (same as original jr.create_initial_frame)
    black_bg = jnp.zeros((210, 160, 4), dtype=jnp.uint8)
    black_bg = black_bg.at[:, :, 3].set(255)  # Set alpha to 255
    return {
        'black_bg': black_bg,
    }

def _get_default_asset_config() -> tuple:
    """
    Returns the default declarative asset manifest for Turmoil.
    Kept immutable (tuple of dicts) to fit NamedTuple defaults.
    """
    static_procedural = _create_static_procedural_sprites()
    
    # A list of all 15 base enemy frames, to be padded together
    all_enemy_files = [
        'enemy/3lines/1.npy',         # 0
        'enemy/arrow/1.npy',          # 1
        'enemy/tank/1.npy',           # 2
        'enemy/tank/2.npy',           # 3
        'enemy/L/1.npy',              # 4
        'enemy/L/2.npy',              # 5
        'enemy/T/1.npy',              # 6
        'enemy/T/2.npy',              # 7
        'enemy/rocket/1.npy',         # 8
        'enemy/rocket/2.npy',         # 9
        'enemy/triangle_hollow/1.npy',# 10
        'enemy/x_shape/1.npy',        # 11
        'enemy/x_shape/2.npy',        # 12
        'enemy/boom/1.npy',            # 13
        'enemy/boom/2.npy',           # 14
    ]

    return (
        # Background - procedural black background (base layer)
        {'name': 'black_bg', 'type': 'background', 'data': static_procedural['black_bg']},

        # Game background sprite (drawn conditionally on top of black background)
        {'name': 'game_bg', 'type': 'single', 'file': 'bg/1.npy'},

        # Player
        {'name': 'player', 'type': 'single', 'file': 'player/1.npy'},
        {'name': 'bullet', 'type': 'single', 'file': 'player/bullet/1.npy'},
        {'name': 'player_shrink', 'type': 'group', 'files': [
            'player/shrink/1.npy', 'player/shrink/2.npy', 'player/shrink/3.npy',
            'player/shrink/4.npy', 'player/shrink/5.npy', 'player/shrink/6.npy'
        ]},

        # Enemies (All base frames in one group for uniform padding)
        {'name': 'all_enemies', 'type': 'group', 'files': all_enemy_files},

        # Explosion
        {'name': 'explosion_group', 'type': 'group', 'files': ['enemy/explosion/1.npy', 'enemy/explosion/2.npy']},

        # UI
        {'name': 'digits', 'type': 'digits', 'pattern': 'digits/{}.npy'},
    )

class TurmoilConstants(AutoDerivedConstants):
    # pre-defined movement lanes
    VERTICAL_LANE: int = struct.field(pytree_node=False, default=76) # x value
    HORIZONTAL_LANES: list[int] = struct.field(pytree_node=False, default_factory=lambda: [37, 58, 79, 100, 121, 142, 163]) # y values

    # boundaries
    MIN_BOUND: tuple[int, int] = struct.field(pytree_node=False, default=None) # (min x, min y)
    MAX_BOUND: tuple[int, int] = struct.field(pytree_node=False, default=None)

    # directions
    FACE_LEFT: int = struct.field(pytree_node=False, default=-1)
    FACE_RIGHT: int = struct.field(pytree_node=False, default=1)   

    # sizes
    HORIZONTAL_LANE_GAP_SIZE: int = struct.field(pytree_node=False, default=17)
    PLAYER_SIZE: tuple[int, int] = struct.field(pytree_node=False, default=(8, 11)) # (width, height)
    BULLET_SIZE: tuple[int, int] = struct.field(pytree_node=False, default=(8, 3))
    ENEMY_SIZE: jnp.ndarray = struct.field(pytree_node=False, default_factory=lambda: (
        (8, 5), # lines
        (8, 10), # arrow
        (8, 13), # tank
        (8, 11), # L
        (7, 13), # T
        (8, 7), # rocket
        (8, 13), # triangle_hollow
        (8, 11), # x_shape
        (4, 5), # sonic boom
    ))
    ENEMY_SIZE_FOR_COLLISION: tuple[int, int] = struct.field(pytree_node=False, default=(8, 13))  # max values from ENEMY_SIZE
    PRIZE_SIZE: tuple[int, int] = struct.field(pytree_node=False, default=(8, 9))
    ENEMY_EXPLOSION_SIZE: tuple[int, int] = struct.field(pytree_node=False, default=(8, 13))

    # y offsets for finding the middle of the lane for each sprite
    Y_OFFSET_PLAYER: tuple[int, int] = struct.field(pytree_node=False, default=None)
    Y_OFFSET_PRIZE: tuple[int, int] = struct.field(pytree_node=False, default=None)
    Y_OFFSET_ENEMY: tuple[int, int] = struct.field(pytree_node=False, default=None)
    Y_OFFSET_ENEMY_EXPLOSION: tuple[int, int] = struct.field(pytree_node=False, default=None)

    # player
    PLAYER_START_POS: tuple[int, int] = struct.field(pytree_node=False, default=None) # (starting_x_pos, starting_y_pos)
    PLAYER_STEP_COOLDOWN: tuple[int, int] = struct.field(pytree_node=False, default=(0, 5)) # (x cooldown, y cooldown)
    PLAYER_SPEED: tuple[int, int] = struct.field(pytree_node=False, default_factory=lambda: (1, 21)) # (x_step_size, y_step_size)
    PLAYER_X_LANE_MOVEMENT_BUFFER: int = struct.field(pytree_node=False, default=None) # +/- this amount from VERTICAL_LANE player can move vertically

    # bullet
    BULLET_SPEED: int = struct.field(pytree_node=False, default=5)

    # enemy types, so it is easier to identify by name
    ENEMY_TYPES: dict[str, int] = struct.field(pytree_node=False, default_factory=lambda: {
        "3lines" : 0,
        "arrow" : 1,
        "tank" : 2,
        "L" : 3,
        "T" : 4,
        "rocket" : 5,
        "triangle_hollow" : 6,
        "x_shape" : 7,
        "boom" : 8
    })

    ENEMY_SPEED: jnp.ndarray = struct.field(pytree_node=False, default_factory=lambda: (
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # lines
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # arrow
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # tank
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # L
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # T
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # rocket
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # triangle_hollow
        [1, 1, 1, 1, 2, 2, 2, 2, 3], # x_shape
        [5, 5, 5, 5, 7, 7, 7, 7, 9], # sonic boom
    ))

    ENEMY_LEFT_SPAWN_X: int = struct.field(pytree_node=False, default=3)
    ENEMY_RIGHT_SPAWN_X: int = struct.field(pytree_node=False, default=148)
    TANK_PUSH_BACK: int = struct.field(pytree_node=False, default=5) # tank displacement if shot from front
    ENEMY_EXPLOSION_SPEED: int = struct.field(pytree_node=False, default=1) # enemy explosion movement speed

    # probability of spawning when there is slot available for each level
    ENEMY_SPAWN_PROBABILITY: list[float] = struct.field(pytree_node=False, default_factory=lambda: [0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17])
    PRIZE_SPAWN_PROBABILITY: list[float] = struct.field(pytree_node=False, default_factory=lambda: [0.005, 0.007, 0.009, 0.011, 0.015, 0.017, 0.019, 0.021, 0.023])
    
    # prize
    PRIZE_TO_BOOM_TIME: int = struct.field(pytree_node=False, default=300)
    PRIZE_SCORE_REWARD: int = struct.field(pytree_node=False, default=800)
    PRIZE_TILL_TRIANGLE_HOLLOW_TIMER: int = struct.field(pytree_node=False, default=40)

    # game phases and control
    STEP_COUNTER: int = struct.field(pytree_node=False, default=1024)
    LOADING_GAME_PHASE_TIME: int = struct.field(pytree_node=False, default=50)
    PLAYER_SHRINK_TIME: int = struct.field(pytree_node=False, default=120)
    LVL_CHANGE_SCORES: jnp.ndarray = struct.field(pytree_node=False, default_factory=lambda: ( # lvl end scores
        5000,  # lvl 1
        10000, # lvl 2
        15000, # lvl 3
        20000, # lvl 4
        30000, # lvl 5
        40000, # lvl 6
        60000, # lvl 7
        80000, # lvl 8
        99999  # lvl 9
    ))
    BG_APPER_PROBABILITY: float = struct.field(pytree_node=False, default=0.4) # after lvl 4, prob. of seeing lanes
    
    # rendering
    WIDTH: int = struct.field(pytree_node=False, default=160)
    HEIGHT: int = struct.field(pytree_node=False, default=210)
    MAX_ENEMIES: int = struct.field(pytree_node=False, default=7)
    MAX_EXPLOSIONS: int = struct.field(pytree_node=False, default=7)

    # Asset config baked into constants (immutable default) for asset overrides
    ASSET_CONFIG: tuple[dict, ...] = struct.field(pytree_node=False, default=_get_default_asset_config())

    def compute_derived(self) -> dict[str, Any]:
        """Compute derived constants based on static fields."""

        y_offset_enemy = (
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[0][1]) // 2, # lines
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[1][1]) // 2, # arrow
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[2][1]) // 2, # tank
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[3][1]) // 2, # L
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[4][1]) // 2, # T
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[5][1]) // 2, # rocket
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[6][1]) // 2, # triangle_hollow
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[7][1]) // 2, # x_shape
            (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_SIZE[8][1]) // 2, # sonic boom
        )

        y_offset_player = (self.HORIZONTAL_LANE_GAP_SIZE - self.PLAYER_SIZE[1]) // 2

        return {
            'MIN_BOUND': (2, self.HORIZONTAL_LANES[0]),
            'MAX_BOUND': (150, self.HORIZONTAL_LANES[-1]),
            'Y_OFFSET_PLAYER': y_offset_player,
            'Y_OFFSET_PRIZE': (self.HORIZONTAL_LANE_GAP_SIZE - self.PRIZE_SIZE[1]) // 2,
            'Y_OFFSET_ENEMY': y_offset_enemy,
            'Y_OFFSET_ENEMY_EXPLOSION': (self.HORIZONTAL_LANE_GAP_SIZE - self.ENEMY_EXPLOSION_SIZE[1]) // 2,
            'PLAYER_START_POS': (self.VERTICAL_LANE, self.HORIZONTAL_LANES[6] + y_offset_player),
            'PLAYER_X_LANE_MOVEMENT_BUFFER': self.PLAYER_SIZE[1] // 2,
        }

@struct.dataclass
class TurmoilState:
    player_x: chex.Array
    player_y: chex.Array
    player_direction: chex.Array
    player_step_cooldown: chex.Array # (2,) x_cooldown, y_cooldown
    player_move_unlock: chex.Array # (2,) player to move when off center, cuase of prize
                                   # can_move, position (1 -> right, -1 -> left)
    player_shrink: chex.Array # if player is in shrink mode

    ships: chex.Array # maximum 6 ships
    score: chex.Array
    bullet: chex.Array # x, y, active, direction

    enemy: chex.Array # (7, 7) 7 lanes; 7 -> type (see constants), x, y, active, speed, direction, change_type_coordinate,
    enemy_explosion: chex.Array # (7, 4) -> x, y, active, direction

    prize: chex.Array # (6,) lane, x, y, active, boom_timer, direction
    spawn_triangle_hollow: chex.Array # (4,) spawn, counter, lane, direction

    game_phase: chex.Array # game phase 0-2
                           # 0 -> loading screen, 1 -> game, 2 -> player shrink
    game_phase_timer: chex.Array

    level: chex.Array # maximim lvl is 9
    step_counter: chex.Array
    rng_key: chex.PRNGKey

    bg_visible: chex.Array # if background is visible


@struct.dataclass
class TurmoilObservation:
    player: ObjectObservation
    enemies: ObjectObservation # n=7
    prize: ObjectObservation
    bullet: ObjectObservation
    
    ships: jnp.ndarray
    score: jnp.ndarray
    game_phase: jnp.ndarray
    level: jnp.ndarray

@struct.dataclass
class TurmoilInfo:
    step_counter: jnp.ndarray  # Current step count
    level: jnp.ndarray # current game level


class JaxTurmoil(JaxEnvironment[TurmoilState, TurmoilObservation, TurmoilInfo, TurmoilConstants]):
    # Minimal ALE action set (from scripts/action_space_helper.py)
    ACTION_SET: jnp.ndarray = jnp.array(
        [
            Action.NOOP,
            Action.FIRE,
            Action.UP,
            Action.RIGHT,
            Action.LEFT,
            Action.DOWN,
            Action.UPRIGHT,
            Action.UPLEFT,
            Action.DOWNRIGHT,
            Action.DOWNLEFT,
            Action.RIGHTFIRE,
            Action.LEFTFIRE,
        ],
        dtype=jnp.int32,
    )

    def __init__(self, consts: TurmoilConstants = None):
        consts = consts or TurmoilConstants()
        super().__init__(consts)
        self.renderer = TurmoilRenderer(self.consts)
    
    @partial(jax.jit, static_argnums=(0,))
    def render(self, state: TurmoilState) -> jnp.ndarray:
        """Render the game state to a raster image."""
        return self.renderer.render(state)

    def action_space(self) -> spaces.Discrete:
        return spaces.Discrete(len(self.ACTION_SET))
    
    def observation_space(self) -> spaces.Dict:
        c = self.consts
        h = int(c.HEIGHT)
        w = int(c.WIDTH)
        screen_size = (h, w)
        
        single_obj = spaces.get_object_space(n=None, screen_size=screen_size)
        
        return spaces.Dict({
            "player": single_obj,
            "enemies": spaces.get_object_space(n=c.MAX_ENEMIES, screen_size=screen_size),
            "prize": single_obj,
            "bullet": single_obj,
            "ships": spaces.Box(low=0, high=6, shape=(), dtype=jnp.int32),
            "score": spaces.Box(low=0, high=999999, shape=(), dtype=jnp.int32),
            "game_phase": spaces.Box(low=0, high=2, shape=(), dtype=jnp.int32),
            "level": spaces.Box(low=0, high=10, shape=(), dtype=jnp.int32),
        })

    def image_space(self) -> spaces.Box:
        """Returns the image space for Turmoil.
        The image is a RGB image with shape (210, 160, 3).
        """
        return spaces.Box(
            low=0,
            high=255,
            shape=(210, 160, 3),
            dtype=jnp.uint8
        )
    
    @partial(jax.jit, static_argnums=(0,))
    def _get_observation(self, state: TurmoilState) -> TurmoilObservation:
        c = self.consts
        w, h = int(c.WIDTH), int(c.HEIGHT)

        # --- Player ---
        # Direction: -1 (Left/270), 1 (Right/90)
        p_ori = jnp.where(state.player_direction == 1, 90.0, 270.0).astype(jnp.float32)
        
        player = ObjectObservation.create(
            x=jnp.clip(jnp.array(state.player_x, dtype=jnp.int32), 0, w),
            y=jnp.clip(jnp.array(state.player_y, dtype=jnp.int32), 0, h),
            width=jnp.array(c.PLAYER_SIZE[0], dtype=jnp.int32),
            height=jnp.array(c.PLAYER_SIZE[1], dtype=jnp.int32),
            active=jnp.array(1, dtype=jnp.int32),
            orientation=p_ori
        )

        # --- Enemies ---
        e = state.enemy
        # enemy array cols: 0:type, 1:x, 2:y, 3:active, 4:speed, 5:dir, 6:limit
        e_x = e[:, 1].astype(jnp.int32)
        e_y = e[:, 2].astype(jnp.int32)
        e_active = e[:, 3].astype(jnp.int32)
        e_type = e[:, 0].astype(jnp.int32)
        e_dir = e[:, 5].astype(jnp.int32)
        
        # Orientations
        e_ori = jnp.where(e_dir == 1, 90.0, 270.0).astype(jnp.float32)

        # Sizes lookup (vectorized?)
        # Enemy sizes are in constant list ENEMY_SIZE. 
        # Need to map e_type to size. 
        # ENEMY_SIZE_FOR_COLLISION is a single tuple (max size).
        # For visualization accuracy, we should map per type, but constant lookup in JIT is tricky if not array.
        # ENEMY_SIZE is a jnp array in constants! Good.
        sizes = jnp.take(jnp.asarray(c.ENEMY_SIZE), e_type, axis=0)
        
        enemies = ObjectObservation.create(
            x=jnp.clip(e_x, 0, w),
            y=jnp.clip(e_y, 0, h),
            width=sizes[:, 0].astype(jnp.int32),
            height=sizes[:, 1].astype(jnp.int32),
            active=e_active,
            visual_id=e_type,
            orientation=e_ori
        )

        # --- Prize ---
        # prize array: 0:lane, 1:x, 2:y, 3:active, 4:timer, 5:dir
        pr_active = state.prize[3].astype(jnp.int32)
        pr_x = state.prize[1].astype(jnp.int32)
        pr_y = state.prize[2].astype(jnp.int32)
        pr_dir = state.prize[5].astype(jnp.int32)
        pr_ori = jnp.where(pr_dir == 1, 90.0, 270.0).astype(jnp.float32)
        
        prize = ObjectObservation.create(
            x=jnp.clip(pr_x, 0, w),
            y=jnp.clip(pr_y, 0, h),
            width=jnp.array(c.PRIZE_SIZE[0], dtype=jnp.int32),
            height=jnp.array(c.PRIZE_SIZE[1], dtype=jnp.int32),
            active=pr_active,
            orientation=pr_ori
        )

        # --- Bullet ---
        # bullet array: 0:x, 1:y, 2:active, 3:dir
        b_active = (state.bullet[2] != 0).astype(jnp.int32)
        bullet = ObjectObservation.create(
            x=jnp.clip(state.bullet[0].astype(jnp.int32), 0, w),
            y=jnp.clip(state.bullet[1].astype(jnp.int32), 0, h),
            width=jnp.array(c.BULLET_SIZE[0], dtype=jnp.int32),
            height=jnp.array(c.BULLET_SIZE[1], dtype=jnp.int32),
            active=b_active,
            orientation=jnp.where(state.bullet[3] == 1, 90.0, 270.0).astype(jnp.float32)
        )

        return TurmoilObservation(
            player=player,
            enemies=enemies,
            prize=prize,
            bullet=bullet,
            ships=state.ships.astype(jnp.int32),
            score=state.score.astype(jnp.int32),
            game_phase=state.game_phase.astype(jnp.int32),
            level=state.level.astype(jnp.int32)
        )

    @partial(jax.jit, static_argnums=(0,))
    def _get_info(self, state: TurmoilState) -> TurmoilInfo:
        return TurmoilInfo(
            step_counter=state.step_counter,
            level=state.level,
        )

    @partial(jax.jit, static_argnums=(0,))
    def _get_reward(self, previous_state: TurmoilState, state: TurmoilState):
        return state.score - previous_state.score

    @partial(jax.jit, static_argnums=(0,))
    def _get_done(self, state: TurmoilState) -> bool:
        return jnp.logical_or(state.ships <= 0, state.level >= 10)

    @partial(jax.jit, static_argnums=(0,))
    def reset(self, key: jax.random.PRNGKey = jax.random.PRNGKey(42)) -> Tuple[TurmoilObservation, TurmoilState]:
        """Initialize game state"""
        reset_state = TurmoilState(
            player_x=jnp.array(self.consts.PLAYER_START_POS[0]),
            player_y=jnp.array(self.consts.PLAYER_START_POS[1]),
            player_direction=jnp.array(0),
            player_step_cooldown=jnp.zeros(2),
            player_move_unlock=jnp.zeros(2),
            player_shrink=jnp.array(0),
            ships=jnp.array(5),
            score=jnp.array(0),

            bullet=jnp.zeros(4),

            enemy=jnp.zeros((7, 7)),
            enemy_explosion=jnp.zeros((7, 4)),
            prize=jnp.zeros(6),
            spawn_triangle_hollow=jnp.zeros(4),

            game_phase=jnp.array(0),
            game_phase_timer=jnp.array(0),
            level=jnp.array(1),
            step_counter=jnp.array(0),
            rng_key=key,
            bg_visible=jnp.array(1),
        )

        initial_obs = self._get_observation(reset_state)
        return initial_obs, reset_state

    @partial(jax.jit, static_argnums=(0,))
    def player_step(
        self,
        state: TurmoilState,
        action: chex.Array
    ) -> tuple[chex.Array, chex.Array, chex.Array]:
        '''
        implement all the possible movement directions for the player, the mapping is:
        anything with left in it, add -2 to the x position
        anything with right in it, add 2 to the x position
        anything with up in it, add -2 to the y position
        anything with down in it, add 2 to the y position
        '''        
        up = jnp.any(
            jnp.array(
                [
                    action == Action.UP,
                    action == Action.UPRIGHT,
                    action == Action.UPLEFT,
                    action == Action.UPFIRE,
                    action == Action.UPRIGHTFIRE,
                    action == Action.UPLEFTFIRE,
                ]
            )
        )
        down = jnp.any(
            jnp.array(
                [
                    action == Action.DOWN,
                    action == Action.DOWNRIGHT,
                    action == Action.DOWNLEFT,
                    action == Action.DOWNFIRE,
                    action == Action.DOWNRIGHTFIRE,
                    action == Action.DOWNLEFTFIRE,
                ]
            )
        )
        left = jnp.any(
            jnp.array(
                [
                    action == Action.LEFT,
                    action == Action.UPLEFT,
                    action == Action.DOWNLEFT,
                    action == Action.LEFTFIRE,
                    action == Action.UPLEFTFIRE,
                    action == Action.DOWNLEFTFIRE,
                ]
            )
        )
        right = jnp.any(
            jnp.array(
                [
                    action == Action.RIGHT,
                    action == Action.UPRIGHT,
                    action == Action.DOWNRIGHT,
                    action == Action.RIGHTFIRE,
                    action == Action.UPRIGHTFIRE,
                    action == Action.DOWNRIGHTFIRE,
                ]
            )
        )

        def can_move_horizontal(state: TurmoilState) :
            return jnp.logical_or(
                jnp.logical_and(
                    state.prize[3] == 1, # prize active and player on same lane
                    state.player_y - self.consts.Y_OFFSET_PLAYER == state.prize[2] - self.consts.Y_OFFSET_PRIZE
                ),
                state.player_move_unlock[0] == 1
            )
        
        def can_move_vertical(player_x) :
            return jnp.logical_and(
                player_x >= self.consts.VERTICAL_LANE - self.consts.PLAYER_X_LANE_MOVEMENT_BUFFER,
                player_x <= self.consts.VERTICAL_LANE + self.consts.PLAYER_X_LANE_MOVEMENT_BUFFER,
            )
        
        # cooldown so player does not go too fast
        player_step_cooldown = jnp.where(
            state.player_step_cooldown > 0,
            state.player_step_cooldown - 1,
            0
        )

        # move player
        player_x = jnp.where(
            jnp.logical_and(player_step_cooldown[0] <= 0, can_move_horizontal(state)),
            jnp.where(
                right,
                state.player_x + self.consts.PLAYER_SPEED[0],
                jnp.where(
                    left,
                    state.player_x - self.consts.PLAYER_SPEED[0],
                    state.player_x
                )
            ),
            state.player_x
        )

        player_y = jnp.where(
            jnp.logical_and(player_step_cooldown[1] <= 0, can_move_vertical(player_x)),
            jnp.where(
                down,
                state.player_y + self.consts.PLAYER_SPEED[1],
                jnp.where(
                    up,
                    state.player_y - self.consts.PLAYER_SPEED[1],
                    state.player_y
                )
            ),
            state.player_y
        )

        # if moved vertical set player to VERTICAL_LANE
        moved_vertically = jnp.logical_and(
            jnp.logical_and(player_step_cooldown[1] <= 0, can_move_vertical(player_x)),
            jnp.logical_or(up, down)
        )

        player_x = jnp.where(
            moved_vertically,
            self.consts.VERTICAL_LANE,
            player_x
        )

        player_direction = jnp.where(
            right,
            1,
            jnp.where(
                left,
                -1,
                state.player_direction
            )
        )

        # right/left cooldown
        player_step_cooldown = player_step_cooldown.at[0].set(
            jnp.where(
                jnp.logical_and(
                    jnp.logical_or(left, right),
                    player_step_cooldown[0] <= 0 # if not already on cooldown
                ),
                self.consts.PLAYER_STEP_COOLDOWN[0],
                player_step_cooldown[0],
            )
        )

        # up/down cool down
        player_step_cooldown = player_step_cooldown.at[1].set(
            jnp.where(
                jnp.logical_and(
                    jnp.logical_or(up, down),
                    player_step_cooldown[1] <= 0
                ),
                self.consts.PLAYER_STEP_COOLDOWN[1],
                player_step_cooldown[1],
            )
        )

        # keep player in boundaries
        player_x = jnp.where(
            player_x <= self.consts.MIN_BOUND[0],
            self.consts.MIN_BOUND[0],
            jnp.where(
                player_x >= self.consts.MAX_BOUND[0],
                self.consts.MAX_BOUND[0],
                player_x,
            ),
        )

        player_y = jnp.where(
            player_y <= self.consts.MIN_BOUND[1],
            self.consts.MIN_BOUND[1] + self.consts.Y_OFFSET_PLAYER,
            jnp.where(
                player_y >= self.consts.MAX_BOUND[1],
                self.consts.MAX_BOUND[1] + self.consts.Y_OFFSET_PLAYER,
                player_y
            ),
        )

        # player can move horizontal, if off center
        new_player_move_unlock = jnp.where(
            jnp.logical_and(player_x != self.consts.VERTICAL_LANE, state.player_move_unlock[0] == 0),
            jnp.array([
                1,
                jnp.where(
                    player_x - self.consts.VERTICAL_LANE > 0,
                    1,
                    -1
                )
                
            ]),
            state.player_move_unlock
        )
    
        passed_vertical_lane = jnp.logical_or(
            jnp.logical_and(new_player_move_unlock[1] == 1, player_x <= self.consts.VERTICAL_LANE),
            jnp.logical_and(new_player_move_unlock[1] == -1, player_x >= self.consts.VERTICAL_LANE)
        )

        # player snaps to vertical lane 
        player_x = jnp.where(
            jnp.logical_and(passed_vertical_lane, new_player_move_unlock[0] == 1),
            self.consts.VERTICAL_LANE,
            player_x
        )

        # reset the lock
        new_player_move_unlock = jnp.where(
            jnp.logical_or(new_player_move_unlock[0] == 0, passed_vertical_lane),
            jnp.array([0, 0]),
            new_player_move_unlock
        )

        return player_x, player_y, player_direction, player_step_cooldown, new_player_move_unlock


    @partial(jax.jit, static_argnums=(0,))
    def bullet_step(
        self,
        state: TurmoilState,
        action: chex.Array,
    ) -> chex.Array:
        fire = jnp.any(
            jnp.array(
                [
                    action == Action.FIRE,
                    action == Action.UPRIGHTFIRE,
                    action == Action.UPLEFTFIRE,
                    action == Action.DOWNFIRE,
                    action == Action.DOWNRIGHTFIRE,
                    action == Action.DOWNLEFTFIRE,
                    action == Action.RIGHTFIRE,
                    action == Action.LEFTFIRE,
                    action == Action.UPFIRE,
                ]
            )
        )

        same_lane_as_prize = jnp.logical_and(
            state.player_y - self.consts.Y_OFFSET_PLAYER == state.prize[2] - self.consts.Y_OFFSET_PRIZE,
            state.prize[3] == 1 # prize is active
        )

        # if player fired and there is no active bullet, create on in player_direction
        new_bullet = jnp.where(
            jnp.logical_and(
                jnp.logical_and(jnp.logical_and(fire, jnp.logical_not(state.bullet[2])), jnp.logical_not(state.game_phase == 2)),
                jnp.logical_not(same_lane_as_prize)
            ),
            jnp.where(
                state.player_direction == -1,
                jnp.array([
                    state.player_x, # x, y, active, direction
                    state.player_y + self.consts.PLAYER_SIZE[1] // 2 - 1,
                    1,
                    -1
                ]),
                jnp.array([
                    state.player_x,
                    state.player_y + self.consts.PLAYER_SIZE[1] // 2 - 1,
                    1,
                    1
                ]),
            ),
            state.bullet,
        )

        # check if the new positions are in bounds, else destroy
        new_bullet = jnp.where(
            new_bullet[0] < self.consts.MIN_BOUND[0] - 2,
            jnp.array([0, 0, 0, 0]),
            jnp.where(
                new_bullet[0] > self.consts.MAX_BOUND[0] + self.consts.BULLET_SIZE[0] + 2,
                jnp.array([0, 0, 0, 0]),
                new_bullet
            ),
        )

        # if a bullet, we move the bullet further
        new_bullet = jnp.where(
            state.bullet[2],
            jnp.array([
                new_bullet[0] + new_bullet[3] * self.consts.BULLET_SPEED, # bullet speed
                new_bullet[1],
                new_bullet[2],
                new_bullet[3]
            ]),
            new_bullet,
        )

        # if bullet not active reset
        new_bullet = jnp.where(
            new_bullet[2] == 0,
            jnp.zeros_like(new_bullet),
            new_bullet
        )

        return new_bullet
    
    @partial(jax.jit, static_argnums=(0,))
    def prize_step(self, state: TurmoilState) -> chex.Array :
        """
        spawn a prize
        """
        def spawn(state: TurmoilState, rng_in) :
            rng_rest, if_spawn, _, lane, direction = self.spawn_data(
                rng_in,
                state,
                jnp.take(
                    jnp.array(self.consts.PRIZE_SPAWN_PROBABILITY),
                    state.level - 1
                ),
                0,
            )

            new_prize = jnp.where(
                if_spawn,
                jnp.array([
                    lane,
                    jnp.where(
                        direction == 1,
                        self.consts.ENEMY_LEFT_SPAWN_X,
                        self.consts.ENEMY_RIGHT_SPAWN_X
                    ), # X
                    jnp.take(jnp.array(self.consts.HORIZONTAL_LANES), lane) + self.consts.Y_OFFSET_PRIZE, #Y
                    1, # active
                    self.consts.PRIZE_TO_BOOM_TIME, # boom_timer
                    direction
                ]),
                state.prize
            )

            return new_prize, rng_rest

        # spawn new prize
        new_prize, rng_rest = jax.lax.cond(
            jnp.logical_and(state.prize[3] == 0, jnp.logical_not(state.game_phase == 2)),
            lambda : spawn(state, state.rng_key),
            lambda : (state.prize, state.rng_key),
        )

        # reduce boom_timer
        new_prize = new_prize.at[4].set(
            jnp.where(
                new_prize[3],
                new_prize[4] - 1,
                new_prize[4]
            )
        )

        return new_prize, rng_rest

    @partial(jax.jit, static_argnums=(0,))
    def spawn_data(self, rng: chex.PRNGKey, state: TurmoilState, spawn_prob: float = 1, for_enemy = 1):
        """
        Returns (new_rng, if_spawn, enemy_type, lane, direction).
        spawn_prob [0,1] controls probability of spawning when slots are available.
        """
        enemy_active_mask = (state.enemy[:, 3] == 1)
        enemy_explosion_mask = (state.enemy_explosion[:, 2] == 1)

        prize_lane_mask = (jnp.arange(7) == state.prize[0]) & (state.prize[3] == 1)

        triangle_hollow_lane_mask = (
            (jnp.arange(7) == state.spawn_triangle_hollow[2])
            & (state.spawn_triangle_hollow[0] == 1)
        )

        inactive_mask = jnp.logical_not(
            enemy_active_mask | prize_lane_mask | triangle_hollow_lane_mask | enemy_explosion_mask
        )

        num_inactive = jnp.sum(inactive_mask)

        def no_spawn(rng_in):
            return (
                rng_in,
                jnp.array(0, jnp.int32),
                jnp.array(0, jnp.int32),
                jnp.array(0, jnp.int32),
                jnp.array(0, jnp.int32),
            )

        def spawn(rng_in):
            rng_rest, type_key, lane_key, dir_key = jax.random.split(rng_in, 4)

            inactive_indices = jnp.nonzero(inactive_mask, size=state.enemy.shape[0])[0]
            lane_idx = jax.random.randint(lane_key, (), 0, num_inactive)
            lane = jax.lax.dynamic_index_in_dim(inactive_indices, lane_idx, keepdims=False)

            enemy_type = jax.random.choice(type_key, jnp.array([0, 1, 3, 4, 5, 6, 7]))
            direction = jax.random.choice(dir_key, jnp.array([-1, 1]))

            return (
                rng_rest,
                jnp.array(1, jnp.int32),
                enemy_type.astype(jnp.int32),
                lane.astype(jnp.int32),
                direction.astype(jnp.int32),
            )

        def maybe_spawn(rng_in):
            rng_in, gate_key = jax.random.split(rng_in)
            do_spawn = jax.random.bernoulli(gate_key, p=spawn_prob)
            return jax.lax.cond(do_spawn, spawn, no_spawn, rng_in)
        
        def spawn_triangle_hollow_after_prize() :
            return (
                rng,
                jnp.array(1, jnp.int32),
                jnp.array(6, jnp.int32),
                jnp.array(state.spawn_triangle_hollow[2], jnp.int32),
                jnp.array(state.spawn_triangle_hollow[3], jnp.int32),
            )


        return jax.lax.cond(
            jnp.logical_and(
                for_enemy == 1,
                jnp.logical_and( # should spawn trinagle hollow in pre-defined lane
                    state.spawn_triangle_hollow[0] == 1,
                    jnp.mod(state.step_counter - state.spawn_triangle_hollow[1],
                            self.consts.STEP_COUNTER) >= self.consts.PRIZE_TILL_TRIANGLE_HOLLOW_TIMER
                )
            ),
            spawn_triangle_hollow_after_prize,
            lambda: jax.lax.cond(
                num_inactive == 0,
                no_spawn,
                maybe_spawn,
                rng
            ),
        )



    @partial(jax.jit, static_argnums=(0,))
    def change_type(self, state: TurmoilState):
        """
        Change type of arrow -> tank or pize -> sonic_boom
        """

        def change_arrow(enemy) :
            """
            change arrow to tank if timer has run out
            """
            arrow_lanes = enemy[:, 0] == 1
            arrow_reached_change_coordinate = enemy[:, 1] == enemy[:, 6]
            change_to_tank = arrow_lanes & arrow_reached_change_coordinate

            # new type
            new_type = jnp.where(
                change_to_tank,
                2,
                enemy[:, 0]
            )
            
            # new direction
            new_direction = jnp.where(
                change_to_tank,
                jnp.where(
                    enemy[:, 5] == 1,
                    -1,
                    1
                ),
                enemy[:, 5]
            )

            # new change_type_coordinate
            new_change_type_coordinate = jnp.where(
                new_direction == 1,
                self.consts.ENEMY_RIGHT_SPAWN_X,
                self.consts.ENEMY_LEFT_SPAWN_X
            )

            # update x
            new_y = jnp.where(
                change_to_tank, # remove arrow offset and add tank offset
                enemy[:, 2] - jnp.take(jnp.array(self.consts.Y_OFFSET_ENEMY), 1) + jnp.take(jnp.array(self.consts.Y_OFFSET_ENEMY), 2),
                enemy[:, 2]
            )

            # update enemy
            new_enemy = enemy.at[:, 0].set(new_type)
            new_enemy = new_enemy.at[:, 5].set(new_direction)
            new_enemy = new_enemy.at[:, 6].set(new_change_type_coordinate)
            new_enemy = new_enemy.at[:, 2].set(new_y)

            return new_enemy

        def change_prize(enemy, prize) :
            """
            change prize to sonic boom if timer has run out
            """
            # change active
            new_prize = prize.at[3].set(
                jnp.where(
                    jnp.logical_and(state.prize[3], state.prize[4] == 0),
                    0,
                    state.prize[3]
                )
            )
            
            # spawn sonic boom
            new_enemy = jnp.where(
                jnp.logical_and(state.prize[3], state.prize[4] == 0),
                enemy.at[state.prize[0].astype(jnp.int32)].set(
                    jnp.array([
                        8, # type sonic boom
                        state.prize[1], # x
                        state.prize[2] - self.consts.Y_OFFSET_PRIZE + jnp.take(jnp.array(self.consts.Y_OFFSET_ENEMY), 8), # y
                        1, # active
                        jnp.take(
                            jnp.take(jnp.array(self.consts.ENEMY_SPEED), 8, axis=0),
                            state.level - 1
                        ), # speed
                        state.prize[5], # direction
                        jnp.where( # change_type_coordiante
                            state.prize[5] == 1,
                            self.consts.ENEMY_RIGHT_SPAWN_X,
                            self.consts.ENEMY_LEFT_SPAWN_X
                        ),
                    ])
                ),
                enemy
            )

            return new_enemy, new_prize
        
        new_enemy = change_arrow(state.enemy)
        new_enemy, new_prize = change_prize(new_enemy, state.prize)

        return new_enemy, new_prize


    @partial(jax.jit, static_argnums=(0,))
    def enemy_spawn_step(self, state: TurmoilState) -> chex.Array :
        """
        Checks if it should spawn an enemy, if yes, spawns one.
        Decides type, position, direction and speed of enemy.
        """

        def spawn_fn(in_state, enemy_type, lane, direction) -> chex.Array :
            """
            Spawns enemy with given data for given state.

            Args:
               state, enemy_type, lane, direction
            """
            return in_state.enemy.at[lane].set(
                jnp.array([
                    enemy_type,
                    jnp.where(
                        direction == 1,
                        self.consts.ENEMY_LEFT_SPAWN_X,
                        self.consts.ENEMY_RIGHT_SPAWN_X
                    ), # X
                    jnp.take(jnp.array(self.consts.HORIZONTAL_LANES), lane) + jnp.take(jnp.array(self.consts.Y_OFFSET_ENEMY), enemy_type), #Y
                    1, # active
                    jnp.take(
                        jnp.take(jnp.array(self.consts.ENEMY_SPEED), enemy_type, axis=0),
                        state.level - 1
                    ), # speed
                    direction,
                    jnp.where( # change_type_coordiante
                        direction == 1,
                        self.consts.ENEMY_RIGHT_SPAWN_X,
                        self.consts.ENEMY_LEFT_SPAWN_X
                    ),
                ])
            )

        # get spawn data           
        rng_rest, if_spawn, enemy_type, lane, direction = self.spawn_data(
            state.rng_key,
            state,
            jnp.take(
                jnp.array(self.consts.ENEMY_SPAWN_PROBABILITY),
                state.level - 1
            ),
            1,
        )

        # spawn
        new_enemy = jax.lax.cond(
            if_spawn,
            lambda : spawn_fn(state, enemy_type, lane, direction),
            lambda : state.enemy,
        )

        # disable spawn_triangle_hollow
        should_spawn_triangle_hollow = jnp.logical_and(
            state.spawn_triangle_hollow[0] == 1,
            jnp.mod(state.step_counter - state.spawn_triangle_hollow[1],
                    self.consts.STEP_COUNTER) >= self.consts.PRIZE_TILL_TRIANGLE_HOLLOW_TIMER
        )

        new_spawn_triangle_hollow = jnp.where(
            should_spawn_triangle_hollow,
            jnp.zeros_like(state.spawn_triangle_hollow),
            state.spawn_triangle_hollow
        )

        return rng_rest, new_enemy, new_spawn_triangle_hollow


    @partial(jax.jit, static_argnums=(0,))
    def enemy_step(self, state: TurmoilState) :
        # move enemy
        new_enemy = state.enemy.at[:, 1].set(
            jnp.where(
                state.enemy[:, 3] == 1,
                state.enemy[:, 1] + state.enemy[:, 4] * state.enemy[:, 5],
                state.enemy[:, 1]
            )
        )

        # if tank or sonic_boom flip them back
        flip = jnp.logical_and(
            jnp.logical_or(
                new_enemy[:, 0] == 2, # type check
                new_enemy[:, 0] == 8
            ),
            (new_enemy[:, 1] - new_enemy[:, 6]) * new_enemy[:, 5] >= 0 # reached change type
        )

        ## set new direction
        new_enemy = new_enemy.at[:, 5].set(
            jnp.where(
                flip,
                -1 * new_enemy[:, 5],
                new_enemy[:, 5]
            )
        )

        ## set new change_type_coordinate
        new_enemy = new_enemy.at[:, 6].set(
            jnp.where(
                new_enemy[:, 5] == 1,
                self.consts.ENEMY_RIGHT_SPAWN_X,
                self.consts.ENEMY_LEFT_SPAWN_X
            )
        )

        # deactivate if out of bounds
        new_enemy = new_enemy.at[:, 3].set(
            jnp.where(
                jnp.logical_or(
                    new_enemy[:, 1] > self.consts.MAX_BOUND[0] + self.consts.ENEMY_SIZE_FOR_COLLISION[0],
                    new_enemy[:, 1] < self.consts.MIN_BOUND[0]
                ),
                0,
                new_enemy[:, 3]
            )
        )

        return new_enemy

    @partial(jax.jit, static_argnums=(0,))
    def update_score(self, state: TurmoilState, enemy_type) :
        new_score = jax.lax.switch(
            enemy_type,
            [
                lambda : state.score + 10,  # lines
                lambda : state.score + 100, # arrow
                lambda : state.score + 50,  # tank
                lambda : state.score + 40,  # L
                lambda : state.score + 60,  # T
                lambda : state.score + 30,  # rocket
                lambda : state.score,       # triangle_hollow
                lambda : state.score + 20,  # x_shape
                lambda : state.score + 100, # sonic_boom
            ]
        )

        return new_score
    
    @partial(jax.jit, static_argnums=(0,))
    def check_collision_single(self, pos1, size1, pos2, size2):
        """Check collision between two single entities"""
        # Calculate edges for rectangle 1
        rect1_left = pos1[0]
        rect1_right = pos1[0] + size1[0]
        rect1_top = pos1[1]
        rect1_bottom = pos1[1] + size1[1]

        # Calculate edges for rectangle 2
        rect2_left = pos2[0]
        rect2_right = pos2[0] + size2[0]
        rect2_top = pos2[1]
        rect2_bottom = pos2[1] + size2[1]

        # Check overlap
        horizontal_overlap = jnp.logical_and(
            rect1_left < rect2_right,
            rect1_right > rect2_left
        )

        vertical_overlap = jnp.logical_and(
            rect1_top < rect2_bottom,
            rect1_bottom > rect2_top
        )

        return jnp.logical_and(horizontal_overlap, vertical_overlap)

    @partial(jax.jit, static_argnums=(0,))
    def check_collision_batch(self, pos1, size1, pos2_array, size2):
        """Check collision between one entity and an array of entities"""
        # Calculate edges for rectangle 1
        rect1_left = pos1[0]
        rect1_right = pos1[0] + size1[0]
        rect1_top = pos1[1]
        rect1_bottom = pos1[1] + size1[1]

        # Calculate edges for all rectangles in pos2_array
        rect2_left = pos2_array[:, 0]
        rect2_right = pos2_array[:, 0] + size2[0]
        rect2_top = pos2_array[:, 1]
        rect2_bottom = pos2_array[:, 1] + size2[1]

        # Check overlap for all entities
        horizontal_overlaps = jnp.logical_and(
            rect1_left < rect2_right,
            rect1_right > rect2_left
        )

        vertical_overlaps = jnp.logical_and(
            rect1_top < rect2_bottom,
            rect1_bottom > rect2_top
        )

        # Combine checks for each entity
        collisions = jnp.logical_and(horizontal_overlaps, vertical_overlaps)

        return collisions
    
    
    @partial(jax.jit, static_argnums=(0,))
    def bullet_enemy_collision_step(self, state: TurmoilState):
        """
        Find collision of bullets with enemies and deactivate both
        in case of collision.
        Special rules:
            - triangle_hollow: no collision
            - tank: if same direction as bullet (shot from back) -> normal collision
                    if opposite direction as bullet (shot from front) -> bullet destroyed, enemy pushed back
        """
        bullet_pos = jnp.array([state.bullet[0], state.bullet[1]])
        bullet_size = self.consts.BULLET_SIZE

        enemy_pos = state.enemy[:, 1:3]
        enemy_active = state.enemy[:, 3]
        enemy_type = state.enemy[:, 0].astype(jnp.int32)
        enemy_dir = state.enemy[:, 5]
        enemy_size = self.consts.ENEMY_SIZE_FOR_COLLISION

        # mask inactive enemies
        active_enemy_pos = jnp.where(enemy_active[:, None] == 1, enemy_pos, -9999)

        # batch collision
        hit = self.check_collision_batch(bullet_pos, bullet_size, active_enemy_pos, enemy_size)

        # index of first hit
        hit_idx = jnp.argmax(jnp.where(hit, 1, 0))
        hit_type = jnp.where(jnp.any(hit), enemy_type[hit_idx], 0)


        def handle_triangle_hollow():
            # ignore collision, keep state
            return state.bullet, state.enemy, state.score, state.enemy_explosion

        def handle_tank():
            same_direction = enemy_dir[hit_idx] == state.bullet[3]

            def same_case():
                # full collision like normal
                new_enemy = state.enemy.at[hit_idx, 3].set(0)
                new_bullet = state.bullet.at[2].set(0)
                new_score = self.update_score(state, hit_type)

                # set explosion
                new_enemy_explosion = state.enemy_explosion.at[hit_idx].set(
                    jnp.array([
                        state.enemy[hit_idx, 1], # x
                        state.enemy[hit_idx, 2] - jnp.take(jnp.array(self.consts.Y_OFFSET_ENEMY), hit_type) + self.consts.Y_OFFSET_ENEMY_EXPLOSION, # y
                        1, # active
                        jnp.where(
                            jnp.abs(
                                state.enemy[hit_idx, 1] - self.consts.MIN_BOUND[0]
                            ) >= jnp.abs(
                                state.enemy[hit_idx, 1] - self.consts.MAX_BOUND[0]
                            ),
                            1,
                            -1
                        ), # direction
                    ])
                )

                return new_bullet, new_enemy, new_score, new_enemy_explosion

            def opposite_case():
                # bullet destroyed, enemy pushed back
                new_bullet = state.bullet.at[2].set(0)
                new_enemy = state.enemy.at[hit_idx, 1].add(
                    self.consts.TANK_PUSH_BACK * state.bullet[3]
                )
                return new_bullet, new_enemy, state.score, state.enemy_explosion

            return jax.lax.cond(same_direction, same_case, opposite_case)

        def handle_normal():
            new_enemy = jnp.where(
                state.bullet[2] == 1,
                state.enemy.at[:, 3].set(jnp.where(hit, 0, enemy_active)),
                state.enemy
            )
            new_bullet = jnp.where(
                state.bullet[2] == 1,
                state.bullet.at[2].set(jnp.where(jnp.any(hit), 0, state.bullet[2])),
                state.bullet
            )
            new_score = jax.lax.cond(
                jnp.any(hit),
                lambda: self.update_score(state, hit_type),
                lambda: state.score,
            )

            # set explosion
            new_enemy_explosion = state.enemy_explosion.at[hit_idx].set(
                jnp.array([
                    state.enemy[hit_idx, 1], # x
                    state.enemy[hit_idx, 2] - jnp.take(jnp.array(self.consts.Y_OFFSET_ENEMY), hit_type) + self.consts.Y_OFFSET_ENEMY_EXPLOSION, # y
                    1, # active
                    jnp.where(
                        jnp.abs(
                            state.enemy[hit_idx, 1] - self.consts.MIN_BOUND[0]
                        ) >= jnp.abs(
                            state.enemy[hit_idx, 1] - self.consts.MAX_BOUND[0]
                        ),
                        1,
                        -1
                    ), # direction
                ])
            )

            return new_bullet, new_enemy, new_score, new_enemy_explosion


        def handle_no_hit():
            return state.bullet, state.enemy, state.score, state.enemy_explosion

        return jax.lax.switch(
            jnp.where(jnp.any(hit), hit_type, 9),
            [
                handle_normal,  # lines
                handle_normal,  # arrow
                handle_tank,    # tank
                handle_normal,  # L
                handle_normal,  # T
                handle_normal,  # rocket
                handle_triangle_hollow,   # triangle_hollow
                handle_normal,  # x_shape
                handle_normal,  # sonic boom
                handle_no_hit,  # no hit case
            ],
        )


    @partial(jax.jit, static_argnums=(0,))
    def check_player_enemy_collision(self, state: TurmoilState) :
        # player rectangle
        player_pos = jnp.array([state.player_x, state.player_y])
        player_size = self.consts.PLAYER_SIZE

        enemy_pos = state.enemy[:, 1:3]   # take x, y columns
        enemy_active = state.enemy[:, 3]  # active flag
        enemy_size = self.consts.ENEMY_SIZE_FOR_COLLISION

        # mask inactive enemies
        active_enemy_pos = jnp.where(enemy_active[:, None] == 1, enemy_pos, -9999)

        # check collisions
        collisions = self.check_collision_batch(player_pos, player_size, active_enemy_pos, enemy_size)

        any_collision = jnp.any(collisions)

        # mark collided enemy inactive
        new_enemy_active = jnp.where(
            collisions,
            0,
            enemy_active
        )

        new_enemy = state.enemy.at[:, 3].set(new_enemy_active)

        new_ships = state.ships - any_collision.astype(jnp.int32)

        new_player_shrink = jnp.where(
            any_collision,
            1,
            state.player_shrink
        )

        return new_player_shrink, new_ships, new_enemy


    @partial(jax.jit, static_argnums=(0,))
    def prize_player_collision_step(self, state: TurmoilState):
        """
        Check player collision with prize
        """
        player_pos = jnp.array([state.player_x, state.player_y])
        
        # check collision
        collision = self.check_collision_single(
            player_pos,
            self.consts.PLAYER_SIZE, 
            jnp.array([state.prize[1], state.prize[2]]),
            self.consts.PRIZE_SIZE,
        )

        new_prize = jnp.where(
            collision,
            jnp.zeros_like(state.prize),
            state.prize,
        )

        new_score = jnp.where(
            collision,
            state.score + self.consts.PRIZE_SCORE_REWARD,
            state.score
        )

        # set spawn_triangle_hollow
        new_spawn_triangle_hollow = jnp.where(
            collision,
            jnp.array([1, state.step_counter, state.prize[0], state.prize[5] * -1]),
            state.spawn_triangle_hollow
        )

        return new_prize, new_score, new_spawn_triangle_hollow

    @partial(jax.jit, static_argnums=(0,))
    def game_control(self, state: TurmoilState) :
        """
        controls game phases
        """
        new_game_phase, new_game_phase_timer = state.game_phase, state.game_phase_timer + 1
        new_player_shrink, new_player_x = state.player_shrink, state.player_x

        def stay():
            return new_game_phase, new_game_phase_timer, new_player_shrink, new_player_x

        def to_loading():
            return (
                jnp.array(0),
                jnp.array(0),
                jnp.array(0),
                self.consts.PLAYER_START_POS[0],
            )

        def to_game():
            return (
                jnp.array(1),
                jnp.array(0),
                jnp.array(0),
                self.consts.PLAYER_START_POS[0],
            )
        
        def to_shrink_animation() :
            return (
                jnp.array(2),
                jnp.array(0),
                jnp.array(0),
                new_player_x,
            )
        
        return jax.lax.switch(
            new_game_phase,
            [
                # 0: show current lvl and colorful background 
                lambda: jax.lax.cond(
                    new_game_phase_timer >= self.consts.LOADING_GAME_PHASE_TIME,
                    to_game,
                    stay
                ),
                # 1: game
                lambda: jax.lax.cond(
                    state.player_shrink == 1,
                    lambda : to_shrink_animation(),
                    lambda : jax.lax.cond(
                        state.score >= jnp.take(jnp.array(self.consts.LVL_CHANGE_SCORES), state.level - 1),
                        lambda : to_loading(),
                        lambda : stay(),
                    ),
                ),
                # 2: animation for player shrinking
                lambda: jax.lax.cond(
                    new_game_phase_timer >= self.consts.PLAYER_SHRINK_TIME, 
                    to_game,
                    stay
                ),
            ],
        )
    

    @partial(jax.jit, static_argnums=(0,))
    def enemy_explosion_step(self, state: TurmoilState):
        """
        Moves explosion sprites and deactivates them if out of bounds.
        """
        new_enemy_explosion = state.enemy_explosion

        # move explosions
        new_enemy_explosion = new_enemy_explosion.at[:, 0].add(
            self.consts.ENEMY_EXPLOSION_SPEED * new_enemy_explosion[:, 3]
        )

        # deactivate if out of bounds
        new_enemy_explosion = new_enemy_explosion.at[:, 2].set(
            jnp.where(
                jnp.logical_or(
                    new_enemy_explosion[:, 0] > self.consts.MAX_BOUND[0],
                    new_enemy_explosion[:, 0] < self.consts.MIN_BOUND[0]
                ),
                0,
                new_enemy_explosion[:, 2]
            )
        )

        return new_enemy_explosion


    @partial(jax.jit, static_argnums=(0,))
    def next_level(self, state: TurmoilState) :
        """
        move to next level
        """
        level_complete = state.score >= jnp.take(jnp.array(self.consts.LVL_CHANGE_SCORES), state.level - 1)

        # if bg is visible next level
        rng_rest, bg_key = jax.random.split(state.rng_key)
        next_bg_visible = jax.lax.cond(
            state.level + 1 < 4,
            lambda : 1,
            lambda : jax.random.bernoulli(bg_key, p=self.consts.BG_APPER_PROBABILITY).astype(jnp.int32)
        )

        next_state = state.replace(
            player_x=jnp.array(self.consts.PLAYER_START_POS[0]),
            player_y=jnp.array(self.consts.PLAYER_START_POS[1]),
            player_direction=jnp.array(0),
            player_step_cooldown=jnp.zeros(2),
            player_move_unlock=jnp.zeros(2),
            player_shrink=jnp.array(0),
            ships=jnp.where(
                state.ships + 1 <= 7,
                state.ships + 1,
                state.ships
            ),
            score=state.score,

            bullet=jnp.zeros(4),

            enemy=jnp.zeros((7, 7)),
            enemy_explosion=jnp.zeros((7, 4)),

            prize=jnp.zeros(6),
            spawn_triangle_hollow=jnp.zeros(4),

            game_phase=state.game_phase,
            game_phase_timer=state.game_phase_timer,
            level=state.level + 1,
            step_counter=jnp.array(0),
            rng_key=rng_rest,
            bg_visible=next_bg_visible,
        )

        new_state = jax.lax.cond(
            level_complete,
            lambda: next_state,
            lambda: state
        )

        return new_state

    @partial(jax.jit, static_argnums=(0,))
    def _normal_game_step(self, state: TurmoilState, action: chex.Array) :
        """
        normal game step for playing
        """
        # player movement
        new_player_x, new_player_y, new_player_direction, new_player_step_cooldown, new_player_move_unlock= self.player_step(
            state,
            action
        )

        new_state = state.replace(
            player_x=new_player_x,
            player_y=new_player_y,
            player_direction=new_player_direction,
            player_step_cooldown=new_player_step_cooldown,
            player_move_unlock=new_player_move_unlock,
        )

        # player collision
        new_player_shrink, new_ships, new_enemy = self.check_player_enemy_collision(
            new_state
        )

        new_state = new_state.replace(
            player_shrink=new_player_shrink,
            ships=new_ships, 
            enemy=new_enemy,
        )

        # bullet
        new_bullet = self.bullet_step(
            new_state,
            action
        )

        new_state = new_state.replace(
            bullet=new_bullet
        )

        # bullet enemy collision
        new_bullet, new_enemy, new_score, new_enemy_explosion = self.bullet_enemy_collision_step(
            new_state
        )
        
        new_state = new_state.replace(
            bullet=new_bullet,
            enemy=new_enemy,
            score=new_score,
            enemy_explosion=new_enemy_explosion,
        )
        
        # enemy
        new_enemy = self.enemy_step(
            new_state,
        )

        new_state = new_state.replace(
            enemy=new_enemy
        )

        # move enemy explosion
        new_enemy_explosion = self.enemy_explosion_step(
            new_state    
        )

        new_state = new_state.replace(
            enemy_explosion=new_enemy_explosion,
        )

        # spawn enemies
        new_rng, new_enemy, new_spawn_triangle_hollow = self.enemy_spawn_step(
            new_state
        )

        new_state = new_state.replace(
            enemy=new_enemy,
            rng_key=new_rng,
            spawn_triangle_hollow=new_spawn_triangle_hollow,
        )

        # change types
        new_enemy, new_prize = self.change_type(new_state)
        
        new_state = new_state.replace(
            enemy=new_enemy,
            prize=new_prize
        )

        # increment step_counter
        new_step_counter = jnp.where(
            new_state.step_counter == self.consts.STEP_COUNTER,
            jnp.array(0),
            new_state.step_counter + 1,
        )

        new_state = new_state.replace(
            step_counter=new_step_counter
        )
        
        # prize
        new_prize, rng_rest = self.prize_step(
            new_state,
        )

        new_state = new_state.replace(
            prize=new_prize,
            rng_key=rng_rest
        )

        # prize collision
        new_prize, new_score, new_spawn_triangle_hollow = self.prize_player_collision_step(new_state)

        new_state = new_state.replace(
            prize=new_prize,
            score=new_score,
            spawn_triangle_hollow=new_spawn_triangle_hollow,
        )

        # game control
        new_game_phase, new_game_phase_timer, new_player_shrink, new_player_x = self.game_control(
            new_state,
        )

        new_state = new_state.replace(
            game_phase=new_game_phase,
            game_phase_timer=new_game_phase_timer,
            player_shrink=new_player_shrink,
            player_x=new_player_x,
        )

        # go to next level
        new_state = self.next_level(new_state)
        
        return new_state


    @partial(jax.jit, static_argnums=(0,))
    def _game_loading_step(self, state: TurmoilState, action: chex.Array) :
        """
        step for loading animation at the start of levels
        """
        # increment step_counter
        new_step_counter = jnp.where(
            state.step_counter == self.consts.STEP_COUNTER,
            jnp.array(0),
            state.step_counter + 1,
        )

        new_state = state.replace(
            step_counter=new_step_counter
        )

        # game control
        new_game_phase, new_game_phase_timer, new_player_shrink, new_player_x = self.game_control(
            new_state,
        )

        new_state = new_state.replace(
            game_phase=new_game_phase,
            game_phase_timer=new_game_phase_timer,
            player_shrink=new_player_shrink,
            player_x=new_player_x,
        )

        return new_state
    
    @partial(jax.jit, static_argnums=(0,))
    def _player_shrink_animation_step(self, state: TurmoilState, action: chex.Array) :
        """
        step for shrinking player, if player enemy collision happens
        """
        # increment step_counter
        new_step_counter = jnp.where(
            state.step_counter == self.consts.STEP_COUNTER,
            jnp.array(0),
            state.step_counter + 1,
        )

        new_state = state.replace(
            step_counter=new_step_counter
        )

        # game control
        new_game_phase, new_game_phase_timer, new_player_shrink, new_player_x = self.game_control(
            new_state,
        )

        new_state = new_state.replace(
            game_phase=new_game_phase,
            game_phase_timer=new_game_phase_timer,
            player_shrink=new_player_shrink,
            player_x=new_player_x,
        )

        # bullet
        new_bullet = self.bullet_step(
            new_state,
            action
        )

        new_state = new_state.replace(
            bullet=new_bullet
        )

        # bullet enemy collision
        new_bullet, new_enemy, new_score, new_enemy_explosion = self.bullet_enemy_collision_step(
            new_state
        )
        
        new_state = new_state.replace(
            bullet=new_bullet,
            enemy=new_enemy,
            score=new_score,
            enemy_explosion=new_enemy_explosion,
        )
        
        # enemy
        new_enemy = self.enemy_step(
            new_state,
        )

        new_state = new_state.replace(
            enemy=new_enemy
        )

        # move enemy explosion
        new_enemy_explosion = self.enemy_explosion_step(
            new_state    
        )

        new_state = new_state.replace(
            enemy_explosion=new_enemy_explosion,
        )

        # change types
        new_enemy, new_prize = self.change_type(new_state)
        
        new_state = new_state.replace(
            enemy=new_enemy,
            prize=new_prize
        )

        # prize
        new_prize, rng_rest = self.prize_step(
            new_state,
        )

        new_state = new_state.replace(
            prize=new_prize,
            rng_key=rng_rest
        )

        return new_state
    
    @partial(jax.jit, static_argnums=(0, ))
    def step(
        self, state: TurmoilState, action: chex.Array
    ) -> Tuple[TurmoilObservation, TurmoilState, float, bool, TurmoilInfo]:

        # Translate compact agent action index to ALE console action
        action = jnp.take(self.ACTION_SET, action.astype(jnp.int32))

        previous_state = state

        return_state = jax.lax.switch(
            state.game_phase,
            [
                lambda s: self._game_loading_step(s, action),
                lambda s: self._normal_game_step(s, action),
                lambda s: self._player_shrink_animation_step(s, action),
            ],
            state,
        )

        observation = self._get_observation(return_state)
        done = self._get_done(return_state)
        env_reward = self._get_reward(previous_state, return_state)
        info = self._get_info(return_state)

        return observation, return_state, env_reward, done, info

class TurmoilRenderer(JAXGameRenderer):
    def __init__(self, consts: TurmoilConstants = None, config: render_utils.RendererConfig = None):
        self.consts = consts or TurmoilConstants()
        super().__init__(self.consts)
        self.sprite_path = os.path.join(render_utils.get_base_sprite_dir(), "turmoil")

        # Use injected config if provided, else default
        if config is None:
            self.config = render_utils.RendererConfig(
                game_dimensions=(self.consts.HEIGHT, self.consts.WIDTH),
                channels=3,
                downscale=None
            )
        else:
            self.config = config
        self.jr = render_utils.JaxRenderingUtils(self.config)

        # 2. Start from (possibly modded) asset config provided via constants
        final_asset_config = list(self.consts.ASSET_CONFIG)

        # 3. Make one call to load and process all assets
        (
            self.PALETTE,
            self.SHAPE_MASKS,
            self.BACKGROUND,
            self.COLOR_TO_ID,
            self.FLIP_OFFSETS
        ) = self.jr.load_and_setup_assets(final_asset_config, self.sprite_path)

        # 4. Replicate Animation Stack Logic (from old load_sprites)

        # Player Shrink (6 frames -> 120 frames)
        ps_stack = self.SHAPE_MASKS['player_shrink']
        self.SHAPE_MASKS['player_shrink'] = jnp.concatenate([
            jnp.repeat(ps_stack[0][None], 31, axis=0),
            jnp.repeat(ps_stack[1][None], 5, axis=0),
            jnp.repeat(ps_stack[2][None], 7, axis=0),
            jnp.repeat(ps_stack[3][None], 5, axis=0),
            jnp.repeat(ps_stack[4][None], 7, axis=0),
            jnp.repeat(ps_stack[5][None], 23, axis=0),
            jnp.repeat(ps_stack[5][None], 23, axis=0),  # Repeated twice
            jnp.repeat(ps_stack[4][None], 7, axis=0),
            jnp.repeat(ps_stack[3][None], 5, axis=0),
            jnp.repeat(ps_stack[2][None], 7, axis=0),
        ])

        # Prize (is animated boom_enemy) (2 frames -> 16 frames)
        prize_stack = self.SHAPE_MASKS['all_enemies'][13:15]  # Get boom_enemy bases
        self.SHAPE_MASKS['prize'] = jnp.concatenate([
            jnp.repeat(prize_stack[0][None], 8, axis=0),
            jnp.repeat(prize_stack[1][None], 8, axis=0),
        ])

        # Enemy Animations (2 frames -> 16 frames)
        l_stack = self.SHAPE_MASKS['all_enemies'][4:6]
        self.SHAPE_MASKS['l_enemy'] = jnp.concatenate([
            jnp.repeat(l_stack[0][None], 8, axis=0), jnp.repeat(l_stack[1][None], 8, axis=0)
        ])

        rocket_stack = self.SHAPE_MASKS['all_enemies'][8:10]
        self.SHAPE_MASKS['rocket_enemy'] = jnp.concatenate([
            jnp.repeat(rocket_stack[0][None], 8, axis=0), jnp.repeat(rocket_stack[1][None], 8, axis=0)
        ])

        t_stack = self.SHAPE_MASKS['all_enemies'][6:8]
        self.SHAPE_MASKS['t_enemy'] = jnp.concatenate([
            jnp.repeat(t_stack[0][None], 8, axis=0), jnp.repeat(t_stack[1][None], 8, axis=0)
        ])

        tank_stack = self.SHAPE_MASKS['all_enemies'][2:4]
        self.SHAPE_MASKS['tank_enemy'] = jnp.concatenate([
            jnp.repeat(tank_stack[0][None], 8, axis=0), jnp.repeat(tank_stack[1][None], 8, axis=0)
        ])

        x_shape_stack = self.SHAPE_MASKS['all_enemies'][11:13]
        self.SHAPE_MASKS['x_shape_enemy'] = jnp.concatenate([
            jnp.repeat(x_shape_stack[0][None], 8, axis=0), jnp.repeat(x_shape_stack[1][None], 8, axis=0)
        ])

        boom_stack = self.SHAPE_MASKS['all_enemies'][13:15]
        self.SHAPE_MASKS['boom_enemy'] = jnp.concatenate([
            jnp.repeat(boom_stack[0][None], 8, axis=0), jnp.repeat(boom_stack[1][None], 8, axis=0)
        ])

        # Enemy Explosion (2 frames -> 16 frames)
        ex_stack = self.SHAPE_MASKS['explosion_group']
        self.SHAPE_MASKS['enemy_explosion'] = jnp.concatenate([
            jnp.repeat(ex_stack[0][None], 8, axis=0), jnp.repeat(ex_stack[1][None], 8, axis=0)
        ])

        # --- 5. Store helper values ---

        # Store animation lengths
        self.anim_len = {
            'player_shrink': self.SHAPE_MASKS['player_shrink'].shape[0],
            'prize': self.SHAPE_MASKS['prize'].shape[0],
            'l_enemy': self.SHAPE_MASKS['l_enemy'].shape[0],
            'rocket_enemy': self.SHAPE_MASKS['rocket_enemy'].shape[0],
            't_enemy': self.SHAPE_MASKS['t_enemy'].shape[0],
            'tank_enemy': self.SHAPE_MASKS['tank_enemy'].shape[0],
            'x_shape_enemy': self.SHAPE_MASKS['x_shape_enemy'].shape[0],
            'boom_enemy': self.SHAPE_MASKS['boom_enemy'].shape[0],
            'enemy_explosion': self.SHAPE_MASKS['enemy_explosion'].shape[0],
        }

        # Store the single, uniform flip offset for all enemies
        self.ENEMY_FLIP_OFFSET = self.FLIP_OFFSETS['all_enemies']

    @partial(jax.jit, static_argnums=(0,))
    def _render_normal_game_step(self, raster, state: TurmoilState):
        # render player
        def _render_player(r):
            flip = state.player_direction == self.consts.FACE_LEFT
            is_shrink = state.game_phase == 2
            
            # Select which mask to use based on game phase
            # For shrink animation, get the frame index
            shrink_idx = jnp.clip(state.game_phase_timer, 0, self.anim_len['player_shrink'] - 1)
            
            # Render conditionally with two separate render calls to avoid shape mismatch
            # Use render_at, not clipped, as player is bounded by game logic
            def render_normal_mask():
                return self.jr.render_at(
                    r, state.player_x, state.player_y,
                    self.SHAPE_MASKS['player'],
                    flip_horizontal=flip,
                    flip_offset=self.FLIP_OFFSETS['player']
                )
            
            def render_shrink_mask():
                return self.jr.render_at(
                    r, state.player_x, state.player_y,
                    self.SHAPE_MASKS['player_shrink'][shrink_idx],
                    flip_horizontal=flip,
                    flip_offset=self.FLIP_OFFSETS['player_shrink']
                )
            
            return jax.lax.cond(is_shrink, render_shrink_mask, render_normal_mask)

        raster = _render_player(raster)

        # render bullet
        raster = jax.lax.cond(
            state.bullet[2],
            lambda r: self.jr.render_at_clipped(
                r, state.bullet[0], state.bullet[1],
                self.SHAPE_MASKS['bullet'], flip_offset=self.FLIP_OFFSETS['bullet']
            ),
            lambda r: r,
            raster
        )

        # show the score
        score_array = self.jr.int_to_digits(state.score, max_digits=5)
        raster = self.jr.render_label(raster, 60, 10, score_array, self.SHAPE_MASKS['digits'], spacing=8, max_digits=5)

        # show remaining ships
        raster = jax.lax.cond(
            state.ships > 0,
            lambda r: self.jr.render_indicator(
                r, 55 + (self.consts.PLAYER_SIZE[0]) * (5 - state.ships),
                190, state.ships - 1,
                self.SHAPE_MASKS['player'],
                spacing=15, max_value=5  # Assuming max 5 lives
            ),
            lambda r: r,
            raster
        )

        # render enemies
        def _render_enemy(r):
            # Get base masks for non-animated enemies
            all_masks = self.SHAPE_MASKS['all_enemies']
            LINES_ENEMY_BASE = all_masks[0]
            ARROW_ENEMY_BASE = all_masks[1]
            TRIANGLE_HOLLOW_ENEMY_BASE = all_masks[10]

            # Get dynamic frames for animated enemies
            # Index into the *pre-built 16-frame stacks*
            tank_frame = self.SHAPE_MASKS['tank_enemy'][state.step_counter % self.anim_len['tank_enemy']]
            l_frame = self.SHAPE_MASKS['l_enemy'][state.step_counter % self.anim_len['l_enemy']]
            t_frame = self.SHAPE_MASKS['t_enemy'][state.step_counter % self.anim_len['t_enemy']]
            rocket_frame = self.SHAPE_MASKS['rocket_enemy'][state.step_counter % self.anim_len['rocket_enemy']]
            x_shape_frame = self.SHAPE_MASKS['x_shape_enemy'][state.step_counter % self.anim_len['x_shape_enemy']]
            boom_frame = self.SHAPE_MASKS['boom_enemy'][state.step_counter % self.anim_len['boom_enemy']]

            # Stack all 9 *current* enemy frames together
            enemy_mask_stack = jnp.stack([
                LINES_ENEMY_BASE,           # 0
                ARROW_ENEMY_BASE,           # 1
                tank_frame,                 # 2
                l_frame,                    # 3
                t_frame,                    # 4
                rocket_frame,               # 5
                TRIANGLE_HOLLOW_ENEMY_BASE, # 6
                x_shape_frame,              # 7
                boom_frame                  # 8
            ])

            def render_enemy(i, r_in):
                enemy_type = state.enemy[i, 0].astype(jnp.int32)
                mask_to_render = enemy_mask_stack[enemy_type]

                return jax.lax.cond(
                    state.enemy[i, 3] == 1,
                    lambda r_l: self.jr.render_at_clipped(
                        r_l,
                        state.enemy[i, 1],
                        state.enemy[i, 2],
                        mask_to_render,
                        flip_horizontal=state.enemy[i, 5] == self.consts.FACE_LEFT,
                        flip_offset=self.ENEMY_FLIP_OFFSET  # All are pre-padded
                    ),
                    lambda r_l: r_l,
                    r_in
                )
            return jax.lax.fori_loop(0, self.consts.MAX_ENEMIES, render_enemy, r)

        raster = _render_enemy(raster)

        # render explosions
        def _render_explosion(r):
            anim_idx = state.step_counter % self.anim_len['enemy_explosion']
            frame_explosion = self.SHAPE_MASKS['enemy_explosion'][anim_idx]

            def render_explosion(i, r_in):
                return jax.lax.cond(
                    state.enemy_explosion[i, 2] == 1,
                    lambda r_l: self.jr.render_at_clipped(
                        r_l,
                        state.enemy_explosion[i, 0],
                        state.enemy_explosion[i, 1],
                        frame_explosion,
                        flip_horizontal=state.enemy_explosion[i, 3] == self.consts.FACE_LEFT,
                        flip_offset=self.FLIP_OFFSETS['explosion_group']
                    ),
                    lambda r_l: r_l,
                    r_in
                )
            return jax.lax.fori_loop(0, self.consts.MAX_EXPLOSIONS, render_explosion, r)

        raster = _render_explosion(raster)

        # render prize
        anim_idx = state.step_counter % self.anim_len['prize']
        frame_prize = self.SHAPE_MASKS['prize'][anim_idx]
        raster = jax.lax.cond(
            state.prize[3],
            lambda r: self.jr.render_at_clipped(
                r, state.prize[1], state.prize[2],
                frame_prize, flip_offset=self.ENEMY_FLIP_OFFSET  # Prize is a boom_enemy
            ),
            lambda r: r,
            raster
        )
        return raster

    @partial(jax.jit, static_argnums=(0,))
    def _render_loading_game_step(self, raster, state: TurmoilState):
        # show level
        level_array = self.jr.int_to_digits(state.level, max_digits=1)
        raster = self.jr.render_label_selective(
            raster, 76, 101, level_array, self.SHAPE_MASKS['digits'],
            0, 1, spacing=8, max_digits_to_render=1
        )

        # show the score
        score_array = self.jr.int_to_digits(state.score, max_digits=5)
        raster = self.jr.render_label(raster, 60, 10, score_array, self.SHAPE_MASKS['digits'], spacing=8, max_digits=5)

        # show remaining ships
        raster = jax.lax.cond(
            state.ships > 0,
            lambda r: self.jr.render_indicator(
                r, 55 + (self.consts.PLAYER_SIZE[0]) * (5 - state.ships),
                190, state.ships - 1,
                self.SHAPE_MASKS['player'],
                spacing=15, max_value=5  # Assuming max 5 lives
            ),
            lambda r: r,
            raster
        )
        return raster

    @partial(jax.jit, static_argnums=(0,))
    def render(self, state: TurmoilState):
        # --- 1. Select Base Raster ---
        # Start with the static black background
        base_raster = self.jr.create_object_raster(self.BACKGROUND)

        # Conditionally draw the game background on top
        # Only show game background if bg_visible is true AND not in loading phase
        # (loading phase always has black background)
        base_raster = jax.lax.cond(
            jnp.logical_and(state.bg_visible, state.game_phase != 0),
            lambda r: self.jr.render_at(
                r, 0, 0,
                self.SHAPE_MASKS['game_bg'],
                flip_offset=self.FLIP_OFFSETS['game_bg']
            ),
            lambda r: r,
            base_raster
        )

        # --- 2. Call appropriate render step ---
        raster = jax.lax.switch(
            state.game_phase,
            [
                lambda r: self._render_loading_game_step(r, state),
                lambda r: self._render_normal_game_step(r, state),
                lambda r: self._render_normal_game_step(r, state),  # Phase 2 is also normal + shrink
            ],
            base_raster
        )

        return self.jr.render_from_palette(raster, self.PALETTE)
