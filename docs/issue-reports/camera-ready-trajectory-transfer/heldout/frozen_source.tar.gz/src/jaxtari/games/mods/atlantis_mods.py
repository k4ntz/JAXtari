import os
from jaxtari.modification import JaxtariModController
from jaxtari.games.mods.atlantis.atlantis_mod_plugins import (
    NoLastLineMod,
    JetsOnlyMod,
    RandomEnemiesMod,
    SpeedModeSlowMod,
    SpeedModeMediumMod,
    SpeedModeFastMod,
)

class AtlantisEnvMod(JaxtariModController):
    """
    Game-specific Mod Controller for Atlantis.
    """

    REGISTRY = {
        "no_last_line": NoLastLineMod,
        "jets_only": JetsOnlyMod,
        "random_enemies": RandomEnemiesMod,
        "speed_mode_slow": SpeedModeSlowMod,
        "speed_mode_medium": SpeedModeMediumMod,
        "speed_mode_fast": SpeedModeFastMod,
    }

    _mod_sprite_dir = os.path.join(os.path.dirname(__file__), "atlantis", "sprites")

    def __init__(self,
                 env,
                 mods_config: list = [],
                 allow_conflicts: bool = False
                 ):

        super().__init__(
            env=env,
            mods_config=mods_config,
            allow_conflicts=allow_conflicts,
            registry=self.REGISTRY
        )
