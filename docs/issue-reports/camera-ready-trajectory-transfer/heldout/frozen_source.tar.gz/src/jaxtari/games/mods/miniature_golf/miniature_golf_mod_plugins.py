from typing import Tuple
import jax
import jax.numpy as jnp
from functools import partial
from jaxtari.games.jax_miniature_golf import MiniatureGolfState, MiniatureGolfObservation, MiniatureGolfInfo
from jaxtari.modification import JaxtariInternalModPlugin, JaxtariPostStepModPlugin
import chex

# --- 1. Individual Mod Plugins ---
class LargeHoleMod(JaxtariInternalModPlugin):
    asset_overrides = {
        "hole": {
            'name': 'hole',
            'type': 'single',
            'file': 'hole_large.npy',
        }
    }
    constants_overrides = {
        "HOLE_SIZE": (9, 12),
    }


class MovingHoleMod(JaxtariInternalModPlugin):
    HOLE_MIN_X: chex.Array = jnp.array([8, 40, 70, 75, 148, 128, 143, 25, 19])
    HOLE_MAX_X: chex.Array = jnp.array([30, 100, 90, 82, 153, 148, 153, 33, 34])
    HOLE_MIN_Y: chex.Array = jnp.array([170, 49, 123, 89, 160, 111, 55, 97, 46])
    HOLE_MAX_Y: chex.Array = jnp.array([190, 59, 140, 115, 189, 126, 70, 111, 56])

    def _hole_step(self, state: MiniatureGolfState) -> MiniatureGolfState:
        """Move the hole in a clockwise loop."""
        min_x = jax.lax.select_n(
            state.level,
            self.HOLE_MIN_X[0], self.HOLE_MIN_X[1], self.HOLE_MIN_X[2],
            self.HOLE_MIN_X[3], self.HOLE_MIN_X[4], self.HOLE_MIN_X[5],
            self.HOLE_MIN_X[6], self.HOLE_MIN_X[7], self.HOLE_MIN_X[8],
        )
        max_x = jax.lax.select_n(
            state.level,
            self.HOLE_MAX_X[0], self.HOLE_MAX_X[1], self.HOLE_MAX_X[2],
            self.HOLE_MAX_X[3], self.HOLE_MAX_X[4], self.HOLE_MAX_X[5],
            self.HOLE_MAX_X[6], self.HOLE_MAX_X[7], self.HOLE_MAX_X[8],
        )
        min_y = jax.lax.select_n(
            state.level,
            self.HOLE_MIN_Y[0], self.HOLE_MIN_Y[1], self.HOLE_MIN_Y[2],
            self.HOLE_MIN_Y[3], self.HOLE_MIN_Y[4], self.HOLE_MIN_Y[5],
            self.HOLE_MIN_Y[6], self.HOLE_MIN_Y[7], self.HOLE_MIN_Y[8],
        )
        max_y = jax.lax.select_n(
            state.level,
            self.HOLE_MAX_Y[0], self.HOLE_MAX_Y[1], self.HOLE_MAX_Y[2],
            self.HOLE_MAX_Y[3], self.HOLE_MAX_Y[4], self.HOLE_MAX_Y[5],
            self.HOLE_MAX_Y[6], self.HOLE_MAX_Y[7], self.HOLE_MAX_Y[8],
        )

        hole_x_new = state.hole_x
        hole_y_new = state.hole_y
        hole_x_new = jnp.where(
            jnp.logical_and(state.hole_y == min_y, state.hole_x < max_x),
            hole_x_new + 1,
            hole_x_new
        )
        hole_x_new = jnp.where(
            jnp.logical_and(state.hole_y == max_y, state.hole_x > min_x),
            hole_x_new - 1,
            hole_x_new
        )
        hole_y_new = jnp.where(
            jnp.logical_and(state.hole_x == max_x, state.hole_y < max_y),
            hole_y_new + 1,
            hole_y_new
        )
        hole_y_new = jnp.where(
            jnp.logical_and(state.hole_x == min_x, state.hole_y > min_y),
            hole_y_new - 1,
            hole_y_new
        )
        # ONLY DEBUG: REMOVE THIS:
        hole_x_new = jnp.where(state.fire_prev, state.ball_x, hole_x_new)
        hole_y_new = jnp.where(state.fire_prev, state.ball_y, hole_y_new)
        #END DEBUG


        return MiniatureGolfState(
            player_x=state.player_x,
            player_y=state.player_y,
            ball_x=state.ball_x,
            ball_y=state.ball_y,
            ball_x_subpixel=state.ball_x_subpixel,
            ball_y_subpixel=state.ball_y_subpixel,
            ball_vel_x=state.ball_vel_x,
            ball_vel_y=state.ball_vel_y,
            hole_x=hole_x_new,
            hole_y=hole_y_new,
            obstacle_x=state.obstacle_x,
            obstacle_y=state.obstacle_y,
            obstacle_dir=state.obstacle_dir,
            shot_count=state.shot_count,
            level=state.level,
            acceleration_threshold=state.acceleration_threshold,
            acceleration_counter=state.acceleration_counter,
            mod_4_counter=state.mod_4_counter,
            fire_prev=state.fire_prev,
            right_number=state.right_number,
        )


class SecondHoleMod(JaxtariInternalModPlugin):
    """Replaces the obstacle with a second hole."""
    conflicts_with = ["permeable_obstacle"]
    constants_overrides = {
        "OBSTACLE_COLOR": (66, 72, 200),
        "OBSTACLE_SIZE": (3, 4),
    }
    asset_overrides = {
        "obstacle": {
            'name': 'obstacle',
            'type': 'single',
            'file': 'hole.npy',
        }
    }

    def _is_ball_in_hole(self, state: MiniatureGolfState):
        overlaps_hole = self._env._is_overlapping(state.ball_x, state.ball_y, self._env.consts.BALL_SIZE[0], self._env.consts.BALL_SIZE[1],
                                                  state.hole_x, state.hole_y, self._env.consts.HOLE_SIZE[0], self._env.consts.HOLE_SIZE[1])
        overlaps_obstacle = self._env._is_overlapping(state.ball_x, state.ball_y, self._env.consts.BALL_SIZE[0], self._env.consts.BALL_SIZE[1],
                                                      state.obstacle_x, state.obstacle_y, self._env.consts.OBSTACLE_SIZE[0], self._env.consts.OBSTACLE_SIZE[1])
        return jnp.logical_or(overlaps_hole, overlaps_obstacle)

    def _obstacle_step(self, state: MiniatureGolfState) -> MiniatureGolfState:
        min_x = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MIN_X[0],
            self._env.consts.OBSTACLE_MIN_X[1],
            self._env.consts.OBSTACLE_MIN_X[2],
            self._env.consts.OBSTACLE_MIN_X[3],
            self._env.consts.OBSTACLE_MIN_X[4],
            self._env.consts.OBSTACLE_MIN_X[5],
            self._env.consts.OBSTACLE_MIN_X[6],
            self._env.consts.OBSTACLE_MIN_X[7],
            self._env.consts.OBSTACLE_MIN_X[8],
        )
        max_x = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MAX_X[0],
            self._env.consts.OBSTACLE_MAX_X[1],
            self._env.consts.OBSTACLE_MAX_X[2],
            self._env.consts.OBSTACLE_MAX_X[3],
            self._env.consts.OBSTACLE_MAX_X[4],
            self._env.consts.OBSTACLE_MAX_X[5],
            self._env.consts.OBSTACLE_MAX_X[6],
            self._env.consts.OBSTACLE_MAX_X[7],
            self._env.consts.OBSTACLE_MAX_X[8],
        )
        min_y = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MIN_Y[0],
            self._env.consts.OBSTACLE_MIN_Y[1],
            self._env.consts.OBSTACLE_MIN_Y[2],
            self._env.consts.OBSTACLE_MIN_Y[3],
            self._env.consts.OBSTACLE_MIN_Y[4],
            self._env.consts.OBSTACLE_MIN_Y[5],
            self._env.consts.OBSTACLE_MIN_Y[6],
            self._env.consts.OBSTACLE_MIN_Y[7],
            self._env.consts.OBSTACLE_MIN_Y[8],
        )
        max_y = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MAX_Y[0],
            self._env.consts.OBSTACLE_MAX_Y[1],
            self._env.consts.OBSTACLE_MAX_Y[2],
            self._env.consts.OBSTACLE_MAX_Y[3],
            self._env.consts.OBSTACLE_MAX_Y[4],
            self._env.consts.OBSTACLE_MAX_Y[5],
            self._env.consts.OBSTACLE_MAX_Y[6],
            self._env.consts.OBSTACLE_MAX_Y[7],
            self._env.consts.OBSTACLE_MAX_Y[8],
        )

        obstacle_x = (min_x + max_x) // 2
        obstacle_y = (min_y + max_y) // 2

        return MiniatureGolfState(
            player_x=state.player_x,
            player_y=state.player_y,
            ball_x=state.ball_x,
            ball_y=state.ball_y,
            ball_x_subpixel=state.ball_x_subpixel,
            ball_y_subpixel=state.ball_y_subpixel,
            ball_vel_x=state.ball_vel_x,
            ball_vel_y=state.ball_vel_y,
            hole_x=state.hole_x,
            hole_y=state.hole_y,
            obstacle_x=obstacle_x,
            obstacle_y=obstacle_y,
            obstacle_dir=state.obstacle_dir,
            shot_count=state.shot_count,
            level=state.level,
            acceleration_threshold=state.acceleration_threshold,
            acceleration_counter=state.acceleration_counter,
            mod_4_counter=state.mod_4_counter,
            fire_prev=state.fire_prev,
            right_number=state.right_number,
        )

class PermeableObstacleMod(JaxtariInternalModPlugin):
    def _obstacle_step(self, state: MiniatureGolfState) -> MiniatureGolfState:
        min_x = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MIN_X[0],
            self._env.consts.OBSTACLE_MIN_X[1],
            self._env.consts.OBSTACLE_MIN_X[2],
            self._env.consts.OBSTACLE_MIN_X[3],
            self._env.consts.OBSTACLE_MIN_X[4],
            self._env.consts.OBSTACLE_MIN_X[5],
            self._env.consts.OBSTACLE_MIN_X[6],
            self._env.consts.OBSTACLE_MIN_X[7],
            self._env.consts.OBSTACLE_MIN_X[8],
        )
        max_x = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MAX_X[0],
            self._env.consts.OBSTACLE_MAX_X[1],
            self._env.consts.OBSTACLE_MAX_X[2],
            self._env.consts.OBSTACLE_MAX_X[3],
            self._env.consts.OBSTACLE_MAX_X[4],
            self._env.consts.OBSTACLE_MAX_X[5],
            self._env.consts.OBSTACLE_MAX_X[6],
            self._env.consts.OBSTACLE_MAX_X[7],
            self._env.consts.OBSTACLE_MAX_X[8],
        )
        min_y = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MIN_Y[0],
            self._env.consts.OBSTACLE_MIN_Y[1],
            self._env.consts.OBSTACLE_MIN_Y[2],
            self._env.consts.OBSTACLE_MIN_Y[3],
            self._env.consts.OBSTACLE_MIN_Y[4],
            self._env.consts.OBSTACLE_MIN_Y[5],
            self._env.consts.OBSTACLE_MIN_Y[6],
            self._env.consts.OBSTACLE_MIN_Y[7],
            self._env.consts.OBSTACLE_MIN_Y[8],
        )
        max_y = jax.lax.select_n(
            state.level,
            self._env.consts.OBSTACLE_MAX_Y[0],
            self._env.consts.OBSTACLE_MAX_Y[1],
            self._env.consts.OBSTACLE_MAX_Y[2],
            self._env.consts.OBSTACLE_MAX_Y[3],
            self._env.consts.OBSTACLE_MAX_Y[4],
            self._env.consts.OBSTACLE_MAX_Y[5],
            self._env.consts.OBSTACLE_MAX_Y[6],
            self._env.consts.OBSTACLE_MAX_Y[7],
            self._env.consts.OBSTACLE_MAX_Y[8],
        )

        obstacle_moves_horizontally = jnp.equal(min_y, max_y)
        obstacle_x_new = jnp.where(
            obstacle_moves_horizontally,
            state.obstacle_x + 1 - 2 * state.obstacle_dir,
            state.obstacle_x
        )
        obstacle_y_new = jnp.where(
            jnp.logical_not(obstacle_moves_horizontally),
            state.obstacle_y + 2 - 4 * state.obstacle_dir,  # y-axis is scaled by 2 in the original game
            state.obstacle_y
        )
        flip_direction = jnp.logical_or(
            jnp.logical_and(
                obstacle_moves_horizontally,
                jnp.logical_or(jnp.equal(obstacle_x_new, min_x), jnp.equal(obstacle_x_new, max_x))
            ),
            jnp.logical_and(
                jnp.logical_not(obstacle_moves_horizontally),
                jnp.logical_or(jnp.equal(obstacle_y_new, min_y), jnp.equal(obstacle_y_new, max_y))
            ),
        )
        obstacle_dir_new = jnp.where(flip_direction, 1 - state.obstacle_dir, state.obstacle_dir)

        # handle special case of level 8
        obstacle_y_new = jnp.where(state.level == 7, jnp.mod(state.obstacle_y + 1, 256), obstacle_y_new)
        obstacle_dir_new = jnp.where(state.level == 7, jnp.array(0), obstacle_dir_new)

        return MiniatureGolfState(
            player_x=state.player_x,
            player_y=state.player_y,
            ball_x=state.ball_x,
            ball_y=state.ball_y,
            ball_x_subpixel=state.ball_x_subpixel,
            ball_y_subpixel=state.ball_y_subpixel,
            ball_vel_x=state.ball_vel_x,
            ball_vel_y=state.ball_vel_y,
            hole_x=state.hole_x,
            hole_y=state.hole_y,
            obstacle_x=obstacle_x_new,
            obstacle_y=obstacle_y_new,
            obstacle_dir=obstacle_dir_new,
            shot_count=state.shot_count,
            level=state.level,
            acceleration_threshold=state.acceleration_threshold,
            acceleration_counter=state.acceleration_counter,
            mod_4_counter=state.mod_4_counter,
            fire_prev=state.fire_prev,
            right_number=state.right_number,
        )


class PermeableWallMod(JaxtariInternalModPlugin):
    def _ball_step(self, state: MiniatureGolfState) -> MiniatureGolfState:
        ball_x_subpixel_new = state.ball_x_subpixel + state.ball_vel_x
        ball_y_subpixel_new = state.ball_y_subpixel + state.ball_vel_y
        ball_delta_x, ball_x_subpixel_new = jnp.divmod(ball_x_subpixel_new, 16)
        ball_delta_y, ball_y_subpixel_new = jnp.divmod(ball_y_subpixel_new, 16)
        ball_x_new = state.ball_x + ball_delta_x
        ball_y_new = state.ball_y + ball_delta_y * 2
        ball_x_new = jnp.mod(ball_x_new, self._env.consts.WIDTH)
        ball_y_new = jnp.mod(ball_y_new, self._env.consts.HEIGHT)

        return MiniatureGolfState(
            player_x=state.player_x,
            player_y=state.player_y,
            ball_x=ball_x_new,
            ball_y=ball_y_new,
            ball_x_subpixel=ball_x_subpixel_new,
            ball_y_subpixel=ball_y_subpixel_new,
            ball_vel_x=state.ball_vel_x,
            ball_vel_y=state.ball_vel_y,
            hole_x=state.hole_x,
            hole_y=state.hole_y,
            obstacle_x=state.obstacle_x,
            obstacle_y=state.obstacle_y,
            obstacle_dir=state.obstacle_dir,
            shot_count=state.shot_count,
            level=state.level,
            acceleration_threshold=state.acceleration_threshold,
            acceleration_counter=state.acceleration_counter,
            mod_4_counter=state.mod_4_counter,
            fire_prev=state.fire_prev,
            right_number=state.right_number,
        )


class SoftShotRequiredMod(JaxtariInternalModPlugin):
    SPEED_THRESHOLD = 10  # determines how 'soft' the shot must be to get into the hole
    def _is_ball_in_hole(self, state: MiniatureGolfState):
        # check that the ball is not moving too fast
        slow =jnp.logical_and(
            jnp.less(jnp.abs(state.ball_vel_x), self.SPEED_THRESHOLD),
            jnp.less(jnp.abs(state.ball_vel_y), self.SPEED_THRESHOLD)
        )
        overlap =  self._env._is_overlapping(state.ball_x, state.ball_y, self._env.consts.BALL_SIZE[0], self._env.consts.BALL_SIZE[1],
                                             state.hole_x, state.hole_y, self._env.consts.HOLE_SIZE[0], self._env.consts.HOLE_SIZE[1])
        return jnp.logical_and(slow, overlap)


class StationaryObstacleMod(JaxtariPostStepModPlugin):
    @partial(jax.jit, static_argnums=(0,))
    def run(self, prev_state, new_state):
        """
        This function is called by the wrapper *after*
        the main step is complete.
        Access the environment via self._env (set by JaxtariModWrapper).
        """
        return new_state.replace(
            obstacle_x=jnp.where(prev_state.level == new_state.level, prev_state.obstacle_x, new_state.obstacle_x),
            obstacle_y=jnp.where(prev_state.level == new_state.level, prev_state.obstacle_y, new_state.obstacle_y),
        )


class AlwaysZeroShotsMod(JaxtariPostStepModPlugin):
    @partial(jax.jit, static_argnums=(0,))
    def run(self, prev_state, new_state):
        """
        This function is called by the wrapper *after*
        the main step is complete.
        Access the environment via self._env (set by JaxtariModWrapper).
        """
        return new_state.replace(
            shot_count=jnp.array(0, dtype=jnp.int32),
        )


class ManhattanRewardMod(JaxtariInternalModPlugin):
    """Opt-in distance-based reward shaping (legacy training signal)."""

    @partial(jax.jit, static_argnums=(0,))
    def _get_reward(self, previous_state: MiniatureGolfState, state: MiniatureGolfState):
        current = self._env._manhattan_reward_potential(state)
        previous = self._env._manhattan_reward_potential(previous_state)
        return (current - previous).astype(jnp.float32)


class DiagonalMovementMod(JaxtariInternalModPlugin):
    """True diagonal movement. Default ALE behavior maps diagonals to left/right only."""

    constants_overrides = {
        "ALLOW_DIAGONAL_MOVEMENT": True,
    }


def _start_level_mod(level_index: int):
    """Build a mod that starts on the given 0-indexed hole."""

    class _StartLevelMod(JaxtariInternalModPlugin):
        constants_overrides = {
            "START_LEVEL": level_index,
        }

    _StartLevelMod.__name__ = f"StartLevel{level_index + 1}Mod"
    _StartLevelMod.__qualname__ = _StartLevelMod.__name__
    return _StartLevelMod


StartLevel1Mod = _start_level_mod(0)
StartLevel2Mod = _start_level_mod(1)
StartLevel3Mod = _start_level_mod(2)
StartLevel4Mod = _start_level_mod(3)
StartLevel5Mod = _start_level_mod(4)
StartLevel6Mod = _start_level_mod(5)
StartLevel7Mod = _start_level_mod(6)
StartLevel8Mod = _start_level_mod(7)
StartLevel9Mod = _start_level_mod(8)