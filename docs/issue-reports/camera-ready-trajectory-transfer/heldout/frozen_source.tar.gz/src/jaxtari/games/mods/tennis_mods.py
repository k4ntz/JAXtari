import os
from jaxtari.modification import JaxtariModController
from jaxtari.games.mods.tennis.tennis_mod_plugins import (
    RandomBallSpeedWrapper,
    RandomWalkSpeedWrapper,
    FastPlayerMod,
    SuperGravityMod,
    LazyEnemyMod,
    HighBounceMod,
    FastEnemyMod,
    ClayCourtMod,
    GrassCourtMod,
    HardCourtMod,
    NightMod,
    GrayscaleMod,
    InvertedColorsMod,
)

class TennisEnvMod(JaxtariModController):
    """
    Game-specific Mod Controller for Tennis.
    It simply inherits all logic from JaxtariModController and defines the REGISTRY.
    """

    REGISTRY = {
        "random_ball_speed": RandomBallSpeedWrapper,
        "random_walk_speed": RandomWalkSpeedWrapper,
        "fast_player": FastPlayerMod,
        "super_gravity": SuperGravityMod,
        "lazy_enemy": LazyEnemyMod,
        "high_bounce": HighBounceMod,
        "fast_enemy": FastEnemyMod,
        "clay_court": ClayCourtMod,
        "grass_court": GrassCourtMod,
        "hard_court": HardCourtMod,
        "night_mode": NightMod,
        "grayscale": GrayscaleMod,
        "inverted_colors": InvertedColorsMod,
    }

    _mod_sprite_dir = os.path.join(os.path.dirname(__file__), "tennis", "sprites")

    def __init__(self,
                 env,
                 mods_config: list = [],
                 allow_conflicts: bool = False
                 ):

        super().__init__(
            env=env,
            mods_config=mods_config,
            allow_conflicts=allow_conflicts,
            registry=self.REGISTRY
        )
