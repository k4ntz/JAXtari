import os
from jaxtari.modification import JaxtariModController
from jaxtari.games.mods.mspacman.mspacman_mod_plugins import (
    CagedGhostsMod,
    ConstantFruitsMod,
    FruitGhostBonusMod,
    SetMaze1Mod,
    SetMaze2Mod,
    SetMaze3Mod,
    SetMaze4Mod,
    Only1GhostMod,
    Only2GhostMod,
    Only3GhostMod,
    RandomGhostNavigationMod,
    MatrixMod,
    RandomPowerPelletsMod,
    SpeedFrenzyMod,
    FragileGhostsMod,
    GreedyPacManMod,
    CozyStartMod,
    InvisibleDotsMod,
    GhostMagnetismMod,
    TeleportationErrorMod,
    NoStartDelayMod,
    MatrixMod
)

class MsPacmanEnvMod(JaxtariModController):
    """
    Game-specific Mod Controller for MsPacman.
    """
    REGISTRY = {
        "caged_ghosts": CagedGhostsMod,
        "constant_fruits": ConstantFruitsMod,
        "fruit_ghost_bonus": FruitGhostBonusMod,
        "set_maze_1": SetMaze1Mod,
        "set_maze_2": SetMaze2Mod,
        "set_maze_3": SetMaze3Mod,
        "set_maze_4": SetMaze4Mod,
        "only_1_ghost": Only1GhostMod,
        "only_2_ghost": Only2GhostMod,
        "only_3_ghost": Only3GhostMod,
        "random_ghost_navigation": RandomGhostNavigationMod,
        "no_start_delay": NoStartDelayMod,
        "matrix_theme": MatrixMod,
        "random_power_pellets": RandomPowerPelletsMod,
        "speed_frenzy": SpeedFrenzyMod,
        "fragile_ghosts": FragileGhostsMod,
        "greedy_pacman": GreedyPacManMod,
        "cozy_start": CozyStartMod,
        "invisible_dots": InvisibleDotsMod,
        "ghost_magnetism": GhostMagnetismMod,
        "teleportation_error": TeleportationErrorMod,
    }

    _mod_sprite_dir = os.path.join(os.path.dirname(__file__), "mspacman", "sprites")

    def __init__(self,
                 env,
                 mods_config: list = [],
                 allow_conflicts: bool = False
                 ):

        super().__init__(
            env=env,
            mods_config=mods_config,
            allow_conflicts=allow_conflicts,
            registry=self.REGISTRY
        )

# Alias for utils.py loader which uses capitalize()
MspacmanEnvMod = MsPacmanEnvMod