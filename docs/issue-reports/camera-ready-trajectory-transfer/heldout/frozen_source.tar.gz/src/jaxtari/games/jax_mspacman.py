# -------- Imports --------
from enum import IntEnum
import os
from functools import partial
from typing import Any, Dict, NamedTuple, Optional, Tuple

import chex
import jax
import jax.numpy as jnp
from flax import struct

import jaxtari.spaces as spaces
from jaxtari.environment import JaxEnvironment, JaxtariAction as Action, ObjectObservation
from jaxtari.renderers import JAXGameRenderer
from jaxtari.rendering import jax_rendering_utils as render_utils
from jaxtari.games.mspacman_mazes import MsPacmanMaze


# -------- Enums -------- 
class FruitType(IntEnum):
    CHERRY = 0
    STRAWBERRY = 1
    ORANGE = 2
    PRETZEL = 3
    APPLE = 4
    PEAR = 5
    BANANA = 6

class GhostType(IntEnum):
    BLINKY = 0
    PINKY = 1
    INKY = 2
    SUE = 3

class GhostMode(IntEnum):
    RANDOM = 0
    CHASE = 1
    SCATTER = 2
    FRIGHTENED = 3
    BLINKING = 4
    RETURNING = 5
    ENJAILED = 6


# -------- Constants --------
class MsPacmanConstants(struct.PyTreeNode):
    # GENERAL
    WIDTH: int = struct.field(pytree_node=False, default=160)
    HEIGHT: int = struct.field(pytree_node=False, default=210)
    RESET_LEVEL: int = struct.field(pytree_node=False, default=1) # The starting level, loaded when reset is called
    TIME_SCALE: int = struct.field(pytree_node=False, default=20) # Approximate number of timesteps in a second scaled to the original game speed
    INITIAL_LIVES: int = struct.field(pytree_node=False, default=3) # Number of starting bonus lives
    MAX_LIVE_COUNT: int = struct.field(pytree_node=False, default=4) # Maximum possible number of lives
    MAX_SCORE_DIGITS: int = struct.field(pytree_node=False, default=6) # Number of digits to display in the score
    BONUS_LIFE_SCORE: int = struct.field(pytree_node=False, default=10000) # Score at which a bonus life is rewarded
    COLLISION_THRESHOLD: int = struct.field(pytree_node=False, default=6) # Contacts below this distance count as collision
    START_DELAY: int = struct.field(pytree_node=False, default=260) # Frames to wait after reset before player/ghosts move (animations still run)
    MOVE_PERIOD: int = struct.field(pytree_node=False, default=2) # ALE advances entity positions every other frame
    PELLETS_TO_COLLECT: Tuple[int, ...] = struct.field(pytree_node=False, default=(154, 150, 158, 154)) # Total pellets to collect in each maze

    # GHOST TIMINGS
    SUE_RELEASE_TIME: int = struct.field(pytree_node=False, default=1*20)
    INKY_RELEASE_TIME: int = struct.field(pytree_node=False, default=5*20)
    PINKY_RELEASE_TIME: int = struct.field(pytree_node=False, default=7*20)
    RESET_TIMER: int = struct.field(pytree_node=False, default=4*20)
    EAT_GHOST_FREEZE: int = struct.field(pytree_node=False, default=20) # Frames to freeze after eating a ghost
    CHASE_DURATION: int = struct.field(pytree_node=False, default=20*20)
    SCATTER_DURATION: int = struct.field(pytree_node=False, default=7*20)
    FRIGHTENED_DURATION: int = struct.field(pytree_node=False, default=13*20)
    BLINKING_DURATION: int = struct.field(pytree_node=False, default=4*20)
    ENJAILED_DURATION: int = struct.field(pytree_node=False, default=10*20)
    FRIGHTENED_REDUCTION: float = struct.field(pytree_node=False, default=0.85)
    RETURN_DURATION: int = struct.field(pytree_node=False, default=int(20/2))
    MAX_CHASE_OFFSET: float = struct.field(pytree_node=False, default=20*20/10)
    MAX_SCATTER_OFFSET: float = struct.field(pytree_node=False, default=7*20/10)

    # FRUITS
    FRUIT_SPAWN_THRESHOLDS: Tuple[int, ...] = struct.field(pytree_node=False, default=(50, 100))
    FRUIT_WANDER_DURATION: int = struct.field(pytree_node=False, default=25*20)

    # POSITIONS
    POWER_PELLET_TILES: Tuple[Tuple[int, int], ...] = struct.field(
        pytree_node=False, default=((1, 3), (36, 3), (1, 36), (36, 36))
    )
    POWER_PELLET_HITBOXES: Tuple[Tuple[int, int], ...] = struct.field(
        pytree_node=False,
        default=((1, 3), (36, 3), (1, 36), (36, 36), (1, 4), (36, 4), (1, 37), (36, 37)),
    )
    JAIL_POSITION: Tuple[int, int] = struct.field(pytree_node=False, default=(75, 75))
    INITIAL_GHOSTS_POSITIONS: Tuple[Tuple[int, int], ...] = struct.field(
        pytree_node=False, default=((75, 54), (75, 75), (75, 75), (75, 75))
    )
    INITIAL_PACMAN_POSITION: Tuple[int, int] = struct.field(pytree_node=False, default=(75, 102))
    SCATTER_TARGETS: Tuple[Tuple[int, int], ...] = struct.field(
        pytree_node=False,
        default_factory=lambda: (
            (int(MsPacmanMaze.WIDTH) - 1, 0),
            (0, 0),
            (int(MsPacmanMaze.WIDTH) - 1, int(MsPacmanMaze.HEIGHT) - 1),
            (0, int(MsPacmanMaze.HEIGHT) - 1),
        ),
    )

    # ACTIONS
    DIRECTIONS: Tuple[int, ...] = struct.field(
        pytree_node=False, default=(Action.UP, Action.RIGHT, Action.LEFT, Action.DOWN)
    )
    ACTIONS: Tuple[Tuple[int, int], ...] = struct.field(
        pytree_node=False, default=((0, 0), (0, 0), (0, -1), (1, 0), (-1, 0), (0, 1))
    )
    # ALE steps ~1.25px on X and ~1.7–2px on Y every other frame. Extra X pixel
    # when x%4==3 lands on turn columns (x%4==1); even Y uses 2px to keep y%12==6.
    HORIZONTAL_SPEED: int = struct.field(pytree_node=False, default=1)
    VERTICAL_SPEED: int = struct.field(pytree_node=False, default=2)
    INITIAL_ACTION: int = struct.field(pytree_node=False, default=Action.LEFT)
    INITIAL_LAST_ACTION: int = struct.field(pytree_node=False, default=Action.LEFT)

    # Sprite sizes used by object-centric observations (HWC npy assets).
    PACMAN_WIDTH: int = struct.field(pytree_node=False, default=10)
    PACMAN_HEIGHT: int = struct.field(pytree_node=False, default=10)
    GHOST_WIDTH: int = struct.field(pytree_node=False, default=9)
    GHOST_HEIGHT: int = struct.field(pytree_node=False, default=10)
    FRUIT_WIDTH: int = struct.field(pytree_node=False, default=8)
    FRUIT_HEIGHT: int = struct.field(pytree_node=False, default=10)
    PACMAN_INK_BOXES: Tuple[Tuple[int, int, int, int], ...] = struct.field(
        pytree_node=False, default=((0, 0, 10, 9), (1, 0, 9, 10), (0, 0, 9, 10), (0, 1, 10, 9))
    )
    FRUIT_INK_SIZES: Tuple[Tuple[int, int], ...] = struct.field(
        pytree_node=False, default=((8, 10), (6, 8), (8, 10), (8, 10), (7, 10), (6, 10), (8, 10))
    )
    POWER_PELLET_WIDTH: int = struct.field(pytree_node=False, default=4)
    POWER_PELLET_HEIGHT: int = struct.field(pytree_node=False, default=7)

    # POINTS
    PELLET_POINTS: int = struct.field(pytree_node=False, default=10)
    POWER_PELLET_POINTS: int = struct.field(pytree_node=False, default=50)
    FRUIT_REWARDS: Tuple[int, ...] = struct.field(
        pytree_node=False, default=(100, 200, 500, 700, 1000, 2000, 5000)
    )
    EAT_GHOSTS_BASE_POINTS: int = struct.field(pytree_node=False, default=200)
    LEVEL_COMPLETED_POINTS: int = struct.field(pytree_node=False, default=500)

    # COLORS
    PATH_COLOR: Tuple[int, int, int] = struct.field(pytree_node=False, default=(0, 28, 136))
    WALL_COLOR: Tuple[int, int, int] = struct.field(pytree_node=False, default=(228, 111, 111))
    PELLET_COLOR: Tuple[int, int, int] = struct.field(pytree_node=False, default=(228, 111, 111))
    PACMAN_COLOR: Tuple[int, int, int, int] = struct.field(pytree_node=False, default=(210, 164, 74, 255))
    
    # MOD COLORS (Optional overrides)
    RGB_BACKGROUND: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_PACMAN: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_WALLS: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_PATH: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_PELLETS: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_GHOST_BLINKY: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_GHOST_PINKY: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_GHOST_INKY: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_GHOST_SUE: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_GHOST_FRIGHTENED: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_GHOST_BLINKING: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_FRUIT: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)
    RGB_SCORE: Optional[Tuple[int, int, int]] = struct.field(pytree_node=False, default=None)


# -------- Entity classes --------
class LevelState(NamedTuple):
    id: chex.Array                  # Int - Number of the current level, starts at 1
    collected_pellets: chex.Array   # Int - Number of collected pellets
    pellets: chex.Array             # Bool[x][y] - 2D grid of 0 (empty) or 1 (pellet)
    power_pellets: chex.Array       # Bool[4] - Indicates wheter the power pellet is available
    loaded: chex.Array              # Int - 0: Not loaded, 1: loading, 2: loaded

class GhostsState(NamedTuple):
    positions: chex.Array           # Tuple - (x, y)
    types: chex.Array               # Enum - 0: BLINKY, 1: PINKY, 2: INKY, 3: SUE
    actions: chex.Array             # Enum - 0: NOOP, 1: FIRE, 2: UP, 3: RIGHT, 4: LEFT, 5: DOWN
    modes: chex.Array               # Enum - 0: RANDOM, 1: CHASE, 2: SCTATTER, 3: FRIGHTENED, 4: BLINKING, 5: RETURNING, 6: ENJAILED
    timers: chex.Array              # Int - Triggers mode change when reaching 0, decrements every step

class PlayerState(NamedTuple):
    position: chex.Array            # Tuple - (x, y)
    action: chex.Array              # Enum - 0: NOOP, 1: FURE, 2: UP, 3: RIGHT, 4: LEFT, 5: DOWN
    has_pellet: chex.Array          # Bool - Indicates if pacman just collected a pellet
    eaten_ghosts: chex.Array        # Int - Indicates the number of ghosts eaten since the last power pellet
    last_horiz_dir: chex.Array = jnp.array(2, dtype=jnp.int32) # Default LEFT (2 in act_to_dir)

class FruitState(NamedTuple):
    position: chex.Array            # Tuple - (x, y)
    exit: chex.Array                # Tuple - (x, y) Position of the tunnel through which it will exit
    type: chex.Array                # Enum - 0: CHERRY, 1: STRAWBERRY, 2: ORANGE, 3: PRETZEL, 4: APPLE, 5: PEAR, 6: BANANA, 7: NONE
    action: chex.Array              # Enum - 0: NOOP, 1: FIRE, 2: UP, 3: RIGHT, 4: LEFT, 5: DOWN
    spawn: chex.Array               # Bool - Indicates wether a fruit should spawn into the maze as soon as possible
    spawned: chex.Array             # Bool - Indicates wether a fruit is currently present within the maze
    timer: chex.Array               # Int - Time until leaving through the exit tunnel, decrements every step

@struct.dataclass
class PacmanState:
    level: LevelState               # LevelState
    player: PlayerState             # PlayerState
    ghosts: GhostsState             # GhostStates
    fruit: FruitState               # FruitState
    lives: chex.Array               # Int - Number of lives left
    score: chex.Array               # Int - Total score reached
    score_changed: chex.Array       # Bool[] - Indicates which score digit changed since the last step
    freeze_timer: chex.Array        # Int - Time until game is unfrozen, decrements every step
    eat_freeze_timer: chex.Array    # Int - Pause after eating a ghost; decrements every step
    step_count: chex.Array          # Int - Number of steps made in the current level
    key: chex.PRNGKey               # PRNGKey for RNG during step

@struct.dataclass
class PacmanObservation:
    player: ObjectObservation
    ghosts: ObjectObservation  # n=4; visual_id=GhostType, state=GhostMode (FRIGHTENED/BLINKING = vulnerable)
    fruit: ObjectObservation  # visual_id=FruitType; active while spawned in the maze
    power_pellets: ObjectObservation  # n=4
    pellets: ObjectObservation  # n=252, index = grid_x * 14 + grid_y; active while not eaten

@struct.dataclass
class PacmanInfo:
    level: chex.Array
    score: chex.Array
    lives: chex.Array


# -------- Game class --------
class JaxPacman(JaxEnvironment[PacmanState, PacmanObservation, PacmanInfo, MsPacmanConstants]):
    # Overlay / gym wrappers pass an index into ACTION_SET, not the ALE Action enum.
    ACTION_SET: jnp.ndarray = jnp.array([
        Action.NOOP,
        Action.UP,
        Action.RIGHT,
        Action.LEFT,
        Action.DOWN,
        Action.UPRIGHT,
        Action.UPLEFT,
        Action.DOWNRIGHT,
        Action.DOWNLEFT,
    ], dtype=jnp.int32)

    def __init__(self, consts: MsPacmanConstants = None):
        consts = consts or MsPacmanConstants()
        super().__init__(consts)
        self.frame_stack_size = 1
        # Precompute outside JIT so cached DOF mazes stay concrete arrays.
        self.dof_mazes = MsPacmanMaze.get_dof_mazes()
        self.renderer = MsPacmanRenderer(self.consts)

    def action_space(self) -> spaces.Discrete:
        """Returns the action space for MsPacman.
        Actions are indices into ACTION_SET:
        0: NOOP
        1: UP
        2: RIGHT
        3: LEFT
        4: DOWN
        5: UPRIGHT
        6: UPLEFT
        7: DOWNRIGHT
        8: DOWNLEFT
        """
        return spaces.Discrete(len(self.ACTION_SET))

    def reset(self, key=None) -> Tuple[PacmanObservation, PacmanState]:
        """
        Resets the game to its initial state.
        """
        if key is None:
            key = jax.random.PRNGKey(0)
        state = reset_game(self.consts, self.consts.RESET_LEVEL, self.consts.INITIAL_LIVES, 0, key)
        return self._get_observation(state), state

    def render(self, state: PacmanState) -> jnp.ndarray:
        return self.renderer.render(state)

    @partial(jax.jit, static_argnums=(0,))
    def step(self, state: PacmanState, action: chex.Array) -> tuple[
        PacmanObservation, PacmanState, jax.Array, jax.Array, PacmanInfo]:
        """
        Updates the game state by applying the game logic on the current state.
        """
        key, step_key = jax.random.split(state.key)
        
        ( # 1) If in death animation, decrement timer and freeze everything
            new_state,
            frozen,
            done
        ) = self.death_step(state, step_key, self.consts)
        
        maze_idx = get_level_maze(state.level.id)
        dofmaze = self.dof_mazes[maze_idx]

        # Map action-set index → ALE Action enum (player_step expects enum values).
        atari_action = jnp.take(self.ACTION_SET, action.astype(jnp.int32))

        ( # 2) Pacman handling
            player_position,
            player_action,
            pellets,
            has_pellet,
            collected_pellets,
            power_pellets,
            ate_power_pellet,
            pellet_reward,
            level_id
        ) = self.player_step(state, atari_action, dofmaze, self.consts)

        ( # 3) Fruit handling
            fruit_state,
            fruit_reward
        ) = self.fruit_step(state, player_position, collected_pellets, dofmaze, step_key, self.consts)

        ( # 4) Ghost handling
            ghost_positions,
            ghost_actions,
            ghost_modes,
            ghost_timers,
            eaten_ghosts,
            new_lives,
            new_death_timer,
            ghosts_reward,
            new_eat_freeze
        ) = self.ghosts_step(state, ate_power_pellet, dofmaze, step_key, self.consts)

        # 5) Calculate reward, new score, bonus life and flag score change digit-wise
        reward = pellet_reward + fruit_reward + ghosts_reward
        new_score = state.score + reward
        score_changed = self.flag_score_change(state.score, new_score, self.consts)
        new_lives = jax.lax.cond(
            (new_score >= self.consts.BONUS_LIFE_SCORE) & (state.score < self.consts.BONUS_LIFE_SCORE),
            lambda: new_lives + 1,
            lambda: new_lives
        )
        
        # 6) Update state
        # During START_DELAY or eat-ghost freeze, keep entities still but advance
        # step_count so flicker / ghost look-left-right animations keep running.
        paused = (state.step_count < self.consts.START_DELAY) | (state.eat_freeze_timer > 0)
        new_state = jax.lax.cond(
            frozen,
            lambda: new_state.replace(key=key),
            lambda: jax.lax.cond(
                paused,
                lambda: state.replace(
                    step_count=state.step_count + 1,
                    eat_freeze_timer=jnp.where(
                        state.eat_freeze_timer > 0,
                        state.eat_freeze_timer - 1,
                        state.eat_freeze_timer,
                    ),
                    key=key,
                ),
                lambda: jax.lax.cond(
                    level_id != state.level.id,
                    lambda: reset_game(self.consts, level_id, state.lives, new_score, key),
                    lambda: PacmanState(
                        level = LevelState(
                            id=level_id,
                            collected_pellets=collected_pellets,
                            pellets=pellets,
                            power_pellets=power_pellets,
                            loaded=jax.lax.cond(
                                state.level.loaded < 2,
                                lambda: state.level.loaded + 1,
                                lambda: state.level.loaded
                            )
                        ),
                        player = PlayerState(
                            position=player_position,
                            action=player_action,
                            has_pellet=has_pellet,
                            eaten_ghosts=eaten_ghosts
                        ),
                        ghosts = GhostsState(
                            positions=ghost_positions,
                            types=state.ghosts.types,
                            actions=ghost_actions,
                            modes=ghost_modes,
                            timers=ghost_timers
                        ),
                        fruit=fruit_state,
                        lives=new_lives,
                        score=new_score,
                        score_changed=score_changed,
                        freeze_timer=new_death_timer,
                        eat_freeze_timer=new_eat_freeze,
                        step_count=state.step_count + 1,
                        key=key
                    )
                )
            )
        )

        # 7) Get observation, info and reward
        observation = self._get_observation(new_state)
        info = self.get_info(new_state)
        reward = jax.lax.cond(
            frozen | (state.step_count < self.consts.START_DELAY) | (state.eat_freeze_timer > 0),
            lambda: jnp.array(0, dtype=jnp.uint32),
            lambda: jnp.array(reward, dtype=jnp.uint32)
        )
        return observation, new_state, reward, done, info
    
    @staticmethod
    def get_observation(state: PacmanState, consts: MsPacmanConstants):
        return JaxPacman._observation_from_state(state, consts)

    @staticmethod
    @partial(jax.jit, static_argnums=(1,))
    def _observation_from_state(state: PacmanState, consts: MsPacmanConstants) -> PacmanObservation:
        player_pos = state.player.position.astype(jnp.int32)
        player_orientation = _action_orientation(state.player.action)
        player_box = jnp.asarray(consts.PACMAN_INK_BOXES, dtype=jnp.int32)[player_orientation.astype(jnp.int32)]
        player = ObjectObservation.create(
            x=jnp.minimum(player_pos[0], consts.WIDTH - consts.PACMAN_WIDTH) + player_box[0],
            y=player_pos[1] - 1 + player_box[1],
            width=player_box[2],
            height=player_box[3],
            orientation=player_orientation,
        )

        ghost_pos = state.ghosts.positions.astype(jnp.int32)
        ghost_orientation = _action_orientation(state.ghosts.actions)
        ghosts = ObjectObservation.create(
            x=ghost_pos[:, 0],
            y=ghost_pos[:, 1] - 1,
            width=jnp.minimum(consts.GHOST_WIDTH, consts.WIDTH - ghost_pos[:, 0]),
            height=jnp.full((4,), consts.GHOST_HEIGHT, dtype=jnp.int32),
            visual_id=state.ghosts.types.astype(jnp.int32),
            state=state.ghosts.modes.astype(jnp.int32),
            orientation=ghost_orientation,
        )

        fruit_pos = state.fruit.position.astype(jnp.int32)
        fruit_size = jnp.asarray(consts.FRUIT_INK_SIZES, dtype=jnp.int32)[state.fruit.type.astype(jnp.int32)]
        fruit_orientation = _action_orientation(state.fruit.action)
        fruit = ObjectObservation.create(
            x=jnp.minimum(fruit_pos[0], consts.WIDTH - consts.FRUIT_WIDTH),
            y=jnp.maximum(fruit_pos[1] - 1, 0),
            width=fruit_size[0],
            height=fruit_size[1],
            active=state.fruit.spawned.astype(jnp.int32),
            visual_id=state.fruit.type.astype(jnp.int32),
            orientation=fruit_orientation,
        )

        power_pellet_tiles = jnp.asarray(consts.POWER_PELLET_TILES)
        power_x = (power_pellet_tiles[:, 0] * MsPacmanMaze.TILE_SCALE + 4).astype(jnp.int32)
        power_y = (power_pellet_tiles[:, 1] * MsPacmanMaze.TILE_SCALE + 6).astype(jnp.int32)
        power_pellets = ObjectObservation.create(
            x=power_x,
            y=power_y,
            width=jnp.full((4,), consts.POWER_PELLET_WIDTH, dtype=jnp.int32),
            height=jnp.full((4,), consts.POWER_PELLET_HEIGHT, dtype=jnp.int32),
            active=state.level.power_pellets.astype(jnp.int32),
        )

        grid_w, grid_h = state.level.pellets.shape
        grid_x, grid_y = jnp.meshgrid(jnp.arange(grid_w), jnp.arange(grid_h), indexing="ij")
        pellet_x = jnp.where(grid_x < 9, grid_x * 8 + 8, grid_x * 8 + 12)
        pellet_y = grid_y * 12 + 9
        pellet_w = jnp.where(grid_x == 8, 8, 4)
        maze = MsPacmanMaze.MAZES[get_level_maze(state.level.id)]
        tile = MsPacmanMaze.TILE_SCALE
        on_path = ~maze[pellet_y // tile, pellet_x // tile] & ~maze[pellet_y // tile, (pellet_x + pellet_w - 1) // tile]
        n_pellets = grid_w * grid_h
        pellets = ObjectObservation.create(
            x=pellet_x.reshape(-1).astype(jnp.int32),
            y=pellet_y.reshape(-1).astype(jnp.int32),
            width=pellet_w.reshape(-1).astype(jnp.int32),
            height=jnp.full((n_pellets,), 2, dtype=jnp.int32),
            active=(state.level.pellets & on_path).reshape(-1).astype(jnp.int32),
        )

        return PacmanObservation(
            player=player,
            ghosts=ghosts,
            fruit=fruit,
            power_pellets=power_pellets,
            pellets=pellets,
        )

    @staticmethod
    @jax.jit
    def get_info(state: PacmanState):
        return PacmanInfo(
            level=state.level.id,
            score=state.score,
            lives=state.lives
        )

    def _get_observation(self, state: PacmanState) -> PacmanObservation:
        return JaxPacman.get_observation(state, self.consts)

    def _get_info(self, state: PacmanState, all_rewards=None) -> PacmanInfo:
        return JaxPacman.get_info(state)

    def _get_reward(self, previous_state: PacmanState, state: PacmanState) -> chex.Array:
        return (state.score - previous_state.score).astype(jnp.float32)

    def _get_done(self, state: PacmanState) -> chex.Array:
        return state.lives < 0

    def observation_space(self) -> spaces.Dict:
        screen_size = (self.consts.HEIGHT, self.consts.WIDTH)
        return spaces.Dict({
            "player": spaces.get_object_space(n=None, screen_size=screen_size),
            "ghosts": spaces.get_object_space(n=4, screen_size=screen_size),
            "fruit": spaces.get_object_space(n=None, screen_size=screen_size),
            "power_pellets": spaces.get_object_space(n=4, screen_size=screen_size),
            "pellets": spaces.get_object_space(n=MsPacmanMaze.BASE_PELLETS.size, screen_size=screen_size),
        })

    def image_space(self) -> spaces.Box:
        return spaces.Box(low=0, high=255, shape=(210, 160, 3), dtype=jnp.uint8)

    @staticmethod
    def death_step(state: PacmanState, key: chex.PRNGKey, consts: MsPacmanConstants):
        """
        Updates the game state when a deadly collision occured.
        """
        def decrement_timer(state: PacmanState):
            return state.replace(freeze_timer=state.freeze_timer - 1)

        return jax.lax.cond(
            state.freeze_timer == 0,
            lambda: (state, False, False), # Alive
            lambda: jax.lax.cond(
                state.freeze_timer > 1,
                lambda: (decrement_timer(state), True, False), # Frozen
                lambda: jax.lax.cond(
                    state.lives == 0,
                    lambda: (decrement_timer(state), True, True), # Game Over,
                    lambda: (reset_entities(consts, decrement_timer(state), key), True, False) # Level Reset
                )
            )
        )

    @staticmethod
    def player_step(state: PacmanState, action: chex.Array, dofmaze: chex.Array, consts: MsPacmanConstants):
        """
        Updates the players position and orientation based on his input and the current maze layout.
        """
        # 1) Determine the last pressed action and check for validity
        action = last_pressed_action(action, state.player.action)
        action = jnp.asarray(action, dtype=state.player.action.dtype)
        action = jax.lax.cond(
            (action < 0) | (action > len(consts.ACTIONS) - 1),
            lambda: jnp.array(Action.NOOP, dtype=state.player.action.dtype), # Ignore illegal actions
            lambda: action
        )
        # 2) Determine the next action based on the available directions
        available = available_directions(state.player.position, dofmaze)
        new_action = jax.lax.cond(
            (action != Action.NOOP) & available[act_to_dir(action)],
            lambda: action,
            lambda: state.player.action
        )
        # 3) Compute the next position (ALE moves every other frame; X/Y step sizes differ)
        blocked = stop_wall(state.player.position, dofmaze)[act_to_dir(state.player.action)]
        skip_move = (state.step_count % consts.MOVE_PERIOD != 0) | blocked
        new_pos = jax.lax.cond(
            skip_move,
            lambda: state.player.position,
            lambda: get_new_position(state.player.position, new_action, consts)
        )
        # 4) Update pellets based on the new player position
        (
            pellets,
            has_pellet,
            collected_pellets,
            power_pellets,
            ate_power_pellet,
            reward,
            level_id
        ) = JaxPacman.pellet_step(state, new_pos, consts)
        # 5) Return new player and pellet state
        return (
            new_pos,
            new_action,
            pellets,
            has_pellet,
            collected_pellets,
            power_pellets,
            ate_power_pellet,
            reward,
            level_id
        )

    @staticmethod
    def pellet_step(state: PacmanState, new_pacman_pos: chex.Array, consts: MsPacmanConstants):
        """
        Updates pellets based on the players position and applies resulting score and mode changes.
        """
        def check_power_pellet(idx: chex.Array, power_pellets: chex.Array):
            return jax.lax.cond(
                idx < 0,
                lambda: False,
                lambda: power_pellets[idx % 4]
            )
        
        def eat_power_pellet(idx: chex.Array, power_pellets: chex.Array):
            return power_pellets.at[idx % 4].set(False)
        
        def check_pellet(pos: chex.Array):
            x_offset = jax.lax.cond(pos[0] < 75, lambda: 5, lambda: 1)
            return (pos[0] % 8 == x_offset) & (pos[1] % 12 == 6)
            
        def eat_pellet(pos: chex.Array, pellets: chex.Array):
            tile_x, tile_y = (pos[0] - 2) // 8, (pos[1] + 4) // 12
            in_bounds = (tile_x >= 0) & (tile_x < pellets.shape[0]) & (tile_y >= 0) & (tile_y < pellets.shape[1])
            return jax.lax.cond(
                pellets[tile_x, tile_y] & in_bounds,
                lambda: (pellets.at[tile_x, tile_y].set(False), True),
                lambda: (pellets, False)
            )
        
        # 1) Check if a regular pellet was eaten
        pellets, ate_pellet = jax.lax.cond(
            check_pellet(new_pacman_pos),
            lambda: eat_pellet(new_pacman_pos, state.level.pellets),
            lambda: (state.level.pellets, False)
        )
        # 2) Check if a power pellet was eaten
        # Optimized hit detection avoiding jnp.where(..., size=1)
        power_pellet_matches = jnp.all(jnp.round(new_pacman_pos / MsPacmanMaze.TILE_SCALE) == jnp.asarray(consts.POWER_PELLET_HITBOXES), axis=1)
        has_hit = jnp.any(power_pellet_matches)
        power_pellet_hit = jnp.where(has_hit, jnp.argmax(power_pellet_matches), -1)

        power_pellets, ate_power_pellet = jax.lax.cond(
            check_power_pellet(power_pellet_hit, state.level.power_pellets),
            lambda: (eat_power_pellet(power_pellet_hit, state.level.power_pellets), True),
            lambda: (state.level.power_pellets, False)
        )
        # 3) Process pellet reward
        reward = jax.lax.cond(
            ate_power_pellet,
            lambda: consts.POWER_PELLET_POINTS,
            lambda: jax.lax.cond(
                ate_pellet,
                lambda: consts.PELLET_POINTS,
                lambda: 0
            )
        )
        # 4) Update collected pellets
        has_pellet = ate_power_pellet | ate_pellet
        collected_pellets = jax.lax.cond(
            has_pellet,
            lambda: state.level.collected_pellets + 1,
            lambda: state.level.collected_pellets
        )
        # 5) Check win condition
        level_id, reward = jax.lax.cond(
            collected_pellets >= jnp.asarray(consts.PELLETS_TO_COLLECT)[get_level_maze(state.level.id)],
            lambda: (state.level.id + 1, reward),
            lambda: (state.level.id, reward)
        )
        # 6) Update pellet state
        return (
            pellets,
            has_pellet,
            collected_pellets,
            power_pellets,
            ate_power_pellet,
            reward,
            level_id
        )

    @staticmethod
    def ghosts_step(state: PacmanState, ate_power_pellet: chex.Array, dofmaze: chex.Array, common_key: chex.Array, consts: MsPacmanConstants
                    ) -> Tuple[chex.Array, chex.Array, chex.Array, chex.Array, chex.Array, chex.Array, chex.Array, chex.Array]:
        """
        Updates all ghosts and checks for collisions with the player.
        """
        ghost_keys  = jax.random.split(common_key, 4)

        def update_ghost_mode(mode, action, timer, step_count, ate_power_pellet):
            new_timer = jax.lax.cond(
                timer > 0,
                lambda: jnp.array(timer - 1.0, dtype=jnp.float16),
                lambda: jnp.array(timer, dtype=jnp.float16)
            )
            timing_factor = jax.lax.cond(
                state.level.id == 1,
                lambda: 1.0,
                lambda: consts.FRIGHTENED_REDUCTION ** (state.level.id - 1)
            )
            return jax.lax.cond(
                ate_power_pellet & (mode != GhostMode.ENJAILED) & (mode != GhostMode.RETURNING),
                lambda: (
                    jnp.array(GhostMode.FRIGHTENED, dtype=jnp.uint8),
                    jnp.array(reverse_action(action), dtype=jnp.uint8),
                    jnp.array(consts.FRIGHTENED_DURATION * timing_factor, dtype=jnp.float16),
                    True
                ),
                lambda: jax.lax.cond(
                    (timer > 0) & (new_timer <= 0),
                    lambda: jax.lax.switch(
                        mode,
                        (
                            start_chase_no_reverse, # 0: RANDOM
                            start_scatter,          # 1: CHASE
                            start_chase_offset,     # 2: SCATTER
                            start_blinking,         # 3: FRIGHTENED
                            start_chase_no_reverse, # 4: BLINKING
                            start_returned,         # 5: RETURNING
                            start_returning         # 6: ENJAILED
                        ),
                        action, step_count
                    ),
                    lambda: (
                        mode,
                        action,
                        new_timer,
                        False
                    )
                )
            )

        def start_scatter(action, step_count): # succeeds chase mode
            OFFSET_SCALE = 10.0
            scaled_offset = jnp.round(consts.MAX_SCATTER_OFFSET * OFFSET_SCALE)
            return (
                jnp.array(GhostMode.SCATTER, dtype=jnp.uint8),
                jnp.array(action, dtype=jnp.uint8),
                jnp.array(consts.SCATTER_DURATION + (jax.random.randint(common_key, (), -scaled_offset, scaled_offset) / OFFSET_SCALE), dtype=jnp.float16),
                False
            )
        
        def start_chase_offset(action, step_count): # succeeds scatter mode
            OFFSET_SCALE = 10.0
            scaled_offset = jnp.round(consts.MAX_CHASE_OFFSET * OFFSET_SCALE)
            return (
                jnp.array(GhostMode.CHASE, dtype=jnp.uint8),
                jnp.array(action, dtype=jnp.uint8),
                jnp.array(consts.CHASE_DURATION + (jax.random.randint(common_key, (), -scaled_offset, scaled_offset) / OFFSET_SCALE), dtype=jnp.float16),
                False
            )
        
        def start_chase_no_reverse(action, step_count): # succeeds blinking, returning and random mode
            return (
                jnp.array(GhostMode.CHASE, dtype=jnp.uint8),
                jnp.array(action, dtype=jnp.uint8),
                jnp.array(consts.CHASE_DURATION, dtype=jnp.float16),
                False
            )
        
        def start_returning(action, step_count): # succeeds enjailed mode
            return (
                jnp.array(GhostMode.RETURNING, dtype=jnp.uint8),
                jnp.array(Action.UP, dtype=jnp.uint8),
                jnp.array(consts.RETURN_DURATION, dtype=jnp.float16),
                True
            )
        
        def start_blinking(action, step_count): # succeeds frightened mode
            timing_factor = jax.lax.cond(
                state.level.id == 1,
                lambda: 1.0,
                lambda: consts.FRIGHTENED_REDUCTION ** (state.level.id - 1)
            )
            return (
                jnp.array(GhostMode.BLINKING, dtype=jnp.uint8),
                jnp.array(action, dtype=jnp.uint8),
                jnp.array(jnp.round(consts.BLINKING_DURATION * timing_factor), dtype=jnp.float16),
                False
            )
        
        def start_returned(action, step_count): # returning
            return jax.lax.cond(
                step_count > (consts.SCATTER_DURATION + 1) * consts.TIME_SCALE,
                lambda: start_chase_no_reverse(action, step_count),
                lambda: (
                    jnp.array(GhostMode.RANDOM, dtype=jnp.uint8),
                    jnp.array(action, dtype=jnp.uint8),
                    jnp.array(consts.SCATTER_DURATION, dtype=jnp.float16),
                    False
                )
            )

        def pathfind_target(type, mode, action, position, allowed, key):
            chase_target = jax.lax.cond(
                mode == GhostMode.CHASE,
                lambda: get_chase_target(type, position, state.ghosts.positions[GhostType.BLINKY], state.player.position, state.player.action, jnp.asarray(consts.ACTIONS), jnp.asarray(consts.SCATTER_TARGETS)),
                lambda: jnp.asarray(consts.SCATTER_TARGETS)[type]
            )
            return pathfind(position, action, chase_target, allowed, key, jnp.asarray(consts.ACTIONS), jnp.asarray(consts.DIRECTIONS))

        def choose_direction(type, mode, action, position, key):
            allowed = get_allowed_directions(position, action, dofmaze, jnp.asarray(consts.DIRECTIONS), is_ghost=True)
            n_allowed = jnp.sum(allowed != 0)
            return jax.lax.cond(
                n_allowed == 0,
                lambda: action,
                lambda: jax.lax.cond(
                    n_allowed == 1,
                    lambda: allowed[0],
                    lambda: jax.lax.cond(
                        (mode == GhostMode.FRIGHTENED) | (mode == GhostMode.BLINKING) | (mode == GhostMode.RANDOM) | (mode == GhostMode.RETURNING),
                        lambda: allowed[jax.random.randint(key, (), minval=0, maxval=n_allowed)],
                        lambda: pathfind_target(type, mode, action, position, allowed, key)
                    )
                )
            )

        def ghost_step_single(ghost_type, mode, action, position, timer, key):
            new_mode, new_action, new_timer, skip = update_ghost_mode(
                mode, action, timer, state.step_count, ate_power_pellet
            )

            new_action = jnp.asarray(
                jax.lax.cond(
                    skip | (new_mode == GhostMode.ENJAILED) | (new_mode == GhostMode.RETURNING),
                    lambda: new_action,
                    lambda: choose_direction(ghost_type, new_mode, new_action, position, key)
                ),
                dtype=jnp.uint8
            )

            is_slow = (
                (mode == GhostMode.FRIGHTENED) |
                (mode == GhostMode.BLINKING) |
                (mode == GhostMode.RETURNING)
            )
            # Normal ghosts match ALE (every other frame); frightened/returning stay at half that speed.
            skip_move = (state.step_count % consts.MOVE_PERIOD != 0) | (
                is_slow & (state.step_count % (consts.MOVE_PERIOD * 2) != 0)
            )
            new_position, new_action = jax.lax.cond(
                skip_move,
                lambda: (position, new_action),
                lambda: (get_new_position(position, new_action, consts), new_action)
            )
            return new_mode, new_action, new_position, new_timer

        vmapped_ghost_step = jax.vmap(ghost_step_single)
        new_modes, new_actions, new_positions, new_timers = vmapped_ghost_step(
            state.ghosts.types,
            state.ghosts.modes,
            state.ghosts.actions,
            state.ghosts.positions,
            state.ghosts.timers,
            ghost_keys
        )
        
        ( # Check for player collision
            new_positions,
            new_actions,
            new_modes,
            new_timers,
            eaten_ghosts,
            new_lives,
            new_death_timer,
            reward,
            new_eat_freeze
        ) = JaxPacman.ghosts_collision(
            new_positions,
            new_actions,
            new_modes,
            new_timers,
            state.player.position,
            state.player.eaten_ghosts,
            ate_power_pellet,
            state.lives,
            consts)

        return (
            new_positions,
            new_actions,
            new_modes,
            new_timers,
            eaten_ghosts,
            new_lives,
            new_death_timer,
            reward,
            new_eat_freeze
        )

    @staticmethod
    def ghosts_collision(ghost_positions: chex.Array, ghost_actions: chex.Array, ghost_modes: chex.Array, ghost_timers: chex.Array,
                                new_pacman_pos: chex.Array, eaten_ghosts: chex.Array, ate_power_pellet: chex.Array, lives: chex.Array, consts: MsPacmanConstants):
        """
        Updates the game state if a player-ghost collision occured.
        """
        def handle_ghost_collision_single(ghost_index, ghost_pos, ghost_mode, ghost_action, ghost_timer, current_eaten_ghosts):
            collision = detect_collision(new_pacman_pos, ghost_pos, consts.COLLISION_THRESHOLD)
            
            is_frightened = (ghost_mode == GhostMode.FRIGHTENED) | (ghost_mode == GhostMode.BLINKING)
            
            # Case 1: Ghost eaten
            eaten_reward = consts.EAT_GHOSTS_BASE_POINTS * (2 ** current_eaten_ghosts.astype(jnp.uint32))
            
            # We need to know if THIS ghost was eaten to update its state
            this_ghost_eaten = collision & is_frightened
            
            new_pos = jnp.where(this_ghost_eaten, jnp.asarray(consts.JAIL_POSITION), ghost_pos)
            new_act = jnp.where(this_ghost_eaten, Action.NOOP, ghost_action)
            new_mode = jnp.where(this_ghost_eaten, GhostMode.ENJAILED.value, ghost_mode)
            new_timer = jnp.where(this_ghost_eaten, consts.ENJAILED_DURATION, ghost_timer)
            
            # Case 2: Deadly collision
            deadly = collision & (~is_frightened)
            
            return new_pos, new_act, new_mode, new_timer, this_ghost_eaten, deadly, eaten_reward

        # Since ghosts are processed one by one for eaten_ghosts count in the original, 
        # but the order doesn't strictly matter for a single frame (only 1 ghost can be at a position usually, 
        # but even if multiple are, ALE handles them).
        # To match the original logic of incrementing eaten_ghosts, we can use a loop or a clever prefix sum.
        # But there are only 4 ghosts, so let's just use a loop for the eaten_ghosts count if we want to be exact,
        # OR just vmap and sum the rewards.
        
        # Vectorized collision check
        collisions = jax.vmap(detect_collision, in_axes=(None, 0, None))(new_pacman_pos, ghost_positions, consts.COLLISION_THRESHOLD)
        is_frightened = (ghost_modes == GhostMode.FRIGHTENED) | (ghost_modes == GhostMode.BLINKING)
        
        ghosts_eaten = collisions & is_frightened
        deadly_collision = jnp.any(collisions & (~is_frightened))
        
        # Calculate rewards based on how many ghosts were already eaten this power pellet
        # and how many are eaten THIS step.
        base_eaten = jax.lax.cond(ate_power_pellet, lambda: jnp.array(0, dtype=jnp.uint8), lambda: eaten_ghosts)
        
        # Optimized reward calculation using prefix sum (cumsum)
        # Match ALE logic where eating multiple ghosts in one step increases reward multiplier per ghost.
        eaten_this_step = ghosts_eaten.astype(jnp.int32)
        eaten_so_far = jnp.cumsum(eaten_this_step)
        
        # Multiplier for each ghost: base_eaten + its order in this step's eaten batch
        multipliers = base_eaten + eaten_so_far - 1
        rewards = jnp.where(ghosts_eaten, consts.EAT_GHOSTS_BASE_POINTS * (2 ** multipliers.astype(jnp.uint32)), 0)
        total_reward = jnp.sum(rewards)
        final_eaten_count = base_eaten + jnp.sum(eaten_this_step)

        # Update ghost states
        new_ghost_positions = jnp.where(ghosts_eaten[:, None], jnp.asarray(consts.JAIL_POSITION), ghost_positions)
        new_ghost_actions = jnp.where(ghosts_eaten, Action.NOOP, ghost_actions)
        new_ghost_modes = jnp.where(ghosts_eaten, GhostMode.ENJAILED.value, ghost_modes)
        new_ghost_timers = jnp.where(ghosts_eaten, consts.ENJAILED_DURATION, ghost_timers)

        new_lives = (lives - jnp.where(deadly_collision, 1, 0)).astype(jnp.int8)
        new_death_timer = jnp.where(deadly_collision, consts.RESET_TIMER, 0).astype(jnp.uint32)
        new_eat_freeze = jnp.where(
            jnp.any(ghosts_eaten),
            consts.EAT_GHOST_FREEZE,
            0
        ).astype(jnp.uint32)
        
        return (
            new_ghost_positions,
            new_ghost_actions,
            new_ghost_modes,
            new_ghost_timers,
            final_eaten_count.astype(jnp.uint8),
            new_lives,
            new_death_timer,
            total_reward,
            new_eat_freeze
        )

    @staticmethod
    def fruit_move(state: PacmanState, dofmaze: chex.Array, key: chex.Array, consts: MsPacmanConstants
                   ) -> Tuple[chex.Array, chex.Array]:
        """
        Updates the fruits position, action and timer if one is currently active.
        """
        # Choose new direction based on last position, action and fruit timer
        allowed = get_allowed_directions(state.fruit.position, state.fruit.action, dofmaze, jnp.asarray(consts.DIRECTIONS))
        n_allowed = jnp.sum(allowed != 0)
        new_dir = jax.lax.cond(
            n_allowed == 0,
            lambda: state.fruit.action,
            lambda: jax.lax.cond(
                n_allowed == 1,
                lambda: allowed[0],
                lambda: jax.lax.cond(
                    state.fruit.timer == 0,
                    lambda: pathfind(state.fruit.position, state.fruit.action, state.fruit.exit, allowed, key, jnp.asarray(consts.ACTIONS), jnp.asarray(consts.DIRECTIONS)),
                    lambda: allowed[jax.random.randint(key, (), minval=0, maxval=n_allowed)]
                )
            )
        )
        # Compute the new position
        new_pos = get_new_position(state.fruit.position, new_dir, consts)
        # Return new position and direction values
        return (
            jnp.array(new_pos, dtype=jnp.uint8),
            jnp.array(new_dir, dtype=jnp.uint8)
        )

    @staticmethod
    def fruit_step(state: PacmanState, new_pacman_pos: chex.Array, collected_pellets: chex.Array, dofmaze: chex.Array, key: chex.Array, consts: MsPacmanConstants):
        """
        Updates the fruit state if a fruit spawns, moves or is consumed.
        """
        def spawn_fruit(fruit_spawn: bool):
            fruit_position, fruit_action = get_random_tunnel(state.level.id, key)
            fruit_exit, _ = get_random_tunnel(state.level.id, key)
            return FruitState(
                jnp.array(fruit_position, dtype=jnp.uint8),
                jnp.array(fruit_exit, dtype=jnp.uint8),
                state.fruit.type,
                jnp.array(fruit_action, dtype=jnp.uint8),
                jnp.array(False, dtype=jnp.bool),
                jnp.array(True, dtype=jnp.bool),
                jnp.array(consts.FRUIT_WANDER_DURATION, dtype=jnp.uint16)
            ), 0
        
        def do_nothing(fruit_spawn: bool):
            return FruitState(
                state.fruit.position,
                state.fruit.exit,
                state.fruit.type,
                state.fruit.action,
                state.fruit.spawn | fruit_spawn,
                state.fruit.spawned,
                state.fruit.timer
            ), 0
        
        def consume_fruit(fruit_spawn: bool):
            return FruitState(
                jnp.zeros(2, dtype=jnp.uint8),
                jnp.zeros(2, dtype=jnp.uint8),
                state.fruit.type,
                jnp.array(Action.NOOP, dtype=jnp.uint8),
                state.fruit.spawn | fruit_spawn,
                jnp.array(False, dtype=jnp.bool),
                jnp.array(consts.FRUIT_WANDER_DURATION, dtype=jnp.uint16)
            ), jnp.asarray(consts.FRUIT_REWARDS)[state.fruit.type]
        
        def remove_fruit(fruit_spawn: bool):
            return FruitState(
                jnp.zeros(2, dtype=jnp.uint8),
                jnp.zeros(2, dtype=jnp.uint8),
                state.fruit.type,
                jnp.array(Action.NOOP, dtype=jnp.uint8),
                state.fruit.spawn | fruit_spawn,
                jnp.array(False, dtype=jnp.bool),
                jnp.array(consts.FRUIT_WANDER_DURATION, dtype=jnp.uint16)
            ), 0
        
        def step_fruit(fruit_spawn: bool):
            fruit_type = get_level_fruit(state.level.id, key)
            fruit_position, fruit_action = jax.lax.cond(
                state.step_count % consts.MOVE_PERIOD == 0,
                lambda: JaxPacman.fruit_move(state, dofmaze, key, consts),
                lambda: (state.fruit.position, state.fruit.action)
            )
            fruit_timer = jax.lax.cond(
                state.fruit.timer > 0,
                lambda: state.fruit.timer - 1,
                lambda: state.fruit.timer
            )
            return FruitState(
                fruit_position,
                state.fruit.exit,
                jnp.array(fruit_type, dtype=jnp.uint8),
                fruit_action,
                state.fruit.spawn | fruit_spawn,
                state.fruit.spawned,
                fruit_timer
            ), 0
        
        fruit_spawn = jnp.any(jnp.asarray(consts.FRUIT_SPAWN_THRESHOLDS) == collected_pellets) & state.player.has_pellet
        new_fruit_state, reward = jax.lax.cond(
            state.fruit.spawned,
            lambda: jax.lax.cond(
                detect_collision(new_pacman_pos, state.fruit.position, consts.COLLISION_THRESHOLD),
                lambda: consume_fruit(fruit_spawn),
                lambda: jax.lax.cond(
                    (state.fruit.timer == 0) & (jnp.all(jnp.array(state.fruit.position) == jnp.array(state.fruit.exit))),
                    lambda: remove_fruit(fruit_spawn),
                    lambda: step_fruit(fruit_spawn)
                )   
            ),
            lambda: jax.lax.cond(
                state.fruit.spawn,
                lambda: spawn_fruit(fruit_spawn),
                lambda: do_nothing(fruit_spawn)
            )
        ) 
        return new_fruit_state, reward

    @staticmethod
    def flag_score_change(current_score: chex.Array, new_score: chex.Array, consts: MsPacmanConstants):
        """
        Flags the score digits for rendering that changed during the current step.
        """
        powers = 10 ** jnp.arange(consts.MAX_SCORE_DIGITS)
        # Check if (current_score // powers) % 10 != (new_score // powers) % 10
        changed = (current_score // powers) % 10 != (new_score // powers) % 10
        return jnp.flip(changed) # Match digit order: [10^5, 10^4, ..., 10^0]


# -------- Render class --------
class MsPacmanRenderer(JAXGameRenderer):
    """JAX-based MsPacman game renderer, optimized with JIT compilation."""

    def _ensure_palette_color(self, color_rgb: tuple[int, int, int]) -> None:
        color_rgba = (*color_rgb, 255)
        if color_rgb in self.COLOR_TO_ID:
            return
        if color_rgba in self.COLOR_TO_ID:
            self.COLOR_TO_ID[color_rgb] = self.COLOR_TO_ID[color_rgba]
            return
        self.PALETTE, color_id = self.jr.add_palette_color(self.PALETTE, color_rgb)
        self.COLOR_TO_ID[color_rgb] = int(color_id)
        self.COLOR_TO_ID[color_rgba] = int(color_id)

    def _resolve_color_id(self, color_rgb: tuple[int, int, int]) -> int:
        self._ensure_palette_color(color_rgb)
        return self.COLOR_TO_ID.get(color_rgb, self.jr.TRANSPARENT_ID)

    def _build_pacman_oriented_group(self, sprite_path: str) -> list[jnp.ndarray]:
        """
        Build Pacman animation sprites as a single orientation-major group:
        [UP frames][RIGHT frames][LEFT frames][DOWN frames].
        """
        left_frames = [
            self.jr.loadFrame(os.path.join(sprite_path, f"pacman_{i}.npy"))
            for i in range(4)
        ]
        right_frames = [jnp.flip(frame, axis=1) for frame in left_frames]
        up_frames = [jnp.rot90(frame, k=1, axes=(0, 1)) for frame in right_frames]
        down_frames = [jnp.rot90(frame, k=3, axes=(0, 1)) for frame in right_frames]
        return up_frames + right_frames + left_frames + down_frames

    def __init__(self, consts: MsPacmanConstants = None, config: render_utils.RendererConfig = None, sprite_dir_name: str = "mspacman"):
        super().__init__(consts)
        self.consts = consts or MsPacmanConstants()
        if config is None:
            self.config = render_utils.RendererConfig(
                game_dimensions=(210, 160),
                channels=3
            )
        else:
            self.config = config
        self.jr = render_utils.JaxRenderingUtils(self.config)
        
        sprite_path = os.path.join(render_utils.get_base_sprite_dir(), sprite_dir_name)
        
        # Effective colors
        bg_color = self.consts.RGB_BACKGROUND or (0, 0, 0)
        wall_color = self.consts.RGB_WALLS or tuple(self.consts.WALL_COLOR[:3])
        path_color = self.consts.RGB_PATH or tuple(self.consts.PATH_COLOR[:3])
        pacman_color = self.consts.RGB_PACMAN or tuple(self.consts.PACMAN_COLOR[:3])
        pellet_color = self.consts.RGB_PELLETS or wall_color # Default to wall color if not specified
        score_color = self.consts.RGB_SCORE or (255, 255, 255) # Default white for score

        # Define asset config
        asset_config = [
            {'name': 'dummy_bg', 'type': 'background', 'data': jnp.zeros((210, 160, 4), dtype=jnp.uint8).at[:, :, :3].set(jnp.array(bg_color, dtype=jnp.uint8))},
            {'name': 'pacman_oriented', 'type': 'group', 'data': self._build_pacman_oriented_group(sprite_path)},
            {'name': 'ghosts', 'type': 'group', 'files': [
                'ghost_blinky.npy', 'ghost_pinky.npy', 'ghost_inky.npy', 'ghost_sue.npy', 
                'ghost_blue.npy', 'ghost_white.npy'
            ]},
            {'name': 'fruit', 'type': 'group', 'files': [
                'fruit_cherry.npy', 'fruit_strawberry.npy', 'fruit_orange.npy',
                'fruit_pretzel.npy', 'fruit_apple.npy', 'fruit_pear.npy', 'fruit_banana.npy'
            ]},
            {'name': 'digits', 'type': 'digits', 'pattern': 'score_{}.npy'},
        ]
        
        # Apply recoloring rules if any overrides are present
        has_recolorings = False
        for i in range(len(asset_config)):
            asset = asset_config[i]
            asset_name = asset['name']
            rules = []
            
            if asset_name == 'pacman_oriented':
                if self.consts.RGB_PACMAN is not None:
                    rules.append({'target': pacman_color})
            elif asset_name == 'ghosts':
                # Blinky (Red), Pinky (Pink), Inky (Cyan), Sue (Orange)
                # Blue (Frightened), White (Blinking)
                if self.consts.RGB_GHOST_BLINKY is not None:
                    rules.append({'source': (228, 111, 111), 'target': self.consts.RGB_GHOST_BLINKY})
                if self.consts.RGB_GHOST_PINKY is not None:
                    rules.append({'source': (228, 164, 228), 'target': self.consts.RGB_GHOST_PINKY})
                if self.consts.RGB_GHOST_INKY is not None:
                    rules.append({'source': (24, 164, 180), 'target': self.consts.RGB_GHOST_INKY})
                if self.consts.RGB_GHOST_SUE is not None:
                    rules.append({'source': (210, 164, 74), 'target': self.consts.RGB_GHOST_SUE})
                if self.consts.RGB_GHOST_FRIGHTENED is not None:
                    rules.append({'source': (66, 72, 200), 'target': self.consts.RGB_GHOST_FRIGHTENED})
                if self.consts.RGB_GHOST_BLINKING is not None:
                    rules.append({'source': (255, 255, 255), 'target': self.consts.RGB_GHOST_BLINKING})
            elif asset_name == 'fruit':
                if self.consts.RGB_FRUIT is not None:
                    rules.append({'target': self.consts.RGB_FRUIT})
            elif asset_name == 'digits':
                if self.consts.RGB_SCORE is not None:
                    rules.append({'target': self.consts.RGB_SCORE})
            
            if rules:
                asset_config[i] = dict(asset)
                asset_config[i]['recolorings'] = {'mods': rules}
                has_recolorings = True

        # Include background colors in the palette (Path, Wall, and Black for UI padding)
        bg_colors = jnp.stack([jnp.array(path_color, dtype=jnp.uint8), jnp.array(wall_color, dtype=jnp.uint8), jnp.array(bg_color, dtype=jnp.uint8)])
        bg_colors = jnp.concatenate([bg_colors, jnp.full((3, 1), 255, dtype=jnp.uint8)], axis=1)
        asset_config.append({'name': 'bg_colors', 'type': 'procedural', 'data': bg_colors[:, None, :]})

        (self.PALETTE, self.SHAPE_MASKS, _, self.COLOR_TO_ID, self.FLIP_OFFSETS) = \
            self.jr.load_and_setup_assets(asset_config, sprite_path)

        for color in (path_color, wall_color, bg_color):
            self._ensure_palette_color(color)

        self._mask_suffix = '_mods' if has_recolorings else ''
        
        def get_mask(key):
            return self.SHAPE_MASKS.get(key + self._mask_suffix, self.SHAPE_MASKS[key])

        # Pacman mask group is loaded orientation-major:
        # 0: UP, 1: RIGHT, 2: LEFT, 3: DOWN, each with 4 animation frames.
        pacman_group = get_mask('pacman_oriented')
        self.PACMAN_MASKS = pacman_group.reshape(4, 4, pacman_group.shape[1], pacman_group.shape[2])
        
        # Pre-calculate backgrounds for all 4 mazes
        self.MAZE_BACKGROUNDS = self._create_all_backgrounds(
            jnp.array(wall_color, dtype=jnp.uint8),
            jnp.array(path_color, dtype=jnp.uint8)
        )
        
        self.wall_id = self._resolve_color_id(wall_color)
        self.pellet_id = self._resolve_color_id(pellet_color)

    def _create_all_backgrounds(self, wall_color=None, path_color=None):
        bgs = []
        for i in range(4):
            bg = MsPacmanMaze.load_background(i, wall_color=wall_color, path_color=path_color) # Returns (W, H, 3)
            bg = jnp.transpose(bg, (1, 0, 2)) # Convert to (H, W, 3)
            if bg.shape[2] == 3:
                bg = jnp.concatenate([bg, jnp.full((*bg.shape[:2], 1), 255, dtype=jnp.uint8)], axis=2)
            
            bg_id = self.jr._create_background_raster(bg, self.COLOR_TO_ID)
            bgs.append(bg_id)
        return jnp.stack(bgs)

    @partial(jax.jit, static_argnums=(0,))
    def render(self, state: PacmanState):
        maze_idx = get_level_maze(state.level.id)
        background = self.MAZE_BACKGROUNDS[maze_idx]
        raster = self.jr.create_object_raster(background)
        
        # 1. Render Pellets
        raster = self.render_pellets(raster, state.level.pellets, self.pellet_id)
        
        # 2. Power Pellets
        raster = self.render_power_pellets(raster, state, self.pellet_id)
        
        # 3. Pacman
        orientation = act_to_dir(state.player.action)
        orientation = jnp.where(orientation == -1, 2, orientation) # Default to LEFT
        frame = (state.step_count & 0b1000) >> 2
        pacman_mask = self.PACMAN_MASKS[orientation.astype(jnp.int32), frame.astype(jnp.int32)]
        raster = self.jr.render_at(raster, state.player.position[0].astype(jnp.int32), state.player.position[1].astype(jnp.int32) - 1, pacman_mask)
        
        # 4. Ghosts
        raster = self.render_ghosts(raster, state)
        
        # 5. Fruit
        raster = jax.lax.cond(
            state.fruit.spawned,
            lambda r: self.jr.render_at(r, state.fruit.position[0].astype(jnp.int32), state.fruit.position[1].astype(jnp.int32) - 1, self.SHAPE_MASKS['fruit'][state.fruit.type.astype(jnp.int32)]),
            lambda r: r,
            raster
        )
        
        # 6. UI
        raster = self.render_ui(raster, state)
        
        return self.jr.render_from_palette(raster, self.PALETTE)

    @partial(jax.jit, static_argnums=(0,))
    def render_pellets(self, raster, pellets, color_id):
        xx, yy = self.jr._xx, self.jr._yy
        
        # Inverse mapping: for each pixel, find which pellet grid cell it belongs to
        # py = gy * 12 + 9, height = 2
        gy = (yy - 9) // 12
        is_pellet_y = ((yy - 9) % 12 >= 0) & ((yy - 9) % 12 < 2)
        
        # px = gx * 8 + (8 if gx < 9 else 12), width = 4
        # The split point is around x = 75-80
        gx = jnp.where(xx < 76, (xx - 8) // 8, (xx - 12) // 8)
        is_pellet_x = jnp.where(xx < 76, 
                                ((xx - 8) % 8 >= 0) & ((xx - 8) % 8 < 4), 
                                ((xx - 12) % 8 >= 0) & ((xx - 12) % 8 < 4))
        
        # Bounds check
        in_grid = (gx >= 0) & (gx < 18) & (gy >= 0) & (gy < 14)
        
        # Correct for jnp.where indexing out of bounds by clipping gx, gy for the lookup
        gx_clipped = jnp.clip(gx, 0, 17)
        gy_clipped = jnp.clip(gy, 0, 13)
        
        # Pellet exists at this grid cell?
        pellet_exists = pellets[gx_clipped, gy_clipped]
        
        should_draw = is_pellet_pixel = in_grid & is_pellet_x & is_pellet_y & pellet_exists
        
        return jnp.where(should_draw, jnp.asarray(color_id, raster.dtype), raster)

    @partial(jax.jit, static_argnums=(0,))
    def render_power_pellets(self, raster, state, color_id):
        # 4x7 sprite
        sprite = jnp.full((7, 4), color_id, dtype=raster.dtype)
        
        should_draw = state.level.power_pellets & (((state.step_count & 0b1000) >> 3) == 1)
        x_coords = (jnp.asarray(self.consts.POWER_PELLET_TILES)[:, 0] * 4 + 4).astype(jnp.int32)
        y_coords = (jnp.asarray(self.consts.POWER_PELLET_TILES)[:, 1] * 4 + 6).astype(jnp.int32)
        
        # Filter positions
        x_coords = jnp.where(should_draw, x_coords, -1)
        y_coords = jnp.where(should_draw, y_coords, -1)
        
        masks = jnp.tile(sprite[None, ...], (4, 1, 1))
        
        return self.jr.render_at_batch(raster, x_coords, y_coords, masks)

    @partial(jax.jit, static_argnums=(0,))
    def render_ghosts(self, raster, state):
        anim_frame = (state.step_count & 0b10000) >> 4
        
        # Determine ghost indices
        is_frightened = (state.ghosts.modes == GhostMode.FRIGHTENED) | (state.ghosts.modes == GhostMode.BLINKING)
        is_blinking_frame = (state.ghosts.modes == GhostMode.BLINKING) & (((state.step_count & 0b1000) >> 3) == 1)
        
        ghost_indices = jnp.where(
            is_frightened,
            jnp.where(is_blinking_frame, 5, 4),
            jnp.arange(4)
        ).astype(jnp.int32)
        
        masks = self.SHAPE_MASKS['ghosts'][ghost_indices]
        
        # Flip masks if needed
        def flip_masks(m):
            return jnp.flip(m, axis=2)
        
        masks = jax.lax.cond(anim_frame == 1, flip_masks, lambda m: m, masks)
        
        x_coords = state.ghosts.positions[:, 0].astype(jnp.int32)
        y_coords = (state.ghosts.positions[:, 1] - 1).astype(jnp.int32)
        
        return self.jr.render_at_batch(raster, x_coords, y_coords, masks)

    @partial(jax.jit, static_argnums=(0,))
    def render_ui(self, raster, state):
        # Score
        digits = self.jr.int_to_digits(state.score, max_digits=self.consts.MAX_SCORE_DIGITS)
        digit_count = get_digit_count(state.score).astype(jnp.int32)
        start_index = self.consts.MAX_SCORE_DIGITS - digit_count
        render_x = 60 + start_index * 8
        raster = self.jr.render_label_selective(raster, render_x, 190, digits, self.SHAPE_MASKS['digits'], start_index, digit_count, spacing=8, max_digits_to_render=self.consts.MAX_SCORE_DIGITS)
        
        # Lives
        life_mask = self.PACMAN_MASKS[1, 1] # Right looking, frame 1
        raster = self.jr.render_indicator(raster, 12, 182, (state.lives - 1).astype(jnp.int32), life_mask, spacing=14, max_value=self.consts.MAX_LIVE_COUNT)
        
        # Fruit indicator
        fruit_mask = self.SHAPE_MASKS['fruit'][state.fruit.type.astype(jnp.int32)]
        raster = self.jr.render_at(raster, 128, 182, fruit_mask)
        
        return raster


# -------- Helper functions --------
def get_digit_count(number: chex.Array):
    """Returns the number of digits in a given decimal number."""
    number = jnp.abs(number)
    return jax.lax.cond(
        number == 0,
        lambda: jnp.array(1, dtype=jnp.uint8),
        lambda: jnp.floor(jnp.log10(number) + 1).astype(jnp.uint8)
    )


def act_to_dir(action: chex.Array):
    """Converts a Jaxtari action into the corresponding DIRECTION index.
    If conversion is not possible -1 is returned.

    action:     2 (UP)  3 (RIGHT)   4 (LEFT)    5 (DOWN)    ELSE
    direction:  0       1           2           3           -1
    """
    return jax.lax.cond(
        (action >= 2) & (action < 6),
        lambda: jnp.array(action - 2, dtype=jnp.int8),
        lambda: jnp.array(-1, dtype=jnp.int8)
    )


def _action_orientation(action: chex.Array) -> chex.Array:
    """Map ALE actions to observation orientation (0=UP, 1=RIGHT, 2=LEFT, 3=DOWN).

    Invalid / NOOP actions default to LEFT, matching the renderer.
    """
    direction = jnp.where((action >= 2) & (action < 6), action - 2, 2)
    return direction.astype(jnp.float32)


def dir_to_act(direction: chex.Array):
    """Converts a DIRECTION index into the corresponding Jaxtari action.
    If conversion is not possible -1 is returned.

    direction:  0       1           2           3           ELSE
    action:     2 (UP)  3 (RIGHT)   4 (LEFT)    5 (DOWN)    -1
    """
    return jax.lax.cond(
        (direction >= 0) & (direction < 4),
        lambda: jnp.array(direction + 2, dtype=jnp.int8),
        lambda: jnp.array(-1, dtype=jnp.int8)
    )


def last_pressed_action(action, prev_action):
    """Returns the last pressed action in cases where both actions are pressed"""
    return jax.lax.cond(
        action == Action.UPRIGHT,
        lambda: jax.lax.cond(
            prev_action == Action.UP,
            lambda: Action.RIGHT,
            lambda: Action.UP
        ),
        lambda: jax.lax.cond(
            action == Action.UPLEFT,
            lambda: jax.lax.cond(
                prev_action == Action.UP,
                lambda: Action.LEFT,
                lambda: Action.UP
            ),
            lambda: jax.lax.cond(
                action == Action.DOWNRIGHT,
                lambda: jax.lax.cond(
                    prev_action == Action.DOWN,
                    lambda: Action.RIGHT,
                    lambda: Action.DOWN
                ),
                lambda: jax.lax.cond(
                    action == Action.DOWNLEFT,
                    lambda: jax.lax.cond(
                        prev_action == Action.DOWN,
                        lambda: Action.LEFT,
                        lambda: Action.DOWN
                    ),
                    lambda: action
                )
            )
        )
    )


def dof(pos: chex.Array, dofmaze: chex.Array):
    """Degree of freedom of the object, can it move up, right, left, down"""
    x, y = pos
    grid_x = (x + 5) // 4
    grid_y = (y + 3) // 4
    return dofmaze[grid_x, grid_y]


def available_directions(pos: chex.Array, dofmaze: chex.Array):
    """
    What direction Pacman or the ghosts can take when at an intersection.
    Returns a tuple of booleans (up, right, left, down) indicating if
    the character can move in that direction.
    The character can only change direction if it is on a vertical or horizontal grid.

    Arguments:
    pos -- (x, y) position of the character
    dofmaze -- precomputed degree of freedom for a maze level/layout

    Returns:
    A tuple of booleans (up, right, left, down) indicating if the 
    character can move in that direction.
    """
    x, y = pos
    on_vertical_grid = x % 4 == 1 # can potentially move up/down
    on_horizontal_grid = y % 12 == 6 # can potentially move left/right
    up, right, left, down = dof(pos, dofmaze)
    return jnp.array([
        up & on_vertical_grid,
        right & on_horizontal_grid,
        left & on_horizontal_grid,
        down & on_vertical_grid
    ], dtype=jnp.bool_)


def stop_wall(pos: chex.Array, dofmaze: chex.Array):
    """
    What directions are blocked for Pacman or the ghosts when at an intersection.
    Returns a tuple of booleans (up, right, left, down) indicating if
    the direction is blocked by a wall.

    Arguments:
    pos -- (x, y) position of the character
    dofmaze -- precomputed degree of freedom for a maze level/layout

    Returns:
    A tuple of booleans (up, right, left, down) indicating if that
    direction is blocked by a wall.
    """
    x, y = pos
    on_vertical_grid = x % 4 == 1 # can potentially move up/down
    on_horizontal_grid = y % 12 == 6 # can potentially move left/right
    up, right, left, down = dof(pos, dofmaze)
    return jnp.array([
        ~up & on_horizontal_grid,
        ~right & on_vertical_grid,
        ~left & on_vertical_grid,
        ~down & on_horizontal_grid
    ], dtype=jnp.bool_)


def get_allowed_directions(position: chex.Array, action: chex.Array, dofmaze: chex.Array, directions: chex.Array, is_ghost: bool = False):
    """
    Returns an array of all directions (Jaxtari actions) in which movement is possible.
    To be jit-compatible the size of the output array is fixed, so invalid directions are marked with 0 (NOOP).
    Turning is only allowed at the centre of each tile and reverting is not allowed.
    """
    direction_count = directions.shape[0]

    # Return allowed directions and their count
    def at_center(_):
        # Available directions for the current position
        available_mask = available_directions(position, dofmaze)
        
        # Restrict ghosts from entering side tunnels
        available_mask = jax.lax.cond(
            jnp.array(is_ghost, dtype=jnp.bool_),
            lambda: available_mask.at[1].set(jnp.where(position[0] >= 132, False, available_mask[1])).at[2].set(jnp.where(position[0] <= 28, False, available_mask[2])),
            lambda: available_mask
        )

        # Directions that are not the reverse of current action
        not_reverse_mask = jnp.arange(direction_count) != act_to_dir(reverse_action(action))

        allowed_mask = available_mask & not_reverse_mask
        allowed_actions = jnp.where(allowed_mask, directions, 0)
        return jnp.compress(allowed_actions != 0, allowed_actions, size=direction_count).astype(jnp.uint8)

    # Return the current direction
    def not_at_center(_):
        return jnp.zeros(direction_count, dtype=jnp.uint8).at[0].set(action)

    # Check if the position is at the center of a tile
    at_tile_center = (position[0] % 4 == 1) | (position[1] % 12 == 6)
    return jax.lax.cond(
        at_tile_center,
        at_center,
        not_at_center,
        None
    )


def get_chase_target(ghost: GhostType,
                     ghost_position: chex.Array, blinky_pos: chex.Array,
                     player_pos: chex.Array, player_dir: chex.Array,
                     actions: chex.Array, scatter_targets: chex.Array) -> chex.Array:
    """
    Compute the chase-mode target for each ghost:
    0=Red (Blinky), 1=Pink (Pinky), 2=Blue (Inky), 3=Orange (Sue)
    """
    def get_blinky_target(_):
        return player_pos
    
    def get_pinky_target(_):
        return player_pos + 4*MsPacmanMaze.TILE_SCALE * actions[player_dir]
    
    def get_inky_target(_):
        two_ahead = player_pos + 2*MsPacmanMaze.TILE_SCALE * actions[player_dir]
        vect = two_ahead - blinky_pos
        return blinky_pos + 2 * vect
    
    def get_sue_target(_):
        dist = jnp.linalg.norm(ghost_position - player_pos)
        return jnp.where(dist > 8*MsPacmanMaze.TILE_SCALE, player_pos, scatter_targets[GhostType.SUE])
    
    return jax.lax.switch(
        ghost,
        (
            get_blinky_target,  # GhostType.BLINKY
            get_pinky_target,   # GhostType.PINKY
            get_inky_target,    # GhostType.INKY
            get_sue_target      # GhostType.SUE
        ),
        None
    )


def pathfind(position: chex.Array, direction: chex.Array, target: chex.Array, allowed: chex.Array, key: chex.Array, actions: chex.Array, directions: chex.Array):
    """
    Returns the direction which should be taken to approach the target.
    If multiple options exist the direction is chosen that minimizes the distance on the longer axis - horizontal or vertical.
    If both distances are equal or multiple options exist on the same axis, the direction is chosen randomly.
    """
    valid_mask = allowed != 0
    n_allowed = jnp.sum(valid_mask)

    # If no direction allowed - Continue forward
    def no_allowed():
        return direction.astype(allowed.dtype)

    # If one direction allowed - Take it
    def one_allowed():
        return allowed[0].astype(allowed.dtype)

    # If multiple directions allowed - Get cost of all possible steps and determine advantageous directions
    def multi_allowed():
        new_positions = position + actions[allowed]
        costs = jnp.abs(new_positions - target).sum(axis=1)  # Manhattan distances
        costs = jnp.where(valid_mask, costs, jnp.iinfo(jnp.int32).max)
        min_cost = jnp.min(costs)
        min_mask = costs == min_cost
        min_dirs = jnp.compress(min_mask, allowed, size=directions.shape[0])
        n_min = jnp.sum(min_dirs != 0)

        # If one direction advantageous - Take it
        def one_min():
            return min_dirs[0].astype(allowed.dtype)

        # If multiple directions advantageous - Prioritize the longer axis
        def multi_min():
            h_dist = jnp.abs(position[0] - target[0])
            v_dist = jnp.abs(position[1] - target[1])
            h_dirs = jnp.array([int(Action.LEFT), int(Action.RIGHT)], dtype=jnp.int32)
            v_dirs = jnp.array([int(Action.DOWN), int(Action.UP)], dtype=jnp.int32)
            h_mask = jnp.isin(min_dirs, h_dirs)
            v_mask = jnp.isin(min_dirs, v_dirs)
            prefer_h = h_dist >= v_dist
            prefer_v = v_dist >= h_dist
            prefered = (h_mask & prefer_h) | (v_mask & prefer_v)
            n_prefered = jnp.sum(prefered)

            # If no direction advantageous on longer axis - Choose randomly
            def no_long_axis():
                return min_dirs[jax.random.randint(key, (), 0, n_min)].astype(allowed.dtype)

            # If one direction advantageous on longer axis - Take it
            def one_long_axis():
                return min_dirs[jnp.argmax(prefered)].astype(allowed.dtype)
            
            # If multiple directions advantageous on longer or equal axis - Choose randomly with mask
            def multi_long_axis():
                prefered_dirs = jnp.compress(prefered, min_dirs, size=directions.shape[0])
                return prefered_dirs[jax.random.randint(key, (), 0, n_prefered)].astype(allowed.dtype)

            # Check for advantageous directions on longer axis
            return jax.lax.cond(
                n_prefered == 0,
                no_long_axis,
                lambda: jax.lax.cond(
                    n_prefered == 1,
                    one_long_axis,
                    multi_long_axis
                )
            )

        # Check for advantageous directions
        return jax.lax.cond(
            n_min == 1,
            one_min,
            multi_min
        )

    # Check for allowed directions
    return jax.lax.cond(
        n_allowed == 0,
        no_allowed,
        lambda: jax.lax.cond(
            n_allowed == 1,
            one_allowed,
            multi_allowed
        )
    )


"""Returns the next position, given the current position and action that is applied this step"""
def get_new_position(position: chex.Array, action: chex.Array, consts: MsPacmanConstants):
    direction = jnp.asarray(consts.ACTIONS)[action]
    pos = position.astype(jnp.int32)
    x, y = pos[0], pos[1]
    # Horizontal: 2px from x%4==3 lands on a turn column (x%4==1) → 2,1,1 (~1.33px/tick).
    h_step = jnp.where(x % 4 == 3, consts.HORIZONTAL_SPEED + 1, consts.HORIZONTAL_SPEED)
    # Vertical: 2,2,2,2,1,2,1 over each 12px row so we keep y%12==6 and match ALE (~1.7px/tick).
    phase = jnp.where(direction[1] > 0, (y - 6) % 12, (6 - y) % 12)
    v_two = (phase == 0) | (phase == 2) | (phase == 4) | (phase == 6) | (phase == 9)
    v_step = jnp.where(v_two, consts.VERTICAL_SPEED, consts.HORIZONTAL_SPEED)
    delta = jnp.stack([direction[0] * h_step, direction[1] * v_step])
    new_position = pos + delta
    return new_position.at[0].set(new_position[0] % 160).astype(position.dtype)



def get_level_maze(level: chex.Array):
    """Returns the maze id that correpsonds to the current level."""
    return jax.lax.switch(  # Invalid levels (<0) are not handled explicitly and just get assigned to level 0
        jnp.digitize(level, jnp.array([2, 4, 6, 8]), right=True).astype(jnp.int32),
        (
            lambda lvl: jnp.array(0, dtype=jnp.int32),  # Levels 1-2
            lambda lvl: jnp.array(1, dtype=jnp.int32),  # Levels 3-4
            lambda lvl: jnp.array(2, dtype=jnp.int32),  # Levels 5-6
            lambda lvl: jnp.array(3, dtype=jnp.int32),  # Levels 7-8
            lambda lvl: jax.lax.cond(                   # Levels 9+
                (lvl % 4 == 0) | (lvl % 4 == 1),
                lambda: jnp.array(2, dtype=jnp.int32),
                lambda: jnp.array(3, dtype=jnp.int32)
            )
        ),
        level
    )


def get_level_fruit(level: chex, key: chex.Array):
    """Returns the fruit that corresponds to the current level."""
    return jax.lax.cond(
        level > 7,
        lambda: jax.random.randint(key, (), 0, 6),
        lambda: jax.lax.switch(
            level,
            (
                lambda _: FruitType.CHERRY,     # Level 0 - Invalid level, defaults to cherry
                lambda _: FruitType.CHERRY,     # Level 1
                lambda _: FruitType.STRAWBERRY, # Level 2
                lambda _: FruitType.ORANGE,     # Level 3
                lambda _: FruitType.PRETZEL,    # Level 4
                lambda _: FruitType.APPLE,      # Level 5
                lambda _: FruitType.PEAR,       # Level 6
                lambda _: FruitType.BANANA      # Level 7
            ),
            None
        )
    )


def get_random_tunnel(level: chex.Array, key: chex.Array):
    """Returns the position and exit direction of a random tunnel."""
    maze = get_level_maze(level)
    tunnel_heights = jnp.array(MsPacmanMaze.TUNNEL_HEIGHTS)[maze]

    tunnels_dir = jnp.array([
        int(Action.RIGHT),
        int(Action.LEFT),
        int(Action.RIGHT),
        int(Action.LEFT)
    ], dtype=jnp.uint8)

    tunnels_pos = jnp.array([
        [0, tunnel_heights[0]],
        [MsPacmanMaze.WIDTH - 1, tunnel_heights[0]],
        [0, tunnel_heights[1]],
        [MsPacmanMaze.WIDTH - 1, tunnel_heights[1]]
    ], dtype=jnp.int32)

    # If the second element is 0, there is only one pair of tunnels
    max_choices = jax.lax.cond(tunnel_heights[1] == 0, lambda: 2, lambda: 4)
    tunnel_idx = jax.random.randint(key, (), 0, max_choices)

    return tunnels_pos[tunnel_idx], tunnels_dir[tunnel_idx]


def reverse_action(dir_idx: chex.Array):
    """Inverts the direction if possible."""
    # Mapping for actions: 0->0, 1->1, 2->5, 3->4, 4->3, 5->2
    inv_map = jnp.array([0, 1, 5, 4, 3, 2], dtype=jnp.uint8)
    idx = jnp.array(dir_idx, dtype=jnp.uint8)
    in_range = (idx >= 0) & (idx < inv_map.shape[0])
    return jnp.where(in_range, inv_map[idx], idx).astype(idx.dtype)
    

def detect_collision(position_1: chex.Array, position_2: chex.Array, collision_threshold: chex.Array):
    """Checks if the two positions are closer than the collision threshold."""
    return jnp.all(abs(jnp.array(position_1) - jnp.array(position_2)) < collision_threshold)


# -------- Reset functions --------
def reset_level(level: chex.Array):
    return LevelState(
        id                  = jnp.array(level, dtype=jnp.uint8),
        collected_pellets   = jnp.array(0, dtype=jnp.uint8),
        pellets             = jnp.copy(MsPacmanMaze.BASE_PELLETS),
        power_pellets       = jnp.ones(4, dtype=jnp.bool_),
        loaded              = jnp.array(0, dtype=jnp.uint8)
    )

def reset_player(consts: MsPacmanConstants):
    return PlayerState(
        position            = jnp.asarray(consts.INITIAL_PACMAN_POSITION),
        action              = jnp.array(Action.LEFT, dtype=jnp.uint8),
        has_pellet          = jnp.array(False),
        eaten_ghosts        = jnp.array(0, dtype=jnp.uint8)
    )

def reset_ghosts(consts: MsPacmanConstants):
    return GhostsState (
        positions   = jnp.asarray(consts.INITIAL_GHOSTS_POSITIONS),
        types       = jnp.array([GhostType.BLINKY, GhostType.PINKY, GhostType.INKY, GhostType.SUE], dtype=jnp.uint8),
        actions     = jnp.array([Action.LEFT, Action.NOOP, Action.NOOP, Action.NOOP], dtype=jnp.uint8),
        modes       = jnp.array([GhostMode.RANDOM, GhostMode.ENJAILED, GhostMode.ENJAILED, GhostMode.ENJAILED], dtype=jnp.uint8),
        timers      = jnp.array([consts.SCATTER_DURATION, consts.PINKY_RELEASE_TIME, consts.INKY_RELEASE_TIME, consts.SUE_RELEASE_TIME], dtype=jnp.float16),
    )

def reset_fruit(consts: MsPacmanConstants, level: chex.Array, key: chex.PRNGKey):
    return FruitState(
        position    = jnp.zeros(2, dtype=jnp.uint8),
        exit        = jnp.zeros(2, dtype=jnp.uint8),
        type        = jnp.array(get_level_fruit(level, key), dtype=jnp.uint8),
        action      = jnp.array(Action.NOOP, dtype=jnp.uint8),
        spawn       = jnp.array(False, dtype=jnp.bool),
        spawned     = jnp.array(False, dtype=jnp.bool),
        timer       = jnp.array(jnp.array(consts.FRUIT_WANDER_DURATION, dtype=jnp.uint16), dtype=jnp.uint16)
    )

def reset_game(consts: MsPacmanConstants, level: chex.Array, lives: chex.Array, score: chex.Array, key: chex.PRNGKey):
    return PacmanState(
        level           = reset_level(level),
        player          = reset_player(consts),
        ghosts          = reset_ghosts(consts),
        fruit           = reset_fruit(consts, level, key),
        lives           = jnp.array(lives, dtype=jnp.int8),
        score           = jnp.array(score, dtype=jnp.uint32),
        score_changed   = jnp.arange(consts.MAX_SCORE_DIGITS) >= (consts.MAX_SCORE_DIGITS - get_digit_count(score)),
        freeze_timer    = jnp.array(0, dtype=jnp.uint32),
        eat_freeze_timer = jnp.array(0, dtype=jnp.uint32),
        step_count      = jnp.array(0, dtype=jnp.uint32),
        key             = key
    )

def reset_entities(consts: MsPacmanConstants, state: PacmanState, key: chex.PRNGKey):
    return PacmanState(
        level = LevelState(
            id = state.level.id,
            collected_pellets=state.level.collected_pellets,
            pellets=state.level.pellets,
            power_pellets=state.level.power_pellets,
            loaded=state.level.loaded
        ),
        player          = reset_player(consts),
        ghosts          = reset_ghosts(consts),
        fruit           = reset_fruit(consts, state.level.id, key),
        lives           = state.lives,
        score           = state.score,
        score_changed   = state.score_changed,
        freeze_timer    = state.freeze_timer,
        eat_freeze_timer = jnp.array(0, dtype=jnp.uint32),
        step_count      = jnp.array(0, dtype=jnp.uint32),
        key             = state.key
    )
